-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 
-- Database : hamanaka3
-- 
-- Part : #1
-- Date : 2014-11-21 10:17:37
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `smi_access`
-- -----------------------------
DROP TABLE IF EXISTS `smi_access`;
CREATE TABLE `smi_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_access`
-- -----------------------------
INSERT INTO `smi_access` VALUES ('1', '54', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '53', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '52', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '51', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '50', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '49', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '48', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '47', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '46', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '45', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '44', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '43', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '42', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '41', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '40', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '39', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '38', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '37', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '36', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '35', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '34', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '33', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '32', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '31', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '30', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '29', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '28', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '27', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '26', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '25', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '24', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '12', '1', '1');
INSERT INTO `smi_access` VALUES ('1', '62', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '61', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '60', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '59', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '11', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '10', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '9', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '8', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '7', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '6', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '5', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '4', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '3', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '2', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '1', '1', '1');
INSERT INTO `smi_access` VALUES ('2', '1', '1', '1');
INSERT INTO `smi_access` VALUES ('2', '2', '2', '1');
INSERT INTO `smi_access` VALUES ('2', '3', '3', '1');
INSERT INTO `smi_access` VALUES ('2', '4', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '5', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '6', '2', '1');
INSERT INTO `smi_access` VALUES ('2', '7', '3', '1');
INSERT INTO `smi_access` VALUES ('2', '8', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '9', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '10', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '11', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '12', '1', '1');
INSERT INTO `smi_access` VALUES ('2', '48', '2', '1');
INSERT INTO `smi_access` VALUES ('2', '49', '3', '1');
INSERT INTO `smi_access` VALUES ('2', '50', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '51', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '52', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '53', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '54', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '55', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '56', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '57', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '58', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '55', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '56', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '57', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '58', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '63', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '64', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '65', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '66', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '67', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '68', '4', '1');

-- -----------------------------
-- Table structure for `smi_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `smi_attribute`;
CREATE TABLE `smi_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute` varchar(128) NOT NULL,
  `attribute_alias` varchar(128) NOT NULL,
  `display` tinyint(1) NOT NULL COMMENT '1单选0多选',
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='产品属性表';

-- -----------------------------
-- Records of `smi_attribute`
-- -----------------------------
INSERT INTO `smi_attribute` VALUES ('1', '价格', '价格', '1', '');
INSERT INTO `smi_attribute` VALUES ('2', '网络制式', '网络制式', '1', '');

-- -----------------------------
-- Table structure for `smi_attribute_value`
-- -----------------------------
DROP TABLE IF EXISTS `smi_attribute_value`;
CREATE TABLE `smi_attribute_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `attribute_value` varchar(128) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='产品属性值表';

-- -----------------------------
-- Records of `smi_attribute_value`
-- -----------------------------
INSERT INTO `smi_attribute_value` VALUES ('2', '1', '0-100', '0');
INSERT INTO `smi_attribute_value` VALUES ('3', '1', '100-200', '1');
INSERT INTO `smi_attribute_value` VALUES ('4', '1', '300-500', '2');
INSERT INTO `smi_attribute_value` VALUES ('5', '2', '移动', '0');
INSERT INTO `smi_attribute_value` VALUES ('6', '2', '联通', '1');
INSERT INTO `smi_attribute_value` VALUES ('7', '2', '电信', '2');

-- -----------------------------
-- Table structure for `smi_category`
-- -----------------------------
DROP TABLE IF EXISTS `smi_category`;
CREATE TABLE `smi_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(128) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `route` varchar(128) DEFAULT NULL,
  `grade` tinyint(4) DEFAULT NULL,
  `sort` smallint(6) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='产品分类';

-- -----------------------------
-- Records of `smi_category`
-- -----------------------------
INSERT INTO `smi_category` VALUES ('1', '数码产品', '0', '0', '1', '0', '1', '0');
INSERT INTO `smi_category` VALUES ('2', '电脑', '1', '0,1', '2', '0', '1', '2');
INSERT INTO `smi_category` VALUES ('3', '手机', '1', '0,1', '2', '0', '1', '1');
INSERT INTO `smi_category` VALUES ('4', '相机', '1', '0,1', '2', '0', '1', '0');

-- -----------------------------
-- Table structure for `smi_config`
-- -----------------------------
DROP TABLE IF EXISTS `smi_config`;
CREATE TABLE `smi_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_title` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `route` varchar(64) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `remark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='网站配置表';

-- -----------------------------
-- Records of `smi_config`
-- -----------------------------
INSERT INTO `smi_config` VALUES ('1', '基本配置', '', 'text', '', '0', '1', '0', '0', '');
INSERT INTO `smi_config` VALUES ('2', '网站标题', 'META_TITLE', 'text', '这是网站标题', '1', '2', '0,1', '0', '网站前台显示标题');
INSERT INTO `smi_config` VALUES ('3', '网站描述', 'META_DESCRIPTION', 'textarea', '这是网站描述', '1', '2', '0,1', '0', '网站搜索引擎描述');
INSERT INTO `smi_config` VALUES ('4', '网站关键字', 'META_KEYWORD', 'textarea', '这是网站关键字', '1', '2', '0,1', '0', '网站搜索引擎关键字');
INSERT INTO `smi_config` VALUES ('5', '网站备案号', 'META_COPYRIGHT', 'text', '这是网站备案号', '1', '2', '0,1', '0', '');
INSERT INTO `smi_config` VALUES ('6', '邮箱配置', '', 'text', '', '0', '1', '0', '0', '');
INSERT INTO `smi_config` VALUES ('7', 'SMTP服务器', 'SMTP_HOST', 'text', 'localhost', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('8', 'SMTP用户名', 'SMTP_USERNAME', 'text', 'mail@example.com', '6', '2', '0,6', '0', '邮箱全称：mail@example.com');
INSERT INTO `smi_config` VALUES ('9', 'SMTP密码', 'SMTP_PWD', 'text', 'password', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('10', 'SMTP端口', 'SMTP_PORT', 'text', '25', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('11', '字符编码', 'SMTP_CHARSET', 'text', 'utf-8', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('12', '编码方式', 'SMTP_ENCODING', 'text', '', '6', '2', '0,6', '0', '若发送邮件内容出现乱码则用base64');

-- -----------------------------
-- Table structure for `smi_country`
-- -----------------------------
DROP TABLE IF EXISTS `smi_country`;
CREATE TABLE `smi_country` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `country_en` varchar(50) NOT NULL,
  `country_cn` varchar(64) NOT NULL,
  `code` varchar(5) NOT NULL DEFAULT '',
  `area` varchar(5) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`country_en`)
) ENGINE=MyISAM AUTO_INCREMENT=243 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_country`
-- -----------------------------
INSERT INTO `smi_country` VALUES ('1', 'Afghanistan', '阿富汗', 'AF', '93', '1');
INSERT INTO `smi_country` VALUES ('2', 'Albania', '阿尔巴尼亚', 'AL', '355', '1');
INSERT INTO `smi_country` VALUES ('3', 'Algeria', '阿尔及利亚', 'DZ', '213', '1');
INSERT INTO `smi_country` VALUES ('4', 'American Samoa', '东萨摩亚', 'AS', '684', '1');
INSERT INTO `smi_country` VALUES ('5', 'Andorra', '安道尔共和国', 'AD', '376', '1');
INSERT INTO `smi_country` VALUES ('6', 'Angola', '安哥拉', 'AO', '244', '1');
INSERT INTO `smi_country` VALUES ('7', 'Anguilla', '安圭拉岛', 'AI', '1-264', '1');
INSERT INTO `smi_country` VALUES ('8', 'Antarctica', '南极洲', 'AQ', '672', '1');
INSERT INTO `smi_country` VALUES ('9', 'Antigua and Barbuda', '安提瓜和巴布达', 'AG', '1-268', '1');
INSERT INTO `smi_country` VALUES ('10', 'Argentina', '阿根廷', 'AR', '54', '1');
INSERT INTO `smi_country` VALUES ('11', 'Armenia', '亚美尼亚', 'AM', '374', '1');
INSERT INTO `smi_country` VALUES ('12', 'Aruba', '阿鲁巴', 'AW', '297', '1');
INSERT INTO `smi_country` VALUES ('13', 'Australia', '澳大利亚 ', 'AU', '61', '1');
INSERT INTO `smi_country` VALUES ('14', 'Austria', '奥地利 ', 'AT', '43', '1');
INSERT INTO `smi_country` VALUES ('15', 'Azerbaijan', '阿塞拜疆', 'AZ', '994', '1');
INSERT INTO `smi_country` VALUES ('16', 'Bahamas', '巴哈马 ', 'BS', '1-242', '1');
INSERT INTO `smi_country` VALUES ('17', 'Bahrain', '巴林', 'BH', '973', '1');
INSERT INTO `smi_country` VALUES ('18', 'Bangladesh', '孟加拉国', 'BD', '880', '1');
INSERT INTO `smi_country` VALUES ('19', 'Barbados', '巴巴多斯 ', 'BB', '1-246', '1');
INSERT INTO `smi_country` VALUES ('20', 'Belarus', '白俄罗斯', 'BY', '375', '1');
INSERT INTO `smi_country` VALUES ('21', 'Belgium', '比利时', 'BE', '32', '1');
INSERT INTO `smi_country` VALUES ('22', 'Belize', '伯利兹 ', 'BZ', '501', '1');
INSERT INTO `smi_country` VALUES ('23', 'Benin', '贝宁', 'BJ', '229', '1');
INSERT INTO `smi_country` VALUES ('24', 'Bermuda', '百慕大群岛 ', 'BM', '1-441', '1');
INSERT INTO `smi_country` VALUES ('25', 'Bhutan', '不丹', 'BT', '975', '1');
INSERT INTO `smi_country` VALUES ('26', 'Bolivia', '玻利维亚', 'BO', '591', '1');
INSERT INTO `smi_country` VALUES ('27', 'Bosnia and Herzegovina', '波斯尼亚和黑塞哥维纳 ', 'BA', '387', '1');
INSERT INTO `smi_country` VALUES ('28', 'Botswana', '博茨瓦纳', 'BW', '267', '1');
INSERT INTO `smi_country` VALUES ('29', 'Bouvet Island', '布韦岛', 'BV', '', '1');
INSERT INTO `smi_country` VALUES ('30', 'Brazil', '巴西', 'BR', '55', '1');
INSERT INTO `smi_country` VALUES ('31', 'British Indian Ocean Territory', '英属印度洋领地', 'IO', '1-284', '1');
INSERT INTO `smi_country` VALUES ('32', 'Brunei Darussalam', '文莱达鲁萨兰国', 'BN', '673', '1');
INSERT INTO `smi_country` VALUES ('33', 'Bulgaria', '保加利亚', 'BG', '359', '1');
INSERT INTO `smi_country` VALUES ('34', 'Burkina Faso', '布基纳法索 ', 'BF', '226', '1');
INSERT INTO `smi_country` VALUES ('35', 'Burundi', '布隆迪 ', 'BI', '257', '1');
INSERT INTO `smi_country` VALUES ('36', 'Cambodia', '柬埔寨', 'KH', '855', '1');
INSERT INTO `smi_country` VALUES ('37', 'Cameroon', '喀麦隆', 'CM', '237', '1');
INSERT INTO `smi_country` VALUES ('38', 'Canada', '加拿大 ', 'CA', '1', '1');
INSERT INTO `smi_country` VALUES ('39', 'Cape Verde', '佛得角', 'CV', '238', '1');
INSERT INTO `smi_country` VALUES ('40', 'Cayman Islands', '开曼群岛', 'KY', '1-345', '1');
INSERT INTO `smi_country` VALUES ('41', 'Central African Republic', '中非共和国', 'CF', '236', '1');
INSERT INTO `smi_country` VALUES ('42', 'Chad', '乍得', 'TD', '235', '1');
INSERT INTO `smi_country` VALUES ('43', 'Chile', '智利 ', 'CL', '56', '1');
INSERT INTO `smi_country` VALUES ('44', 'China', '中国', 'CN', '86', '1');
INSERT INTO `smi_country` VALUES ('45', 'Christmas Island', '圣诞岛', 'CX', '61', '1');
INSERT INTO `smi_country` VALUES ('46', 'Cocos (Keeling) Islands', '科科斯群岛', 'CC', '61', '1');
INSERT INTO `smi_country` VALUES ('47', 'Colombia', '哥伦比亚', 'CO', '57', '1');
INSERT INTO `smi_country` VALUES ('48', 'Comoros', '科摩罗', 'KM', '269', '1');
INSERT INTO `smi_country` VALUES ('49', 'Congo', '刚果', 'CG', '242', '1');
INSERT INTO `smi_country` VALUES ('50', 'Congo, The Democratic Republic Of The', '扎伊尔', 'ZR', '243', '1');
INSERT INTO `smi_country` VALUES ('51', 'Cook Islands', '库克群岛', 'CK', '682', '1');
INSERT INTO `smi_country` VALUES ('52', 'Costa Rica', '哥斯达黎加', 'CR', '506', '1');
INSERT INTO `smi_country` VALUES ('53', 'Cote D\'Ivoire', '科特迪瓦', 'CI', '225', '1');
INSERT INTO `smi_country` VALUES ('54', 'Croatia (local name: Hrvatska)', '克罗地亚', 'HR', '385', '1');
INSERT INTO `smi_country` VALUES ('55', 'Cuba', '古巴', 'CU', '53', '1');
INSERT INTO `smi_country` VALUES ('56', 'Cyprus', '塞浦路斯', 'CY', '357', '1');
INSERT INTO `smi_country` VALUES ('57', 'Czech Republic', '捷克 ', 'CZ', '420', '1');
INSERT INTO `smi_country` VALUES ('58', 'Denmark', '丹麦', 'DK', '45', '1');
INSERT INTO `smi_country` VALUES ('59', 'Djibouti', '吉布提', 'DJ', '253', '1');
INSERT INTO `smi_country` VALUES ('60', 'Dominica', '多米尼加（西印度群岛岛国）', 'DM', '1-767', '1');
INSERT INTO `smi_country` VALUES ('61', 'Dominican Republic', '多米尼加共和国', 'DO', '1-809', '1');
INSERT INTO `smi_country` VALUES ('62', 'East Timor', '东帝汶', 'TP', '670', '1');
INSERT INTO `smi_country` VALUES ('63', 'Ecuador', '厄瓜多尔 ', 'EC', '593', '1');
INSERT INTO `smi_country` VALUES ('64', 'Egypt', '埃及', 'EG', '20', '1');
INSERT INTO `smi_country` VALUES ('65', 'El Salvador', '萨尔瓦多', 'SV', '503', '1');
INSERT INTO `smi_country` VALUES ('66', 'Equatorial Guinea', '赤道几内亚', 'GQ', '240', '1');
INSERT INTO `smi_country` VALUES ('67', 'Eritrea', '厄立特里亚', 'ER', '291', '1');
INSERT INTO `smi_country` VALUES ('68', 'Estonia', '爱沙尼亚', 'EE', '372', '1');
INSERT INTO `smi_country` VALUES ('69', 'Ethiopia', '埃塞俄比亚', 'ET', '251', '1');
INSERT INTO `smi_country` VALUES ('70', 'Falkland Islands (Malvinas)', '福克兰群岛（马尔维纳斯群岛）', 'FK', '500', '1');
INSERT INTO `smi_country` VALUES ('71', 'Faroe Islands', '法罗群岛', 'FO', '298', '1');
INSERT INTO `smi_country` VALUES ('72', 'Fiji', '斐济', 'FJ', '679', '1');
INSERT INTO `smi_country` VALUES ('73', 'Finland', '芬兰', 'FI', '358', '1');
INSERT INTO `smi_country` VALUES ('74', 'France', '法国 ', 'FR', '33', '1');
INSERT INTO `smi_country` VALUES ('75', 'France Metropolitan', '法属美特罗波利坦 ', 'FX', '33', '1');
INSERT INTO `smi_country` VALUES ('76', 'French Guiana', '法属圭亚那', 'GF', '594', '1');
INSERT INTO `smi_country` VALUES ('77', 'French Polynesia', '法属玻利尼西亚', 'PF', '689', '1');
INSERT INTO `smi_country` VALUES ('78', 'French Southern Territories', '法属南部领土', 'TF', '', '1');
INSERT INTO `smi_country` VALUES ('79', 'Gabon', '加蓬', 'GA', '241', '1');
INSERT INTO `smi_country` VALUES ('80', 'Gambia', '冈比亚', 'GM', '220', '1');
INSERT INTO `smi_country` VALUES ('81', 'Georgia', '格鲁吉亚', 'GE', '995', '1');
INSERT INTO `smi_country` VALUES ('82', 'Germany', '德国 ', 'DE', '49', '1');
INSERT INTO `smi_country` VALUES ('83', 'Ghana', '加纳', 'GH', '233', '1');
INSERT INTO `smi_country` VALUES ('84', 'Gibraltar', '直布罗陀', 'GI', '350', '1');
INSERT INTO `smi_country` VALUES ('85', 'Greece', '希腊', 'GR', '30', '1');
INSERT INTO `smi_country` VALUES ('86', 'Greenland', '格陵兰', 'GL', '299', '1');
INSERT INTO `smi_country` VALUES ('87', 'Grenada', '格林纳达', 'GD', '1-473', '1');
INSERT INTO `smi_country` VALUES ('88', 'Guadeloupe', '瓜德罗普岛', 'GP', '590', '1');
INSERT INTO `smi_country` VALUES ('89', 'Guam', '关岛', 'GU', '1-671', '1');
INSERT INTO `smi_country` VALUES ('90', 'Guatemala', '危地马拉', 'GT', '502', '1');
INSERT INTO `smi_country` VALUES ('91', 'Guinea', '几内亚', 'GN', '224', '1');
INSERT INTO `smi_country` VALUES ('92', 'Guinea-Bissau', '几内亚比绍共和国', 'GW', '245', '1');
INSERT INTO `smi_country` VALUES ('93', 'Guyana', '圭亚那', 'GY', '592', '1');
INSERT INTO `smi_country` VALUES ('94', 'Haiti', '海地 ', 'HT', '509', '1');
INSERT INTO `smi_country` VALUES ('95', 'Heard and Mc Donald Islands', '赫德岛和麦克唐纳群岛', 'HM', '', '1');
INSERT INTO `smi_country` VALUES ('96', 'Honduras', '洪都拉斯', 'HN', '504', '1');
INSERT INTO `smi_country` VALUES ('97', 'Hong Kong', '香港', 'HK', '852', '1');
INSERT INTO `smi_country` VALUES ('98', 'Hungary', '匈牙利', 'HU', '36', '1');
INSERT INTO `smi_country` VALUES ('99', 'Iceland', '冰岛', 'IS', '354', '1');
INSERT INTO `smi_country` VALUES ('100', 'India', '印度', 'IN', '91', '1');
INSERT INTO `smi_country` VALUES ('101', 'Indonesia', '印度尼西亚', 'ID', '62', '1');
INSERT INTO `smi_country` VALUES ('102', 'Iran (Islamic Republic of)', '伊朗', 'IR', '98', '1');
INSERT INTO `smi_country` VALUES ('103', 'Iraq', '伊拉克', 'IQ', '964', '1');
INSERT INTO `smi_country` VALUES ('104', 'Ireland', '爱尔兰', 'IE', '353', '1');
INSERT INTO `smi_country` VALUES ('105', 'Isle of Man', '马恩岛', 'IM', '', '1');
INSERT INTO `smi_country` VALUES ('106', 'Israel', '以色列', 'IL', '972', '1');
INSERT INTO `smi_country` VALUES ('107', 'Italy', '意大利', 'IT', '39', '1');
INSERT INTO `smi_country` VALUES ('108', 'Jamaica', '牙买加', 'JM', '1-876', '1');
INSERT INTO `smi_country` VALUES ('109', 'Japan', '日本', 'JP', '81', '1');
INSERT INTO `smi_country` VALUES ('110', 'Jordan', '约旦', 'JO', '962', '1');
INSERT INTO `smi_country` VALUES ('111', 'Kazakhstan', '哈萨克斯坦', 'KZ', '7', '1');
INSERT INTO `smi_country` VALUES ('112', 'Kenya', '肯尼亚', 'KE', '254', '1');
INSERT INTO `smi_country` VALUES ('113', 'Kiribati', '基里巴斯', 'KI', '686', '1');
INSERT INTO `smi_country` VALUES ('114', 'Kuwait', '科威特', 'KW', '965', '1');
INSERT INTO `smi_country` VALUES ('115', 'Kyrgyzstan', '吉尔吉斯坦', 'KG', '996', '1');
INSERT INTO `smi_country` VALUES ('116', 'Lao People\'s Democratic Republic', '老挝', 'LA', '', '1');
INSERT INTO `smi_country` VALUES ('117', 'Latvia', '拉脱维亚', 'LV', '371', '1');
INSERT INTO `smi_country` VALUES ('118', 'Lebanon', '黎巴嫩', 'LB', '961', '1');
INSERT INTO `smi_country` VALUES ('119', 'Lesotho', '莱索托', 'LS', '266', '1');
INSERT INTO `smi_country` VALUES ('120', 'Liberia', '利比里亚', 'LR', '231', '1');
INSERT INTO `smi_country` VALUES ('121', 'Libyan Arab Jamahiriya', '阿拉伯利比亚民众国', 'LY', '218', '1');
INSERT INTO `smi_country` VALUES ('122', 'Liechtenstein', '列支敦士登', 'LI', '423', '1');
INSERT INTO `smi_country` VALUES ('123', 'Lithuania', '立陶宛', 'LT', '370', '1');
INSERT INTO `smi_country` VALUES ('124', 'Luxembourg', '卢森堡', 'LU', '352', '1');
INSERT INTO `smi_country` VALUES ('125', 'Macau', '澳门', 'MO', '853', '1');
INSERT INTO `smi_country` VALUES ('126', 'Madagascar', '马达加斯加', 'MG', '261', '1');
INSERT INTO `smi_country` VALUES ('127', 'Malawi', '马拉维', 'MW', '265', '1');
INSERT INTO `smi_country` VALUES ('128', 'Malaysia', '马来西亚', 'MY', '60', '1');
INSERT INTO `smi_country` VALUES ('129', 'Maldives', '马尔代夫', 'MV', '960', '1');
INSERT INTO `smi_country` VALUES ('130', 'Mali', '马里', 'ML', '223', '1');
INSERT INTO `smi_country` VALUES ('131', 'Malta', '马耳他', 'MT', '356', '1');
INSERT INTO `smi_country` VALUES ('132', 'Marshall Islands', '马里亚那群岛', 'MH', '692', '1');
INSERT INTO `smi_country` VALUES ('133', 'Martinique', '马提尼克', 'MQ', '596', '1');
INSERT INTO `smi_country` VALUES ('134', 'Mauritania', '毛利塔尼亚', 'MR', '222', '1');
INSERT INTO `smi_country` VALUES ('135', 'Mauritius', '毛里求斯', 'MU', '230', '1');
INSERT INTO `smi_country` VALUES ('136', 'Mayotte', '马约特岛', 'YT', '269', '1');
INSERT INTO `smi_country` VALUES ('137', 'Mexico', '墨西哥', 'MX', '52', '1');
INSERT INTO `smi_country` VALUES ('138', 'Micronesia', '密克罗尼西亚', 'FM', '691', '1');
INSERT INTO `smi_country` VALUES ('139', 'Moldova', '摩尔多瓦', 'MD', '373', '1');
INSERT INTO `smi_country` VALUES ('140', 'Monaco', '摩纳哥', 'MC', '377', '1');
INSERT INTO `smi_country` VALUES ('141', 'Mongolia', '蒙古', 'MN', '976', '1');
INSERT INTO `smi_country` VALUES ('142', 'Montenegro', '黑山共和国', 'MNE', '382', '1');
INSERT INTO `smi_country` VALUES ('143', 'Montserrat', '蒙特塞拉特岛', 'MS', '1-664', '1');
INSERT INTO `smi_country` VALUES ('144', 'Morocco', '摩洛哥', 'MA', '212', '1');
INSERT INTO `smi_country` VALUES ('145', 'Mozambique', '莫桑比克', 'MZ', '258', '1');
INSERT INTO `smi_country` VALUES ('146', 'Myanmar', '缅甸', 'MM', '95', '1');
INSERT INTO `smi_country` VALUES ('147', 'Namibia', '纳米比亚', 'NA', '264', '1');
INSERT INTO `smi_country` VALUES ('148', 'Nauru', '瑙鲁', 'NR', '674', '1');
INSERT INTO `smi_country` VALUES ('149', 'Nepal', '尼泊尔', 'NP', '977', '1');
INSERT INTO `smi_country` VALUES ('150', 'Netherlands', '荷兰', 'NL', '31', '1');
INSERT INTO `smi_country` VALUES ('151', 'Netherlands Antilles', '', 'AN', '599', '0');
INSERT INTO `smi_country` VALUES ('152', 'New Caledonia', '新喀里多尼亚', 'NC', '687', '1');
INSERT INTO `smi_country` VALUES ('153', 'New Zealand', '新西兰', 'NZ', '64', '1');
INSERT INTO `smi_country` VALUES ('154', 'Nicaragua', '尼加拉瓜', 'NI', '505', '1');
INSERT INTO `smi_country` VALUES ('155', 'Niger', '尼日尔', 'NE', '227', '1');
INSERT INTO `smi_country` VALUES ('156', 'Nigeria', '尼日利亚', 'NG', '234', '1');
INSERT INTO `smi_country` VALUES ('157', 'Niue', '纽埃岛', 'NU', '683', '1');
INSERT INTO `smi_country` VALUES ('158', 'Norfolk Island', '诺福克岛', 'NF', '672', '1');
INSERT INTO `smi_country` VALUES ('159', 'North Korea', '韩国', 'KP', '850', '1');
INSERT INTO `smi_country` VALUES ('160', 'Northern Mariana Islands', '北马里亚纳群岛', 'MP', '1670', '1');
INSERT INTO `smi_country` VALUES ('161', 'Norway', '挪威', 'NO', '47', '1');
INSERT INTO `smi_country` VALUES ('162', 'Oman', '阿曼', 'OM', '968', '1');
INSERT INTO `smi_country` VALUES ('163', 'Pakistan', '巴基斯坦', 'PK', '92', '1');
INSERT INTO `smi_country` VALUES ('164', 'Palau', '帕劳群岛', 'PW', '680', '1');
INSERT INTO `smi_country` VALUES ('165', 'Palestine', '巴勒斯坦', 'PS', '970', '1');
INSERT INTO `smi_country` VALUES ('166', 'Panama', '巴拿马', 'PA', '507', '1');
INSERT INTO `smi_country` VALUES ('167', 'Papua New Guinea', '巴布亚新几内亚', 'PG', '675', '1');
INSERT INTO `smi_country` VALUES ('168', 'Paraguay', '巴拉圭', 'PY', '595', '1');
INSERT INTO `smi_country` VALUES ('169', 'Peru', '秘鲁', 'PE', '51', '1');
INSERT INTO `smi_country` VALUES ('170', 'Philippines', '菲律宾', 'PH', '63', '1');
INSERT INTO `smi_country` VALUES ('171', 'Pitcairn', '皮特凯恩群岛', 'PN', '872', '1');
INSERT INTO `smi_country` VALUES ('172', 'Poland', '波兰', 'PL', '48', '1');
INSERT INTO `smi_country` VALUES ('173', 'Portugal', '葡萄牙', 'PT', '351', '1');
INSERT INTO `smi_country` VALUES ('174', 'Puerto Rico', '波多黎各', 'PR', '1-787', '1');
INSERT INTO `smi_country` VALUES ('175', 'Qatar', '卡塔尔', 'QA', '974', '1');
INSERT INTO `smi_country` VALUES ('176', 'Reunion', '留尼旺', 'RE', '262', '1');
INSERT INTO `smi_country` VALUES ('177', 'Romania', '罗马尼亚', 'RO', '40', '1');
INSERT INTO `smi_country` VALUES ('178', 'Russian Federation', '俄罗斯联邦', 'RU', '7', '1');
INSERT INTO `smi_country` VALUES ('179', 'Rwanda', '卢旺达', 'RW', '250', '1');
INSERT INTO `smi_country` VALUES ('180', 'Saint Kitts and Nevis', '圣基茨和尼维斯', 'KN', '', '1');
INSERT INTO `smi_country` VALUES ('181', 'Saint Lucia', '圣卢西亚', 'LC', '', '1');
INSERT INTO `smi_country` VALUES ('182', 'Saint Vincent and the Grenadines', '圣文森特岛', 'VC', '', '1');
INSERT INTO `smi_country` VALUES ('183', 'Samoa', '萨摩亚群岛', 'WS', '685', '1');
INSERT INTO `smi_country` VALUES ('184', 'San Marino', '圣马力诺', 'SM', '378', '1');
INSERT INTO `smi_country` VALUES ('185', 'Sao Tome and Principe', '圣多美和普林西比', 'ST', '', '1');
INSERT INTO `smi_country` VALUES ('186', 'Saudi Arabia', '沙特阿拉伯', 'SA', '966', '1');
INSERT INTO `smi_country` VALUES ('187', 'Senegal', '塞内加尔', 'SN', '221', '1');
INSERT INTO `smi_country` VALUES ('188', 'Serbia', '塞尔维亚', 'SRB', '381', '1');
INSERT INTO `smi_country` VALUES ('189', 'Seychelles', '塞舌尔', 'SC', '248', '1');
INSERT INTO `smi_country` VALUES ('190', 'Sierra Leone', '塞拉利昂', 'SL', '232', '1');
INSERT INTO `smi_country` VALUES ('191', 'Singapore', '新加坡', 'SG', '65', '1');
INSERT INTO `smi_country` VALUES ('192', 'Slovakia (Slovak Republic)', '斯洛伐克', 'SK', '421', '1');
INSERT INTO `smi_country` VALUES ('193', 'Slovenia', '斯洛文尼亚', 'SI', '386', '1');
INSERT INTO `smi_country` VALUES ('194', 'Solomon Islands', '所罗门群岛', 'SB', '677', '1');
INSERT INTO `smi_country` VALUES ('195', 'Somalia', '索马里', 'SO', '252', '1');
INSERT INTO `smi_country` VALUES ('196', 'South Africa', '南非', 'ZA', '27', '1');
INSERT INTO `smi_country` VALUES ('197', 'South Korea', '韩国', 'KR', '82', '1');
INSERT INTO `smi_country` VALUES ('198', 'Spain', '西班牙', 'ES', '34', '1');
INSERT INTO `smi_country` VALUES ('199', 'Sri Lanka', '斯里兰卡', 'LK', '94', '1');
INSERT INTO `smi_country` VALUES ('200', 'St. Helena', '圣赫勒拿岛', 'SH', '290', '1');
INSERT INTO `smi_country` VALUES ('201', 'St. Pierre and Miquelon', '圣基茨-尼维斯-安圭拉岛 ', 'PM', '508', '1');
INSERT INTO `smi_country` VALUES ('202', 'Sudan', '苏丹', 'SD', '249', '1');
INSERT INTO `smi_country` VALUES ('203', 'Suriname', '苏里南', 'SR', '597', '1');
INSERT INTO `smi_country` VALUES ('204', 'Svalbard and Jan Mayen Islands', '斯瓦尔巴群岛', 'SJ', '', '1');
INSERT INTO `smi_country` VALUES ('205', 'Swaziland', '斯威士兰', 'SZ', '268', '1');
INSERT INTO `smi_country` VALUES ('206', 'Sweden', '瑞典', 'SE', '46', '1');
INSERT INTO `smi_country` VALUES ('207', 'Switzerland', '瑞士', 'CH', '41', '1');
INSERT INTO `smi_country` VALUES ('208', 'Syrian Arab Republic', '阿拉伯叙利亚共和国', 'SY', '963', '1');
INSERT INTO `smi_country` VALUES ('209', 'Taiwan', '台湾', 'TW', '886', '1');
INSERT INTO `smi_country` VALUES ('210', 'Tajikistan', '塔吉克斯坦', 'TJ', '992', '1');
INSERT INTO `smi_country` VALUES ('211', 'Tanzania', '坦桑尼亚', 'TZ', '255', '1');
INSERT INTO `smi_country` VALUES ('212', 'Thailand', '泰国', 'TH', '66', '1');
INSERT INTO `smi_country` VALUES ('213', 'The former Yugoslav Republic of Macedonia', '马其顿王国', 'MK', '389', '1');
INSERT INTO `smi_country` VALUES ('214', 'Togo', '多哥', 'TG', '228', '1');
INSERT INTO `smi_country` VALUES ('215', 'Tokelau', '托克劳群岛', 'TK', '690', '1');
INSERT INTO `smi_country` VALUES ('216', 'Tonga', '汤加', 'TO', '676', '1');
INSERT INTO `smi_country` VALUES ('217', 'Trinidad and Tobago', '特立尼达和多巴哥', 'TT', '1-868', '1');
INSERT INTO `smi_country` VALUES ('218', 'Tunisia', '突尼斯', 'TN', '216', '1');
INSERT INTO `smi_country` VALUES ('219', 'Turkey', '土耳其', 'TR', '90', '1');
INSERT INTO `smi_country` VALUES ('220', 'Turkmenistan', '土库曼斯坦', 'TM', '993', '1');
INSERT INTO `smi_country` VALUES ('221', 'Turks and Caicos Islands', '特克斯和凯科斯群岛', 'TC', '1-649', '1');
INSERT INTO `smi_country` VALUES ('222', 'Tuvalu', '图瓦卢', 'TV', '688', '1');
INSERT INTO `smi_country` VALUES ('223', 'Uganda', '乌干达', 'UG', '256', '1');
INSERT INTO `smi_country` VALUES ('224', 'Ukraine', '乌克兰', 'UA', '380', '1');
INSERT INTO `smi_country` VALUES ('225', 'United Arab Emirates', '阿拉伯联合酋长国', 'AE', '971', '1');
INSERT INTO `smi_country` VALUES ('226', 'United Kingdom', '英国', 'UK', '44', '1');
INSERT INTO `smi_country` VALUES ('227', 'United States', '美国', 'US', '1', '1');
INSERT INTO `smi_country` VALUES ('228', 'United States Minor Outlying Islands', '', 'UM', '', '0');
INSERT INTO `smi_country` VALUES ('229', 'Uruguay', '乌拉圭', 'UY', '598', '1');
INSERT INTO `smi_country` VALUES ('230', 'Uzbekistan', '乌兹别克斯坦', 'UZ', '998', '1');
INSERT INTO `smi_country` VALUES ('231', 'Vanuatu', '瓦努阿图', 'VU', '678', '1');
INSERT INTO `smi_country` VALUES ('232', 'Vatican City State (Holy See)', '梵蒂冈城国', 'VA', '39', '1');
INSERT INTO `smi_country` VALUES ('233', 'Venezuela', '委内瑞拉', 'VE', '58', '1');
INSERT INTO `smi_country` VALUES ('234', 'Vietnam', '越南', 'VN', '84', '1');
INSERT INTO `smi_country` VALUES ('235', 'Virgin Islands (British)', '英属维京群岛', 'VG', '1284', '1');
INSERT INTO `smi_country` VALUES ('236', 'Virgin Islands (U.S.)', '美属维尔京群岛', 'VI', '1340', '1');
INSERT INTO `smi_country` VALUES ('237', 'Wallis And Futuna Islands', '瓦利斯和富图纳群岛', 'WF', '681', '1');
INSERT INTO `smi_country` VALUES ('238', 'Western Sahara', '西撒哈拉', 'EH', '685', '1');
INSERT INTO `smi_country` VALUES ('239', 'Yemen', '也门', 'YE', '967', '1');
INSERT INTO `smi_country` VALUES ('240', 'Yugoslavia', '南斯拉夫', 'YU', '381', '1');
INSERT INTO `smi_country` VALUES ('241', 'Zambia', '赞比亚', 'ZM', '260', '1');
INSERT INTO `smi_country` VALUES ('242', 'Zimbabwe', '津巴布韦', 'ZW', '263', '1');

-- -----------------------------
-- Table structure for `smi_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `smi_coupon`;
CREATE TABLE `smi_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon` varchar(16) NOT NULL,
  `coupon_rule_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `batch` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `use_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupon` (`coupon`),
  KEY `coupon_rule_id` (`coupon_rule_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='优惠券表';

-- -----------------------------
-- Records of `smi_coupon`
-- -----------------------------
INSERT INTO `smi_coupon` VALUES ('1', '100000000', '1', '2', '1', '1', '0');
INSERT INTO `smi_coupon` VALUES ('2', 'X7CESRZPT9M5N', '2', '0', '1', '1', '0');

-- -----------------------------
-- Table structure for `smi_coupon_limitation`
-- -----------------------------
DROP TABLE IF EXISTS `smi_coupon_limitation`;
CREATE TABLE `smi_coupon_limitation` (
  `coupon_rule_id` int(11) NOT NULL,
  `limit_type` smallint(6) NOT NULL,
  `object_id` int(11) NOT NULL,
  KEY `coupon_rule_id` (`coupon_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_coupon_limitation`
-- -----------------------------
INSERT INTO `smi_coupon_limitation` VALUES ('1', '2', '1');

-- -----------------------------
-- Table structure for `smi_coupon_rule`
-- -----------------------------
DROP TABLE IF EXISTS `smi_coupon_rule`;
CREATE TABLE `smi_coupon_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_rule` varchar(128) NOT NULL,
  `coupon_alias` varchar(128) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `coupon_type` tinyint(1) NOT NULL,
  `min_amount` decimal(11,2) NOT NULL,
  `discount_amount` decimal(11,2) NOT NULL,
  `discount_rate` decimal(3,1) NOT NULL,
  `target_type` tinyint(1) NOT NULL,
  `target_object` text NOT NULL,
  `limit_type` tinyint(1) NOT NULL,
  `total_batch` smallint(6) NOT NULL,
  `remark` varchar(128) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='优惠券规则表';

-- -----------------------------
-- Records of `smi_coupon_rule`
-- -----------------------------
INSERT INTO `smi_coupon_rule` VALUES ('1', '满200减10', '满200减10', '1415584603', '1415635199', '2', '200.00', '10.00', '80.0', '3', '1', '2', '1', '测试', '1');
INSERT INTO `smi_coupon_rule` VALUES ('2', '推广派发优惠券', '传单式', '1415609045', '1415635199', '1', '200.00', '10.00', '0.0', '4', '', '1', '1', '', '1');

-- -----------------------------
-- Table structure for `smi_goods`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods`;
CREATE TABLE `smi_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_sno` varchar(64) NOT NULL,
  `goods` varchar(128) DEFAULT NULL,
  `short_name` varchar(128) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `original_price` decimal(11,2) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `image` varchar(128) NOT NULL,
  `category_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `specification` text NOT NULL,
  `default_product` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods`
-- -----------------------------
INSERT INTO `smi_goods` VALUES ('1', 'sno000', 'testse', 'vice title', '6', '20.00', '10.00', '/Uploads/Goods/2014-11-18/546b17f1bbc5e.png_thumb.png', '2', '1', '[{\"id\":\"1\",\"spec\":\"\\u989c\\u82721\",\"display\":\"0\",\"_list\":{\"1\":{\"id\":\"1\",\"pvt_val\":\"\\u9ed1\",\"pvt_img\":\"\\/Uploads\\/Spec\\/2014-10-24\\/544a19c50ab7b.jpg\"},\"2\":{\"id\":\"2\",\"pvt_val\":\"\\u767d\",\"pvt_img\":\"\\/Uploads\\/Spec\\/2014-10-22\\/5447841cda655.gif\"},\"5\":{\"id\":\"5\",\"pvt_val\":\"\\u7ea2\",\"pvt_img\":\"\\/Uploads\\/Spec\\/2014-10-23\\/5448c4d90c596.jpg\"}}},{\"id\":\"2\",\"spec\":\"\\u5c3a\\u5bf8\",\"display\":\"1\",\"_list\":{\"6\":{\"id\":\"6\",\"pvt_val\":\"XXS\"},\"7\":{\"id\":\"7\",\"pvt_val\":\"XS\"}}}]', '18', '1');
INSERT INTO `smi_goods` VALUES ('2', 'sno1', 'sadf', 'vice title', '4', '10.00', '10.20', '/Uploads/Goods/2014-11-19/546c006d6892a.jpg_thumb.jpg', '2', '0', '', '20', '1');
INSERT INTO `smi_goods` VALUES ('3', 'test11', 'test', 'tste', '0', '20.00', '10.30', '/Uploads/Goods/2014-11-19/546c0b7fa7c8a.jpg_thumb.jpg', '3', '1', '', '26', '1');
INSERT INTO `smi_goods` VALUES ('4', 'A22222', 'test test r', 'esetr ', '10', '50.00', '30.00', '/Uploads/Goods/2014-11-19/546bff82b72cb.jpg_thumb.jpg', '2', '2', '', '27', '1');

-- -----------------------------
-- Table structure for `smi_goods_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_attribute`;
CREATE TABLE `smi_goods_attribute` (
  `goods_id` int(11) NOT NULL,
  `attr_val_id` int(11) NOT NULL,
  PRIMARY KEY (`goods_id`,`attr_val_id`),
  KEY `goods_id_2` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品-属性值中间表';

-- -----------------------------
-- Records of `smi_goods_attribute`
-- -----------------------------
INSERT INTO `smi_goods_attribute` VALUES ('1', '2');
INSERT INTO `smi_goods_attribute` VALUES ('1', '5');
INSERT INTO `smi_goods_attribute` VALUES ('3', '2');
INSERT INTO `smi_goods_attribute` VALUES ('3', '7');
INSERT INTO `smi_goods_attribute` VALUES ('4', '4');

-- -----------------------------
-- Table structure for `smi_goods_category`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_category`;
CREATE TABLE `smi_goods_category` (
  `goods_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `is_primary` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`goods_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods_category`
-- -----------------------------
INSERT INTO `smi_goods_category` VALUES ('1', '2', '1');
INSERT INTO `smi_goods_category` VALUES ('1', '3', '0');
INSERT INTO `smi_goods_category` VALUES ('1', '4', '0');
INSERT INTO `smi_goods_category` VALUES ('2', '2', '1');
INSERT INTO `smi_goods_category` VALUES ('3', '3', '1');
INSERT INTO `smi_goods_category` VALUES ('4', '2', '1');

-- -----------------------------
-- Table structure for `smi_goods_description`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_description`;
CREATE TABLE `smi_goods_description` (
  `goods_id` int(11) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods_description`
-- -----------------------------
INSERT INTO `smi_goods_description` VALUES ('1', '<p>test sss</p>\r\n');
INSERT INTO `smi_goods_description` VALUES ('2', '<p>sdfad</p>\r\n');
INSERT INTO `smi_goods_description` VALUES ('3', '<p>test</p>\r\n');
INSERT INTO `smi_goods_description` VALUES ('4', '<p>dsafd</p>\r\n');

-- -----------------------------
-- Table structure for `smi_goods_image`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_image`;
CREATE TABLE `smi_goods_image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `origin_image` varchar(128) NOT NULL,
  `big_image` varchar(128) NOT NULL,
  `thumb_image` varchar(128) NOT NULL,
  `small_image` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  PRIMARY KEY (`image_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods_image`
-- -----------------------------
INSERT INTO `smi_goods_image` VALUES ('5', '1', '/Uploads/Goods/2014-11-18/546b17f1bbc5e.png', '/Uploads/Goods/2014-11-18/546b17f1bbc5e.png_big.png', '/Uploads/Goods/2014-11-18/546b17f1bbc5e.png_thumb.png', '/Uploads/Goods/2014-11-18/546b17f1bbc5e.png_small.png', '0');
INSERT INTO `smi_goods_image` VALUES ('6', '1', '/Uploads/Goods/2014-11-18/546b1bcb8a59a.jpg', '/Uploads/Goods/2014-11-18/546b1bcb8a59a.jpg_big.jpg', '/Uploads/Goods/2014-11-18/546b1bcb8a59a.jpg_thumb.jpg', '/Uploads/Goods/2014-11-18/546b1bcb8a59a.jpg_small.jpg', '1');
INSERT INTO `smi_goods_image` VALUES ('7', '4', '/Uploads/Goods/2014-11-19/546bff82b72cb.jpg', '/Uploads/Goods/2014-11-19/546bff82b72cb.jpg_big.jpg', '/Uploads/Goods/2014-11-19/546bff82b72cb.jpg_thumb.jpg', '/Uploads/Goods/2014-11-19/546bff82b72cb.jpg_small.jpg', '0');
INSERT INTO `smi_goods_image` VALUES ('8', '2', '/Uploads/Goods/2014-11-19/546c006d6892a.jpg', '/Uploads/Goods/2014-11-19/546c006d6892a.jpg_big.jpg', '/Uploads/Goods/2014-11-19/546c006d6892a.jpg_thumb.jpg', '/Uploads/Goods/2014-11-19/546c006d6892a.jpg_small.jpg', '0');
INSERT INTO `smi_goods_image` VALUES ('9', '3', '/Uploads/Goods/2014-11-19/546c0b7fa7c8a.jpg', '/Uploads/Goods/2014-11-19/546c0b7fa7c8a.jpg_big.jpg', '/Uploads/Goods/2014-11-19/546c0b7fa7c8a.jpg_thumb.jpg', '/Uploads/Goods/2014-11-19/546c0b7fa7c8a.jpg_small.jpg', '0');

-- -----------------------------
-- Table structure for `smi_letter`
-- -----------------------------
DROP TABLE IF EXISTS `smi_letter`;
CREATE TABLE `smi_letter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `cc_addr` varchar(128) NOT NULL,
  `bcc_addr` varchar(128) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='邮件模板';

-- -----------------------------
-- Records of `smi_letter`
-- -----------------------------
INSERT INTO `smi_letter` VALUES ('1', '测试邮件模板', '测试主题', '<p>TEST</p>\r\n', '', '', '', '1413193240');

-- -----------------------------
-- Table structure for `smi_member`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member`;
CREATE TABLE `smi_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(128) NOT NULL,
  `pwd` varchar(64) NOT NULL,
  `level_id` smallint(6) NOT NULL,
  `username` varchar(32) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `smi_member`
-- -----------------------------
INSERT INTO `smi_member` VALUES ('2', 'xsp@foxmail.com', '$1$kO1.dY/.$uEAE2MjebpFOqcsVjVs8p1', '1', 'xsp', '1');

-- -----------------------------
-- Table structure for `smi_member_address`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_address`;
CREATE TABLE `smi_member_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) NOT NULL,
  `truename` varchar(128) NOT NULL,
  `country_id` mediumint(9) NOT NULL,
  `province_id` mediumint(9) NOT NULL,
  `city_id` mediumint(9) NOT NULL,
  `zone_id` mediumint(9) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(16) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='会员-联系信息表';

-- -----------------------------
-- Records of `smi_member_address`
-- -----------------------------
INSERT INTO `smi_member_address` VALUES ('2', '2', '小号', '0', '2197', '2198', '2202', 'XX市XX区XX路XX号', '123432132', 'asdfsadasd', 'fsadfsa', '1');
INSERT INTO `smi_member_address` VALUES ('3', '2', 'oililoiu', '0', '1', '2', '4', 'fsdgsdfg', 'asd', 'iololiol', 'liliol', '0');

-- -----------------------------
-- Table structure for `smi_member_hashcode`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_hashcode`;
CREATE TABLE `smi_member_hashcode` (
  `member_id` int(11) NOT NULL,
  `hash_type` int(11) NOT NULL COMMENT '0注册1找回密码',
  `hash_code` varchar(64) NOT NULL,
  `hash_time` int(11) NOT NULL,
  PRIMARY KEY (`member_id`,`hash_type`),
  KEY `hash_code` (`hash_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员验证表';


-- -----------------------------
-- Table structure for `smi_member_info`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_info`;
CREATE TABLE `smi_member_info` (
  `member_id` int(11) NOT NULL,
  `register_time` int(11) NOT NULL,
  `register_ip` varchar(15) NOT NULL,
  `active_time` int(11) NOT NULL,
  `login_time` int(11) NOT NULL,
  `login_ip` varchar(15) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员信息表';

-- -----------------------------
-- Records of `smi_member_info`
-- -----------------------------
INSERT INTO `smi_member_info` VALUES ('2', '1415167810', '127.0.0.1', '1415167810', '0', '', 'aa');

-- -----------------------------
-- Table structure for `smi_member_level`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_level`;
CREATE TABLE `smi_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_level` varchar(64) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员等级表';

-- -----------------------------
-- Records of `smi_member_level`
-- -----------------------------
INSERT INTO `smi_member_level` VALUES ('1', '普通会员', '很普通');
INSERT INTO `smi_member_level` VALUES ('2', '高级会员', '很高级');

-- -----------------------------
-- Table structure for `smi_node`
-- -----------------------------
DROP TABLE IF EXISTS `smi_node`;
CREATE TABLE `smi_node` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `title_cn` varchar(50) DEFAULT NULL,
  `title_en` varchar(128) NOT NULL,
  `show_top` tinyint(1) NOT NULL COMMENT '顶部显示',
  `status` tinyint(1) NOT NULL,
  `sort` smallint(6) NOT NULL COMMENT '排序',
  `pid` smallint(6) NOT NULL COMMENT '上级ID',
  `route` varchar(128) NOT NULL COMMENT '结构1-2-3',
  `grade` tinyint(1) NOT NULL COMMENT '级别1大组2小组3模块4操作',
  `remark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`grade`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=303 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_node`
-- -----------------------------
INSERT INTO `smi_node` VALUES ('1', '', '后台面板', 'Panel', '0', '0', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('2', '', '默认组', 'Default', '0', '0', '0', '1', '0,1', '2', '');
INSERT INTO `smi_node` VALUES ('3', 'Index', '控制面板管理', 'Panel', '0', '0', '0', '2', '0,1,2', '3', '');
INSERT INTO `smi_node` VALUES ('4', 'index', '首页', 'home', '0', '0', '0', '3', '0,1,2,3', '4', '');
INSERT INTO `smi_node` VALUES ('5', 'phpinfo', '系统信息', 'System Info', '0', '0', '0', '3', '0,1,2,3', '4', '');
INSERT INTO `smi_node` VALUES ('6', '', '个人信息组', 'Profiles', '0', '0', '0', '1', '0,1', '2', '');
INSERT INTO `smi_node` VALUES ('7', 'Profile', '个人信息管理', 'Profile', '0', '0', '0', '6', '0,1,6', '3', '');
INSERT INTO `smi_node` VALUES ('8', 'edit', '个人信息', 'edit profile', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('9', 'update', '更新个人信息', 'update profile', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('10', 'editPwd', '修改密码', 'edit password', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('11', 'updatePwd', '更新密码', 'update password', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('12', '', '系统', 'System', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('13', '', '权限组', 'Privileges', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('14', 'Node', '权限管理', 'Nodes', '0', '1', '0', '13', '0,12,13', '3', '');
INSERT INTO `smi_node` VALUES ('15', 'index', '权限列表', 'Node List', '0', '1', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('16', 'add', '新增权限', 'add Node', '0', '1', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('17', 'insert', '插入权限', 'insert', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('18', 'edit', '编辑权限', 'edit', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('19', 'update', '更新权限', 'update', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('20', 'addController', '添加控制器权限', 'Add Controller', '0', '1', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('21', 'insertController', '插入控制器权限', 'insert Controller', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('22', 'sort', '排序权限', 'sort', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('23', 'setStatus', '设置状态', 'set status', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('24', '', '管理员组', 'Administrators', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('25', 'Role', '角色', 'Roles', '0', '1', '0', '24', '0,12,24', '3', '');
INSERT INTO `smi_node` VALUES ('26', 'index', '角色列表', 'Role List', '0', '1', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('27', 'add', '新增角色', 'Add Role', '0', '1', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('28', 'insert', '插入角色', 'insert', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('29', 'edit', '编辑角色', 'edit', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('30', 'update', '更新角色', 'update', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('31', 'delete', '删除角色', 'delete', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('32', 'setStatus', '设置状态', 'set status', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('33', 'sort', '排序角色', 'sort', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('34', 'privilege', '设置权限', 'set privilege', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('35', 'setPrivilege', '完成权限设置', 'update privilege', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('36', 'User', '管理员', 'Administrator', '0', '1', '0', '24', '0,12,24', '3', '');
INSERT INTO `smi_node` VALUES ('37', 'index', '管理员列表', 'Admin List', '0', '1', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('38', 'add', '新增管理员', 'Add Admin', '0', '1', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('39', 'insert', '插入管理员', 'insert', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('40', 'edit', '编辑管理员', 'edit', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('41', 'update', '更新管理员', 'update', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('42', 'delete', '删除管理员', 'delete', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('43', 'search', '搜索管理员', 'search', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('44', 'setStatus', '设置状态', 'set status', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('45', 'sort', '排序管理员', 'sort', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('46', 'editPwd', '修改密码', 'edit password', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('47', 'updatePwd', '更新密码', 'update password', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('48', '', '站点配置组', 'Settings', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('49', 'Config', '网站配置', 'Website', '0', '1', '0', '48', '0,12,48', '3', '');
INSERT INTO `smi_node` VALUES ('50', 'index', '网站配置列表', 'General Setting', '0', '1', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('51', 'add', '新增网站配置', 'Add', '0', '1', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('52', 'insert', '插入网站配置', 'insert', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('53', 'edit', '编辑网站配置', 'edit', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('54', 'update', '更新网站配置', 'update', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('55', 'delete', '删除网站配置', 'delete', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('56', 'sort', '排序网站配置', 'sort', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('57', 'setting', '网站配置', 'setting', '0', '1', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('58', 'updateSetting', '更新网站配置', 'update setting', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('59', '', '编辑器组', 'Editors', '0', '0', '0', '1', '0,1', '2', '');
INSERT INTO `smi_node` VALUES ('60', 'Editor', '编辑器', 'Editor', '0', '0', '0', '59', '0,1,59', '3', '');
INSERT INTO `smi_node` VALUES ('61', 'elfinder', 'Elfinder编辑器', 'Elfinder Editor', '0', '0', '0', '60', '0,1,59,60', '4', '');
INSERT INTO `smi_node` VALUES ('62', 'connectElfinder', '连接Elfinder', 'Connect Elfinder', '0', '0', '0', '60', '0,1,59,60', '4', '');
INSERT INTO `smi_node` VALUES ('63', '', '数据库组', 'Databases', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('64', 'Database', '数据库', 'Database', '0', '1', '0', '63', '0,12,63', '3', '');
INSERT INTO `smi_node` VALUES ('65', 'index', '查看数据表', 'Table List', '0', '1', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('66', 'export', '导出数据库', 'Export', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('67', 'optimize', '优化数据表', 'Optimize', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('68', 'repair', '修复数据表', 'Repair', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('69', 'backups', '查看备份', 'Backup List', '0', '1', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('70', 'recover', '恢复数据库', 'Recover', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('71', '-', '内容', 'Content', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('72', '-', '页面组', 'Pages', '0', '1', '0', '71', '0,71', '2', '');
INSERT INTO `smi_node` VALUES ('73', 'Page', '页面', 'Page', '0', '1', '0', '72', '0,71,72', '3', '');
INSERT INTO `smi_node` VALUES ('74', 'index', '页面列表', 'Page List', '0', '1', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('75', 'add', '新增页面', 'Add Page', '0', '1', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('76', 'insert', '插入', 'Insert', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('77', 'edit', '编辑', 'Edit', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('78', 'update', '更新', 'Update', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('79', 'delete', '删除', 'Delete', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('80', 'search', '搜索', 'Search', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('81', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('82', 'sort', '排序', 'Sort', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('83', '', '广告组', 'Models', '0', '1', '0', '71', '0,71', '2', '');
INSERT INTO `smi_node` VALUES ('84', 'PosterSpace', '广告位', 'Poster Spaces', '0', '1', '0', '83', '0,71,83', '3', '');
INSERT INTO `smi_node` VALUES ('85', 'index', '广告位列表', 'Poster Spaces List', '0', '1', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('86', 'add', '新增广告位', 'Add Poster Spaces', '0', '1', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('87', 'insert', '插入', 'Insert', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('88', 'edit', '编辑', 'Edit', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('89', 'update', '更新', 'Update', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('90', 'delete', '删除', 'Delete', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('91', 'search', '搜索', 'Search', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('92', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('93', 'sort', '排序', 'Sort', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('94', 'Poster', '广告', 'Posters', '0', '0', '0', '83', '0,71,83', '3', '');
INSERT INTO `smi_node` VALUES ('95', 'index', '广告列表', 'Posters List', '0', '1', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('96', 'add', '新增广告', 'Add Posters', '0', '1', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('97', 'insert', '插入', 'Insert', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('98', 'edit', '编辑', 'Edit', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('99', 'update', '更新', 'Update', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('100', 'delete', '删除', 'Delete', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('101', 'search', '搜索', 'Search', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('102', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('103', 'sort', '排序', 'Sort', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('104', '', '邮件模板组', 'Letters', '0', '1', '0', '71', '0,71', '2', '');
INSERT INTO `smi_node` VALUES ('105', 'Letter', '邮件模板', 'Letter', '0', '1', '0', '104', '0,71,104', '3', '');
INSERT INTO `smi_node` VALUES ('106', 'index', '邮件模板列表', 'Letter List', '0', '1', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('107', 'add', '新增邮件模板', 'Add Letter', '0', '1', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('108', 'insert', '插入', 'Insert', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('109', 'edit', '编辑', 'Edit', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('110', 'update', '更新', 'Update', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('111', 'delete', '删除', 'Delete', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('112', 'search', '搜索', 'Search', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('113', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('114', 'sort', '排序', 'Sort', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('115', '', '产品', 'Products', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('116', '', '分类组', 'Categories', '0', '1', '0', '115', '0,115', '2', '');
INSERT INTO `smi_node` VALUES ('117', 'Category', '分类', 'Category', '0', '1', '0', '116', '0,115,116', '3', '');
INSERT INTO `smi_node` VALUES ('118', 'index', '分类列表', 'Category List', '0', '1', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('119', 'add', '新增分类', 'Add Category', '0', '1', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('120', 'insert', '插入', 'Insert', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('121', 'edit', '编辑', 'Edit', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('122', 'update', '更新', 'Update', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('123', 'delete', '删除', 'Delete', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('124', 'search', '搜索', 'Search', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('125', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('126', 'sort', '排序', 'Sort', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('127', '', '产品组', 'Products', '0', '1', '0', '115', '0,115', '2', '');
INSERT INTO `smi_node` VALUES ('128', 'Goods', '产品', 'Goods', '0', '1', '0', '127', '0,115,127', '3', '');
INSERT INTO `smi_node` VALUES ('129', 'index', '产品列表', 'Goods List', '0', '1', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('130', 'add', '新增产品', 'Add Goods', '0', '1', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('131', 'insert', '插入', 'Insert', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('132', 'edit', '编辑', 'Edit', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('133', 'update', '更新', 'Update', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('134', 'delete', '删除', 'Delete', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('135', 'search', '搜索', 'Search', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('136', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('137', 'sort', '排序', 'Sort', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('138', '', '扩展组', 'Extends', '0', '1', '0', '115', '0,115', '2', '');
INSERT INTO `smi_node` VALUES ('139', 'Spec', '规格', 'Specification', '0', '1', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('140', 'index', '产品规格', 'Specification List', '0', '1', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('141', 'add', '新增产品规格', 'Add Specification', '0', '1', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('142', 'insert', '插入', 'Insert', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('143', 'edit', '编辑', 'Edit', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('144', 'update', '更新', 'Update', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('145', 'delete', '删除', 'Delete', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('146', 'search', '搜索', 'Search', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('147', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('148', 'sort', '排序', 'Sort', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('149', 'SpecValue', '规格值', 'Spec Values', '0', '0', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('150', 'add', '新增规格值', 'Add Spec Values', '0', '1', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('151', 'insert', '插入', 'Insert', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('152', 'edit', '编辑', 'Edit', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('153', 'update', '更新', 'Update', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('154', 'delete', '删除', 'Delete', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('155', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('156', 'sort', '排序', 'Sort', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('157', 'Attribute', '产品属性', 'Attribute', '0', '1', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('158', 'index', '产品属性', 'Attribute List', '0', '1', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('159', 'add', '新增产品属性', 'Add Attribute', '0', '1', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('160', 'insert', '插入', 'Insert', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('161', 'edit', '编辑', 'Edit', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('162', 'update', '更新', 'Update', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('163', 'delete', '删除', 'Delete', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('164', 'search', '搜索', 'Search', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('165', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('166', 'sort', '排序', 'Sort', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('167', 'AttributeValue', '产品属性值', 'AttributeValue', '0', '0', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('168', 'index', '产品属性值列表', 'AttributeValue List', '0', '1', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('169', 'add', '新增产品属性值', 'Add AttributeValue', '0', '1', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('170', 'insert', '插入', 'Insert', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('171', 'edit', '编辑', 'Edit', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('172', 'update', '更新', 'Update', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('173', 'delete', '删除', 'Delete', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('174', 'search', '搜索', 'Search', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('175', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('176', 'sort', '排序', 'Sort', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('177', 'Type', '产品类型', 'ProductType', '0', '1', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('178', 'index', '产品类型', 'ProductType List', '0', '1', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('179', 'add', '新增产品类型', 'Add ProductType', '0', '1', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('180', 'insert', '插入', 'Insert', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('181', 'edit', '编辑', 'Edit', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('182', 'update', '更新', 'Update', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('183', 'delete', '删除', 'Delete', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('184', 'search', '搜索', 'Search', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('185', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('186', 'sort', '排序', 'Sort', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('187', 'recycle', '放入回收站', 'Recycle', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('188', 'recyclebin', '产品回收站', 'RecycleBin', '0', '1', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('189', '', '会员', 'Member', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('190', '', '会员组', 'Members', '0', '1', '0', '189', '0,189', '2', '');
INSERT INTO `smi_node` VALUES ('191', 'Member', '会员', 'Member', '0', '1', '0', '190', '0,189,190', '3', '');
INSERT INTO `smi_node` VALUES ('192', 'index', '会员列表', 'Member List', '0', '1', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('193', 'add', '新增会员', 'Add Member', '0', '1', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('194', 'insert', '插入', 'Insert', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('195', 'edit', '编辑', 'Edit', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('196', 'update', '更新', 'Update', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('197', 'delete', '删除', 'Delete', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('198', 'search', '搜索', 'Search', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('199', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('200', 'sort', '排序', 'Sort', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('201', '', '扩展组', 'Extends', '0', '1', '0', '189', '0,189', '2', '');
INSERT INTO `smi_node` VALUES ('202', 'MemberLevel', '会员等级', 'MemberLevel', '0', '1', '0', '201', '0,189,201', '3', '');
INSERT INTO `smi_node` VALUES ('203', 'index', '会员等级列表', 'MemberLevel List', '0', '1', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('204', 'add', '新增会员等级', 'Add MemberLevel', '0', '1', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('205', 'insert', '插入', 'Insert', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('206', 'edit', '编辑', 'Edit', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('207', 'update', '更新', 'Update', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('208', 'delete', '删除', 'Delete', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('209', 'search', '搜索', 'Search', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('210', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('211', 'sort', '排序', 'Sort', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('212', 'modifypwd', '修改密码', 'ModifyPassword', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('213', 'updatepwd', '更新密码', 'UpdatePassword', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('214', '', '订单', 'Order', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('215', '', '运营', 'Sales', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('216', '', '促销推广组', 'Promotions', '0', '1', '0', '215', '0,215', '2', '');
INSERT INTO `smi_node` VALUES ('217', 'Promotion', '促销活动', 'Promotion', '0', '1', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('218', 'index', '促销活动列表', 'Promotion List', '0', '1', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('219', 'add', '新增促销活动', 'Add Promotion', '0', '1', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('220', 'insert', '插入', 'Insert', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('221', 'edit', '编辑', 'Edit', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('222', 'update', '更新', 'Update', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('223', 'delete', '删除', 'Delete', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('224', 'search', '搜索', 'Search', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('225', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('226', 'sort', '排序', 'Sort', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('227', 'PromotionRule', '促销活动规则', 'PromotionRule', '0', '0', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('228', 'index', '促销活动规则列表', 'PromotionRule List', '0', '1', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('229', 'add', '新增促销活动规则', 'Add PromotionRule', '0', '1', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('230', 'insert', '插入', 'Insert', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('231', 'edit', '编辑', 'Edit', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('232', 'update', '更新', 'Update', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('233', 'delete', '删除', 'Delete', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('234', 'search', '搜索', 'Search', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('235', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('236', 'sort', '排序', 'Sort', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('237', 'products', '调取产品', 'GetProducts', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('238', 'CouponRule', '优惠券规则', 'CouponRule', '0', '1', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('239', 'index', '优惠券规则列表', 'CouponRule List', '0', '1', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('240', 'add', '新增优惠券规则', 'Add CouponRule', '0', '1', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('241', 'insert', '插入', 'Insert', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('242', 'edit', '编辑', 'Edit', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('243', 'update', '更新', 'Update', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('244', 'delete', '删除', 'Delete', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('245', 'search', '搜索', 'Search', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('246', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('247', 'sort', '排序', 'Sort', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('248', 'Coupon', '优惠券', 'Coupon', '0', '0', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('249', 'index', '优惠券列表', 'Coupon List', '0', '1', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('250', 'add', '新增优惠券', 'Add Coupon', '0', '1', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('251', 'insert', '插入', 'Insert', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('252', 'edit', '编辑', 'Edit', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('253', 'update', '更新', 'Update', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('254', 'delete', '删除', 'Delete', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('255', 'search', '搜索', 'Search', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('256', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('257', 'sort', '排序', 'Sort', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('258', 'Region', '地区', 'Regions', '0', '1', '0', '201', '0,189,201', '3', '');
INSERT INTO `smi_node` VALUES ('259', 'index', '地区列表', 'Regions List', '0', '1', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('260', 'add', '新增地区', 'Add Regions', '0', '1', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('261', 'insert', '插入', 'Insert', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('262', 'edit', '编辑', 'Edit', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('263', 'update', '更新', 'Update', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('264', 'delete', '删除', 'Delete', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('265', 'search', '搜索', 'Search', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('266', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('267', 'sort', '排序', 'Sort', '0', '0', '0', '258', '0,189,201,258', '4', '');
INSERT INTO `smi_node` VALUES ('268', 'MemberAddress', '会员地址', 'MemberAddress', '0', '0', '0', '190', '0,189,190', '3', '');
INSERT INTO `smi_node` VALUES ('269', 'index', '会员地址列表', 'MemberAddress List', '0', '1', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('270', 'add', '新增会员地址', 'Add MemberAddress', '0', '1', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('271', 'insert', '插入', 'Insert', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('272', 'edit', '编辑', 'Edit', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('273', 'update', '更新', 'Update', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('274', 'delete', '删除', 'Delete', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('275', 'search', '搜索', 'Search', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('276', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('277', 'sort', '排序', 'Sort', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('278', 'getregions', '获取省市区', 'GetRegion', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('279', 'reloadaddress', '重新加载会员地址', 'ReloadAddress', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('280', '', '订单组', 'Orders', '0', '1', '0', '214', '0,214', '2', '');
INSERT INTO `smi_node` VALUES ('281', 'Order', '订单', 'Order', '0', '1', '0', '280', '0,214,280', '3', '');
INSERT INTO `smi_node` VALUES ('282', 'index', '订单列表', 'Order List', '0', '1', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('283', 'add', '新增订单', 'Add Order', '0', '1', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('284', 'insert', '插入', 'Insert', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('285', 'edit', '编辑', 'Edit', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('286', 'update', '更新', 'Update', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('287', 'delete', '删除', 'Delete', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('288', 'search', '搜索', 'Search', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('289', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('290', 'sort', '排序', 'Sort', '0', '0', '0', '281', '0,214,280,281', '4', '');
INSERT INTO `smi_node` VALUES ('291', '', '扩展组', 'Extends', '0', '1', '0', '214', '0,214', '2', '');
INSERT INTO `smi_node` VALUES ('292', 'OrderStatus', '订单状态', 'OrderStatus', '0', '1', '0', '291', '0,214,291', '3', '');
INSERT INTO `smi_node` VALUES ('293', 'index', '订单状态列表', 'OrderStatus List', '0', '1', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('294', 'add', '新增订单状态', 'Add OrderStatus', '0', '1', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('295', 'insert', '插入', 'Insert', '0', '0', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('296', 'edit', '编辑', 'Edit', '0', '0', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('297', 'update', '更新', 'Update', '0', '0', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('298', 'delete', '删除', 'Delete', '0', '0', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('299', 'search', '搜索', 'Search', '0', '0', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('300', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '292', '0,214,291,292', '4', '');
INSERT INTO `smi_node` VALUES ('301', 'ajaxreloadregion', 'AJAX加载省市区', 'AJAXLoadRegion', '0', '0', '0', '268', '0,189,190,268', '4', '');
INSERT INTO `smi_node` VALUES ('302', 'ajaxgetproducts', '读取产品', 'GetProducts', '0', '0', '0', '281', '0,214,280,281', '4', '');

-- -----------------------------
-- Table structure for `smi_order`
-- -----------------------------
DROP TABLE IF EXISTS `smi_order`;
CREATE TABLE `smi_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_code` varchar(32) NOT NULL,
  `member_id` int(11) NOT NULL,
  `cost_items` decimal(11,2) NOT NULL,
  `cost_shipping` decimal(11,2) NOT NULL,
  `coupon` varchar(16) NOT NULL,
  `discount_coupon` decimal(11,2) NOT NULL,
  `promotion` varchar(64) NOT NULL,
  `discount_promotion` decimal(11,2) NOT NULL,
  `discount` decimal(11,2) NOT NULL,
  `total_amount` decimal(11,2) NOT NULL,
  `integral` int(11) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `is_paid` tinyint(1) NOT NULL,
  `pay_method` smallint(6) NOT NULL,
  `pay_gateway` varchar(128) NOT NULL,
  `pay_time` int(11) NOT NULL,
  `pay_amount` decimal(11,2) NOT NULL,
  `express_id` int(11) NOT NULL,
  `express_name` varchar(64) NOT NULL,
  `express_bill` varchar(64) NOT NULL,
  `ship_time` int(11) NOT NULL,
  `need_invoice` tinyint(1) NOT NULL,
  `invoice_title` varchar(128) NOT NULL,
  `invoice_type` tinyint(1) NOT NULL,
  `order_status` tinyint(4) NOT NULL,
  `order_ip` varchar(15) NOT NULL,
  `order_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_code` (`order_code`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单表';


-- -----------------------------
-- Table structure for `smi_order_address`
-- -----------------------------
DROP TABLE IF EXISTS `smi_order_address`;
CREATE TABLE `smi_order_address` (
  `order_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `province_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `zone_id` int(11) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(16) NOT NULL,
  `truename` varchar(64) NOT NULL,
  `phone` varchar(32) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `member_id` (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单地址表';


-- -----------------------------
-- Table structure for `smi_order_items`
-- -----------------------------
DROP TABLE IF EXISTS `smi_order_items`;
CREATE TABLE `smi_order_items` (
  `order_id` int(11) NOT NULL,
  `order_code` varchar(32) NOT NULL,
  `member_id` int(11) NOT NULL,
  `goods_id` int(11) NOT NULL,
  `goods_sno` varchar(32) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `amount` smallint(6) NOT NULL,
  `extra` text NOT NULL,
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='订单产品表';


-- -----------------------------
-- Table structure for `smi_order_status`
-- -----------------------------
DROP TABLE IF EXISTS `smi_order_status`;
CREATE TABLE `smi_order_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_status_name` varchar(128) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='订单状态表';

-- -----------------------------
-- Records of `smi_order_status`
-- -----------------------------
INSERT INTO `smi_order_status` VALUES ('1', '新订单', '刚生成的订单');
INSERT INTO `smi_order_status` VALUES ('2', '已支付，待确认', '订单已经支付，未确认。一般支付系统会完成这一步，不会出现。');
INSERT INTO `smi_order_status` VALUES ('3', '待发货', '订单已支付或货到付款');
INSERT INTO `smi_order_status` VALUES ('4', '已发货', '货发出去了');
INSERT INTO `smi_order_status` VALUES ('5', '交易完成', '顾客收到货了');
INSERT INTO `smi_order_status` VALUES ('6', '已取消', '取消订单');

-- -----------------------------
-- Table structure for `smi_page`
-- -----------------------------
DROP TABLE IF EXISTS `smi_page`;
CREATE TABLE `smi_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `brief` varchar(255) NOT NULL,
  `seo_name` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `publish_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `page_title` varchar(128) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_name` (`seo_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_page`
-- -----------------------------
INSERT INTO `smi_page` VALUES ('1', 'teste', '<p>tsets</p>\r\n', 'tsets', 'test', '', '0', '1', '1413098100', '1413098160', '', '', '');

-- -----------------------------
-- Table structure for `smi_poster`
-- -----------------------------
DROP TABLE IF EXISTS `smi_poster`;
CREATE TABLE `smi_poster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `space_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `file` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `space_id` (`space_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='广告内容';

-- -----------------------------
-- Records of `smi_poster`
-- -----------------------------
INSERT INTO `smi_poster` VALUES ('2', '3', 'test0', 'http://www.baidu.com0', 'Poster/2014-10-25/544bc22b0d2aa.png', '0', '1');
INSERT INTO `smi_poster` VALUES ('3', '3', 'test2', '#2', 'Poster/2014-10-25/544bbf7261b28.png', '1', '0');
INSERT INTO `smi_poster` VALUES ('4', '3', 'aaa', '#2', 'Poster/2014-10-25/544bc055615df.png', '2', '1');
INSERT INTO `smi_poster` VALUES ('6', '3', 'sarerewrew', 'adfsadf', 'Poster/544bd605b7905.png', '3', '0');

-- -----------------------------
-- Table structure for `smi_poster_space`
-- -----------------------------
DROP TABLE IF EXISTS `smi_poster_space`;
CREATE TABLE `smi_poster_space` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `sort` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='广告位';

-- -----------------------------
-- Records of `smi_poster_space`
-- -----------------------------
INSERT INTO `smi_poster_space` VALUES ('3', '第一个广告位99', '', '0');

-- -----------------------------
-- Table structure for `smi_product`
-- -----------------------------
DROP TABLE IF EXISTS `smi_product`;
CREATE TABLE `smi_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `sku_sno` int(11) NOT NULL,
  `sku_data` varchar(255) NOT NULL,
  `sku_info` varchar(128) NOT NULL,
  `product_sno` varchar(128) NOT NULL,
  `stock` int(11) NOT NULL,
  `sku_images` varchar(128) NOT NULL,
  `is_onsale` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_product`
-- -----------------------------
INSERT INTO `smi_product` VALUES ('18', '1', '6', '{\"color\":\"\\u9ed1\",\"size\":\"XXS\"}', '黑,XXS', 'e', '5', '', '1');
INSERT INTO `smi_product` VALUES ('20', '2', '0', '', '', 'sno1', '4', '', '1');
INSERT INTO `smi_product` VALUES ('21', '1', '12', '{\"color\":\"\\u767d\",\"size\":\"XXS\"}', '白,XXS', 'r', '1', '', '1');
INSERT INTO `smi_product` VALUES ('22', '1', '30', '{\"color\":\"\\u7ea2\",\"size\":\"XXS\"}', '红,XXS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('23', '1', '7', '{\"color\":\"\\u9ed1\",\"size\":\"XS\"}', '黑,XS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('24', '1', '14', '{\"color\":\"\\u767d\",\"size\":\"XS\"}', '白,XS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('25', '1', '35', '{\"color\":\"\\u7ea2\",\"size\":\"XS\"}', '红,XS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('26', '3', '0', '', '', 'test11', '0', '', '1');
INSERT INTO `smi_product` VALUES ('27', '4', '0', '', '', 'A22222', '10', '', '1');

-- -----------------------------
-- Table structure for `smi_promotion`
-- -----------------------------
DROP TABLE IF EXISTS `smi_promotion`;
CREATE TABLE `smi_promotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion` varchar(128) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `remark` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='促销活动表';

-- -----------------------------
-- Records of `smi_promotion`
-- -----------------------------
INSERT INTO `smi_promotion` VALUES ('1', '测试活动一', '1415255629', '1415289599', 'test', '0', '1');

-- -----------------------------
-- Table structure for `smi_promotion_limitation`
-- -----------------------------
DROP TABLE IF EXISTS `smi_promotion_limitation`;
CREATE TABLE `smi_promotion_limitation` (
  `promotion_id` int(11) NOT NULL,
  `promotion_rule_id` int(11) NOT NULL,
  `limit_type` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  KEY `promotion_rule_id` (`promotion_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_promotion_limitation`
-- -----------------------------
INSERT INTO `smi_promotion_limitation` VALUES ('1', '2', '2', '1');

-- -----------------------------
-- Table structure for `smi_promotion_rule`
-- -----------------------------
DROP TABLE IF EXISTS `smi_promotion_rule`;
CREATE TABLE `smi_promotion_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `promotion_rule` varchar(128) NOT NULL,
  `promotion_rule_alias` varchar(64) NOT NULL,
  `min_amount` decimal(11,2) NOT NULL,
  `promote_type` tinyint(4) NOT NULL,
  `discount_amount` decimal(11,2) NOT NULL,
  `discount_rate` decimal(2,0) NOT NULL,
  `limit_type` tinyint(4) NOT NULL,
  `remark` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotion_id` (`promotion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='促销活动规则表';

-- -----------------------------
-- Records of `smi_promotion_rule`
-- -----------------------------
INSERT INTO `smi_promotion_rule` VALUES ('2', '1', '满200减100', '满200减100', '200.00', '1', '100.00', '0', '2', 'c', '0', '1');

-- -----------------------------
-- Table structure for `smi_region`
-- -----------------------------
DROP TABLE IF EXISTS `smi_region`;
CREATE TABLE `smi_region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_name` varchar(64) NOT NULL,
  `pid` int(11) NOT NULL,
  `grade` tinyint(4) NOT NULL,
  `route` varchar(16) NOT NULL,
  `sort` mediumint(9) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3723 DEFAULT CHARSET=utf8 COMMENT='全国地区表';

-- -----------------------------
-- Records of `smi_region`
-- -----------------------------
INSERT INTO `smi_region` VALUES ('1', '北京', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2', '北京市', '1', '2', '1', '0', '1');
INSERT INTO `smi_region` VALUES ('3', '东城区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('4', '西城区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('5', '崇文区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('6', '宣武区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('7', '朝阳区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('8', '丰台区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('9', '石景山区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('10', '海淀区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('11', '门头沟区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('12', '房山区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('13', '通州区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('14', '顺义区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('15', '昌平区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('16', '大兴区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('17', '怀柔区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('18', '平谷区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('19', '密云县', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('20', '延庆县', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('21', '其它区', '2', '3', '1,2', '0', '1');
INSERT INTO `smi_region` VALUES ('22', '天津', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('23', '天津市', '22', '2', '22', '0', '1');
INSERT INTO `smi_region` VALUES ('24', '和平区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('25', '河东区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('26', '河西区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('27', '南开区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('28', '河北区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('29', '红桥区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('30', '塘沽区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('31', '汉沽区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('32', '大港区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('33', '东丽区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('34', '西青区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('35', '津南区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('36', '北辰区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('37', '武清区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('38', '宝坻区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('39', '滨海新区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('40', '宁河县', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('41', '静海县', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('42', '蓟县', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('43', '其它区', '23', '3', '22,23', '0', '1');
INSERT INTO `smi_region` VALUES ('44', '河北省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('45', '石家庄市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('46', '长安区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('47', '桥东区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('48', '桥西区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('49', '新华区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('50', '井陉矿区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('51', '裕华区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('52', '井陉县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('53', '正定县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('54', '栾城县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('55', '行唐县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('56', '灵寿县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('57', '高邑县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('58', '深泽县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('59', '赞皇县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('60', '无极县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('61', '平山县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('62', '元氏县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('63', '赵县', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('64', '辛集市', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('65', '藁城市', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('66', '晋州市', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('67', '新乐市', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('68', '鹿泉市', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('69', '其它区', '45', '3', '44,45', '0', '1');
INSERT INTO `smi_region` VALUES ('70', '唐山市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('71', '路南区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('72', '路北区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('73', '古冶区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('74', '开平区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('75', '丰南区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('76', '丰润区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('77', '滦县', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('78', '滦南县', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('79', '乐亭县', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('80', '迁西县', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('81', '玉田县', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('82', '唐海县', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('83', '遵化市', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('84', '迁安市', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('85', '其它区', '70', '3', '44,70', '0', '1');
INSERT INTO `smi_region` VALUES ('86', '秦皇岛市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('87', '海港区', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('88', '山海关区', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('89', '北戴河区', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('90', '青龙满族自治县', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('91', '昌黎县', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('92', '抚宁县', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('93', '卢龙县', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('94', '其它区', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('95', '经济技术开发区', '86', '3', '44,86', '0', '1');
INSERT INTO `smi_region` VALUES ('96', '邯郸市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('97', '邯山区', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('98', '丛台区', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('99', '复兴区', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('100', '峰峰矿区', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('101', '邯郸县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('102', '临漳县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('103', '成安县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('104', '大名县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('105', '涉县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('106', '磁县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('107', '肥乡县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('108', '永年县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('109', '邱县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('110', '鸡泽县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('111', '广平县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('112', '馆陶县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('113', '魏县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('114', '曲周县', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('115', '武安市', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('116', '其它区', '96', '3', '44,96', '0', '1');
INSERT INTO `smi_region` VALUES ('117', '邢台市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('118', '桥东区', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('119', '桥西区', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('120', '邢台县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('121', '临城县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('122', '内丘县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('123', '柏乡县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('124', '隆尧县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('125', '任县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('126', '南和县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('127', '宁晋县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('128', '巨鹿县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('129', '新河县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('130', '广宗县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('131', '平乡县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('132', '威县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('133', '清河县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('134', '临西县', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('135', '南宫市', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('136', '沙河市', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('137', '其它区', '117', '3', '44,117', '0', '1');
INSERT INTO `smi_region` VALUES ('138', '保定市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('139', '新市区', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('140', '北市区', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('141', '南市区', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('142', '满城县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('143', '清苑县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('144', '涞水县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('145', '阜平县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('146', '徐水县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('147', '定兴县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('148', '唐县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('149', '高阳县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('150', '容城县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('151', '涞源县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('152', '望都县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('153', '安新县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('154', '易县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('155', '曲阳县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('156', '蠡县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('157', '顺平县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('158', '博野县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('159', '雄县', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('160', '涿州市', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('161', '定州市', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('162', '安国市', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('163', '高碑店市', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('164', '高开区', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('165', '其它区', '138', '3', '44,138', '0', '1');
INSERT INTO `smi_region` VALUES ('166', '张家口市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('167', '桥东区', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('168', '桥西区', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('169', '宣化区', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('170', '下花园区', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('171', '宣化县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('172', '张北县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('173', '康保县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('174', '沽源县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('175', '尚义县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('176', '蔚县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('177', '阳原县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('178', '怀安县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('179', '万全县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('180', '怀来县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('181', '涿鹿县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('182', '赤城县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('183', '崇礼县', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('184', '其它区', '166', '3', '44,166', '0', '1');
INSERT INTO `smi_region` VALUES ('185', '承德市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('186', '双桥区', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('187', '双滦区', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('188', '鹰手营子矿区', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('189', '承德县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('190', '兴隆县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('191', '平泉县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('192', '滦平县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('193', '隆化县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('194', '丰宁满族自治县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('195', '宽城满族自治县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('196', '围场满族蒙古族自治县', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('197', '其它区', '185', '3', '44,185', '0', '1');
INSERT INTO `smi_region` VALUES ('198', '沧州市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('199', '新华区', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('200', '运河区', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('201', '沧县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('202', '青县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('203', '东光县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('204', '海兴县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('205', '盐山县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('206', '肃宁县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('207', '南皮县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('208', '吴桥县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('209', '献县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('210', '孟村回族自治县', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('211', '泊头市', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('212', '任丘市', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('213', '黄骅市', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('214', '河间市', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('215', '其它区', '198', '3', '44,198', '0', '1');
INSERT INTO `smi_region` VALUES ('216', '廊坊市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('217', '安次区', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('218', '广阳区', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('219', '固安县', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('220', '永清县', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('221', '香河县', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('222', '大城县', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('223', '文安县', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('224', '大厂回族自治县', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('225', '开发区', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('226', '燕郊经济技术开发区', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('227', '霸州市', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('228', '三河市', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('229', '其它区', '216', '3', '44,216', '0', '1');
INSERT INTO `smi_region` VALUES ('230', '衡水市', '44', '2', '44', '0', '1');
INSERT INTO `smi_region` VALUES ('231', '桃城区', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('232', '枣强县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('233', '武邑县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('234', '武强县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('235', '饶阳县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('236', '安平县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('237', '故城县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('238', '景县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('239', '阜城县', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('240', '冀州市', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('241', '深州市', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('242', '其它区', '230', '3', '44,230', '0', '1');
INSERT INTO `smi_region` VALUES ('243', '山西省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('244', '太原市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('245', '小店区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('246', '迎泽区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('247', '杏花岭区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('248', '尖草坪区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('249', '万柏林区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('250', '晋源区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('251', '清徐县', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('252', '阳曲县', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('253', '娄烦县', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('254', '古交市', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('255', '其它区', '244', '3', '243,244', '0', '1');
INSERT INTO `smi_region` VALUES ('256', '大同市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('257', '城区', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('258', '矿区', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('259', '南郊区', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('260', '新荣区', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('261', '阳高县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('262', '天镇县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('263', '广灵县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('264', '灵丘县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('265', '浑源县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('266', '左云县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('267', '大同县', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('268', '其它区', '256', '3', '243,256', '0', '1');
INSERT INTO `smi_region` VALUES ('269', '阳泉市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('270', '城区', '269', '3', '243,269', '0', '1');
INSERT INTO `smi_region` VALUES ('271', '矿区', '269', '3', '243,269', '0', '1');
INSERT INTO `smi_region` VALUES ('272', '郊区', '269', '3', '243,269', '0', '1');
INSERT INTO `smi_region` VALUES ('273', '平定县', '269', '3', '243,269', '0', '1');
INSERT INTO `smi_region` VALUES ('274', '盂县', '269', '3', '243,269', '0', '1');
INSERT INTO `smi_region` VALUES ('275', '其它区', '269', '3', '243,269', '0', '1');
INSERT INTO `smi_region` VALUES ('276', '长治市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('277', '长治县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('278', '襄垣县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('279', '屯留县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('280', '平顺县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('281', '黎城县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('282', '壶关县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('283', '长子县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('284', '武乡县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('285', '沁县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('286', '沁源县', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('287', '潞城市', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('288', '城区', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('289', '郊区', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('290', '高新区', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('291', '其它区', '276', '3', '243,276', '0', '1');
INSERT INTO `smi_region` VALUES ('292', '晋城市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('293', '城区', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('294', '沁水县', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('295', '阳城县', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('296', '陵川县', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('297', '泽州县', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('298', '高平市', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('299', '其它区', '292', '3', '243,292', '0', '1');
INSERT INTO `smi_region` VALUES ('300', '朔州市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('301', '朔城区', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('302', '平鲁区', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('303', '山阴县', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('304', '应县', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('305', '右玉县', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('306', '怀仁县', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('307', '其它区', '300', '3', '243,300', '0', '1');
INSERT INTO `smi_region` VALUES ('308', '晋中市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('309', '榆次区', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('310', '榆社县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('311', '左权县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('312', '和顺县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('313', '昔阳县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('314', '寿阳县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('315', '太谷县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('316', '祁县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('317', '平遥县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('318', '灵石县', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('319', '介休市', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('320', '其它区', '308', '3', '243,308', '0', '1');
INSERT INTO `smi_region` VALUES ('321', '运城市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('322', '盐湖区', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('323', '临猗县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('324', '万荣县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('325', '闻喜县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('326', '稷山县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('327', '新绛县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('328', '绛县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('329', '垣曲县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('330', '夏县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('331', '平陆县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('332', '芮城县', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('333', '永济市', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('334', '河津市', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('335', '其它区', '321', '3', '243,321', '0', '1');
INSERT INTO `smi_region` VALUES ('336', '忻州市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('337', '忻府区', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('338', '定襄县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('339', '五台县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('340', '代县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('341', '繁峙县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('342', '宁武县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('343', '静乐县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('344', '神池县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('345', '五寨县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('346', '岢岚县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('347', '河曲县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('348', '保德县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('349', '偏关县', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('350', '原平市', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('351', '其它区', '336', '3', '243,336', '0', '1');
INSERT INTO `smi_region` VALUES ('352', '临汾市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('353', '尧都区', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('354', '曲沃县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('355', '翼城县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('356', '襄汾县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('357', '洪洞县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('358', '古县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('359', '安泽县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('360', '浮山县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('361', '吉县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('362', '乡宁县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('363', '大宁县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('364', '隰县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('365', '永和县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('366', '蒲县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('367', '汾西县', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('368', '侯马市', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('369', '霍州市', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('370', '其它区', '352', '3', '243,352', '0', '1');
INSERT INTO `smi_region` VALUES ('371', '吕梁市', '243', '2', '243', '0', '1');
INSERT INTO `smi_region` VALUES ('372', '离石区', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('373', '文水县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('374', '交城县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('375', '兴县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('376', '临县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('377', '柳林县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('378', '石楼县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('379', '岚县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('380', '方山县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('381', '中阳县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('382', '交口县', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('383', '孝义市', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('384', '汾阳市', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('385', '其它区', '371', '3', '243,371', '0', '1');
INSERT INTO `smi_region` VALUES ('386', '内蒙古自治区', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('387', '呼和浩特市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('388', '新城区', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('389', '回民区', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('390', '玉泉区', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('391', '赛罕区', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('392', '土默特左旗', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('393', '托克托县', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('394', '和林格尔县', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('395', '清水河县', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('396', '武川县', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('397', '其它区', '387', '3', '386,387', '0', '1');
INSERT INTO `smi_region` VALUES ('398', '包头市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('399', '东河区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('400', '昆都仑区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('401', '青山区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('402', '石拐区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('403', '白云矿区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('404', '九原区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('405', '土默特右旗', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('406', '固阳县', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('407', '达尔罕茂明安联合旗', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('408', '其它区', '398', '3', '386,398', '0', '1');
INSERT INTO `smi_region` VALUES ('409', '乌海市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('410', '海勃湾区', '409', '3', '386,409', '0', '1');
INSERT INTO `smi_region` VALUES ('411', '海南区', '409', '3', '386,409', '0', '1');
INSERT INTO `smi_region` VALUES ('412', '乌达区', '409', '3', '386,409', '0', '1');
INSERT INTO `smi_region` VALUES ('413', '其它区', '409', '3', '386,409', '0', '1');
INSERT INTO `smi_region` VALUES ('414', '赤峰市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('415', '红山区', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('416', '元宝山区', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('417', '松山区', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('418', '阿鲁科尔沁旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('419', '巴林左旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('420', '巴林右旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('421', '林西县', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('422', '克什克腾旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('423', '翁牛特旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('424', '喀喇沁旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('425', '宁城县', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('426', '敖汉旗', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('427', '其它区', '414', '3', '386,414', '0', '1');
INSERT INTO `smi_region` VALUES ('428', '通辽市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('429', '科尔沁区', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('430', '科尔沁左翼中旗', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('431', '科尔沁左翼后旗', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('432', '开鲁县', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('433', '库伦旗', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('434', '奈曼旗', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('435', '扎鲁特旗', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('436', '霍林郭勒市', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('437', '其它区', '428', '3', '386,428', '0', '1');
INSERT INTO `smi_region` VALUES ('438', '鄂尔多斯市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('439', '东胜区', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('440', '达拉特旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('441', '准格尔旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('442', '鄂托克前旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('443', '鄂托克旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('444', '杭锦旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('445', '乌审旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('446', '伊金霍洛旗', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('447', '其它区', '438', '3', '386,438', '0', '1');
INSERT INTO `smi_region` VALUES ('448', '呼伦贝尔市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('449', '海拉尔区', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('450', '阿荣旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('451', '莫力达瓦达斡尔族自治旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('452', '鄂伦春自治旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('453', '鄂温克族自治旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('454', '陈巴尔虎旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('455', '新巴尔虎左旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('456', '新巴尔虎右旗', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('457', '满洲里市', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('458', '牙克石市', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('459', '扎兰屯市', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('460', '额尔古纳市', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('461', '根河市', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('462', '其它区', '448', '3', '386,448', '0', '1');
INSERT INTO `smi_region` VALUES ('463', '巴彦淖尔市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('464', '临河区', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('465', '五原县', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('466', '磴口县', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('467', '乌拉特前旗', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('468', '乌拉特中旗', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('469', '乌拉特后旗', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('470', '杭锦后旗', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('471', '其它区', '463', '3', '386,463', '0', '1');
INSERT INTO `smi_region` VALUES ('472', '乌兰察布市', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('473', '集宁区', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('474', '卓资县', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('475', '化德县', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('476', '商都县', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('477', '兴和县', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('478', '凉城县', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('479', '察哈尔右翼前旗', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('480', '察哈尔右翼中旗', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('481', '察哈尔右翼后旗', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('482', '四子王旗', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('483', '丰镇市', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('484', '其它区', '472', '3', '386,472', '0', '1');
INSERT INTO `smi_region` VALUES ('485', '兴安盟', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('486', '乌兰浩特市', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('487', '阿尔山市', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('488', '科尔沁右翼前旗', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('489', '科尔沁右翼中旗', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('490', '扎赉特旗', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('491', '突泉县', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('492', '其它区', '485', '3', '386,485', '0', '1');
INSERT INTO `smi_region` VALUES ('493', '锡林郭勒盟', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('494', '二连浩特市', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('495', '锡林浩特市', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('496', '阿巴嘎旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('497', '苏尼特左旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('498', '苏尼特右旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('499', '东乌珠穆沁旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('500', '西乌珠穆沁旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('501', '太仆寺旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('502', '镶黄旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('503', '正镶白旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('504', '正蓝旗', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('505', '多伦县', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('506', '其它区', '493', '3', '386,493', '0', '1');
INSERT INTO `smi_region` VALUES ('507', '阿拉善盟', '386', '2', '386', '0', '1');
INSERT INTO `smi_region` VALUES ('508', '阿拉善左旗', '507', '3', '386,507', '0', '1');
INSERT INTO `smi_region` VALUES ('509', '阿拉善右旗', '507', '3', '386,507', '0', '1');
INSERT INTO `smi_region` VALUES ('510', '额济纳旗', '507', '3', '386,507', '0', '1');
INSERT INTO `smi_region` VALUES ('511', '其它区', '507', '3', '386,507', '0', '1');
INSERT INTO `smi_region` VALUES ('512', '辽宁省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('513', '沈阳市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('514', '和平区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('515', '沈河区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('516', '大东区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('517', '皇姑区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('518', '铁西区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('519', '苏家屯区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('520', '东陵区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('521', '新城子区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('522', '于洪区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('523', '辽中县', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('524', '康平县', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('525', '法库县', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('526', '新民市', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('527', '浑南新区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('528', '张士开发区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('529', '沈北新区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('530', '其它区', '513', '3', '512,513', '0', '1');
INSERT INTO `smi_region` VALUES ('531', '大连市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('532', '中山区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('533', '西岗区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('534', '沙河口区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('535', '甘井子区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('536', '旅顺口区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('537', '金州区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('538', '长海县', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('539', '开发区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('540', '瓦房店市', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('541', '普兰店市', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('542', '庄河市', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('543', '岭前区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('544', '其它区', '531', '3', '512,531', '0', '1');
INSERT INTO `smi_region` VALUES ('545', '鞍山市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('546', '铁东区', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('547', '铁西区', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('548', '立山区', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('549', '千山区', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('550', '台安县', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('551', '岫岩满族自治县', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('552', '高新区', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('553', '海城市', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('554', '其它区', '545', '3', '512,545', '0', '1');
INSERT INTO `smi_region` VALUES ('555', '抚顺市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('556', '新抚区', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('557', '东洲区', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('558', '望花区', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('559', '顺城区', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('560', '抚顺县', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('561', '新宾满族自治县', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('562', '清原满族自治县', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('563', '其它区', '555', '3', '512,555', '0', '1');
INSERT INTO `smi_region` VALUES ('564', '本溪市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('565', '平山区', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('566', '溪湖区', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('567', '明山区', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('568', '南芬区', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('569', '本溪满族自治县', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('570', '桓仁满族自治县', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('571', '其它区', '564', '3', '512,564', '0', '1');
INSERT INTO `smi_region` VALUES ('572', '丹东市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('573', '元宝区', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('574', '振兴区', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('575', '振安区', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('576', '宽甸满族自治县', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('577', '东港市', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('578', '凤城市', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('579', '其它区', '572', '3', '512,572', '0', '1');
INSERT INTO `smi_region` VALUES ('580', '锦州市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('581', '古塔区', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('582', '凌河区', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('583', '太和区', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('584', '黑山县', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('585', '义县', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('586', '凌海市', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('587', '北镇市', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('588', '其它区', '580', '3', '512,580', '0', '1');
INSERT INTO `smi_region` VALUES ('589', '营口市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('590', '站前区', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('591', '西市区', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('592', '鲅鱼圈区', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('593', '老边区', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('594', '盖州市', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('595', '大石桥市', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('596', '其它区', '589', '3', '512,589', '0', '1');
INSERT INTO `smi_region` VALUES ('597', '阜新市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('598', '海州区', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('599', '新邱区', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('600', '太平区', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('601', '清河门区', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('602', '细河区', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('603', '阜新蒙古族自治县', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('604', '彰武县', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('605', '其它区', '597', '3', '512,597', '0', '1');
INSERT INTO `smi_region` VALUES ('606', '辽阳市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('607', '白塔区', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('608', '文圣区', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('609', '宏伟区', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('610', '弓长岭区', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('611', '太子河区', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('612', '辽阳县', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('613', '灯塔市', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('614', '其它区', '606', '3', '512,606', '0', '1');
INSERT INTO `smi_region` VALUES ('615', '盘锦市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('616', '双台子区', '615', '3', '512,615', '0', '1');
INSERT INTO `smi_region` VALUES ('617', '兴隆台区', '615', '3', '512,615', '0', '1');
INSERT INTO `smi_region` VALUES ('618', '大洼县', '615', '3', '512,615', '0', '1');
INSERT INTO `smi_region` VALUES ('619', '盘山县', '615', '3', '512,615', '0', '1');
INSERT INTO `smi_region` VALUES ('620', '其它区', '615', '3', '512,615', '0', '1');
INSERT INTO `smi_region` VALUES ('621', '铁岭市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('622', '银州区', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('623', '清河区', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('624', '铁岭县', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('625', '西丰县', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('626', '昌图县', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('627', '调兵山市', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('628', '开原市', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('629', '其它区', '621', '3', '512,621', '0', '1');
INSERT INTO `smi_region` VALUES ('630', '朝阳市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('631', '双塔区', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('632', '龙城区', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('633', '朝阳县', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('634', '建平县', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('635', '喀喇沁左翼蒙古族自治县', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('636', '北票市', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('637', '凌源市', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('638', '其它区', '630', '3', '512,630', '0', '1');
INSERT INTO `smi_region` VALUES ('639', '葫芦岛市', '512', '2', '512', '0', '1');
INSERT INTO `smi_region` VALUES ('640', '连山区', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('641', '龙港区', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('642', '南票区', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('643', '绥中县', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('644', '建昌县', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('645', '兴城市', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('646', '其它区', '639', '3', '512,639', '0', '1');
INSERT INTO `smi_region` VALUES ('647', '吉林省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('648', '长春市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('649', '南关区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('650', '宽城区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('651', '朝阳区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('652', '二道区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('653', '绿园区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('654', '双阳区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('655', '农安县', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('656', '九台市', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('657', '榆树市', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('658', '德惠市', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('659', '高新技术产业开发区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('660', '汽车产业开发区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('661', '经济技术开发区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('662', '净月旅游开发区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('663', '其它区', '648', '3', '647,648', '0', '1');
INSERT INTO `smi_region` VALUES ('664', '吉林市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('665', '昌邑区', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('666', '龙潭区', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('667', '船营区', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('668', '丰满区', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('669', '永吉县', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('670', '蛟河市', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('671', '桦甸市', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('672', '舒兰市', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('673', '磐石市', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('674', '其它区', '664', '3', '647,664', '0', '1');
INSERT INTO `smi_region` VALUES ('675', '四平市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('676', '铁西区', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('677', '铁东区', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('678', '梨树县', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('679', '伊通满族自治县', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('680', '公主岭市', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('681', '双辽市', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('682', '其它区', '675', '3', '647,675', '0', '1');
INSERT INTO `smi_region` VALUES ('683', '辽源市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('684', '龙山区', '683', '3', '647,683', '0', '1');
INSERT INTO `smi_region` VALUES ('685', '西安区', '683', '3', '647,683', '0', '1');
INSERT INTO `smi_region` VALUES ('686', '东丰县', '683', '3', '647,683', '0', '1');
INSERT INTO `smi_region` VALUES ('687', '东辽县', '683', '3', '647,683', '0', '1');
INSERT INTO `smi_region` VALUES ('688', '其它区', '683', '3', '647,683', '0', '1');
INSERT INTO `smi_region` VALUES ('689', '通化市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('690', '东昌区', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('691', '二道江区', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('692', '通化县', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('693', '辉南县', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('694', '柳河县', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('695', '梅河口市', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('696', '集安市', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('697', '其它区', '689', '3', '647,689', '0', '1');
INSERT INTO `smi_region` VALUES ('698', '白山市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('699', '八道江区', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('700', '抚松县', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('701', '靖宇县', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('702', '长白朝鲜族自治县', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('703', '江源县', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('704', '临江市', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('705', '其它区', '698', '3', '647,698', '0', '1');
INSERT INTO `smi_region` VALUES ('706', '松原市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('707', '宁江区', '706', '3', '647,706', '0', '1');
INSERT INTO `smi_region` VALUES ('708', '前郭尔罗斯蒙古族自治县', '706', '3', '647,706', '0', '1');
INSERT INTO `smi_region` VALUES ('709', '长岭县', '706', '3', '647,706', '0', '1');
INSERT INTO `smi_region` VALUES ('710', '乾安县', '706', '3', '647,706', '0', '1');
INSERT INTO `smi_region` VALUES ('711', '扶余县', '706', '3', '647,706', '0', '1');
INSERT INTO `smi_region` VALUES ('712', '其它区', '706', '3', '647,706', '0', '1');
INSERT INTO `smi_region` VALUES ('713', '白城市', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('714', '洮北区', '713', '3', '647,713', '0', '1');
INSERT INTO `smi_region` VALUES ('715', '镇赉县', '713', '3', '647,713', '0', '1');
INSERT INTO `smi_region` VALUES ('716', '通榆县', '713', '3', '647,713', '0', '1');
INSERT INTO `smi_region` VALUES ('717', '洮南市', '713', '3', '647,713', '0', '1');
INSERT INTO `smi_region` VALUES ('718', '大安市', '713', '3', '647,713', '0', '1');
INSERT INTO `smi_region` VALUES ('719', '其它区', '713', '3', '647,713', '0', '1');
INSERT INTO `smi_region` VALUES ('720', '延边朝鲜族自治州', '647', '2', '647', '0', '1');
INSERT INTO `smi_region` VALUES ('721', '延吉市', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('722', '图们市', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('723', '敦化市', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('724', '珲春市', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('725', '龙井市', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('726', '和龙市', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('727', '汪清县', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('728', '安图县', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('729', '其它区', '720', '3', '647,720', '0', '1');
INSERT INTO `smi_region` VALUES ('730', '黑龙江省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('731', '哈尔滨市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('732', '道里区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('733', '南岗区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('734', '道外区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('735', '香坊区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('736', '动力区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('737', '平房区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('738', '松北区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('739', '呼兰区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('740', '依兰县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('741', '方正县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('742', '宾县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('743', '巴彦县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('744', '木兰县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('745', '通河县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('746', '延寿县', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('747', '阿城市', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('748', '双城市', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('749', '尚志市', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('750', '五常市', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('751', '阿城市', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('752', '其它区', '731', '3', '730,731', '0', '1');
INSERT INTO `smi_region` VALUES ('753', '齐齐哈尔市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('754', '龙沙区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('755', '建华区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('756', '铁锋区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('757', '昂昂溪区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('758', '富拉尔基区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('759', '碾子山区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('760', '梅里斯达斡尔族区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('761', '龙江县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('762', '依安县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('763', '泰来县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('764', '甘南县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('765', '富裕县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('766', '克山县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('767', '克东县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('768', '拜泉县', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('769', '讷河市', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('770', '其它区', '753', '3', '730,753', '0', '1');
INSERT INTO `smi_region` VALUES ('771', '鸡西市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('772', '鸡冠区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('773', '恒山区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('774', '滴道区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('775', '梨树区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('776', '城子河区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('777', '麻山区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('778', '鸡东县', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('779', '虎林市', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('780', '密山市', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('781', '其它区', '771', '3', '730,771', '0', '1');
INSERT INTO `smi_region` VALUES ('782', '鹤岗市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('783', '向阳区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('784', '工农区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('785', '南山区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('786', '兴安区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('787', '东山区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('788', '兴山区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('789', '萝北县', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('790', '绥滨县', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('791', '其它区', '782', '3', '730,782', '0', '1');
INSERT INTO `smi_region` VALUES ('792', '双鸭山市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('793', '尖山区', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('794', '岭东区', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('795', '四方台区', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('796', '宝山区', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('797', '集贤县', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('798', '友谊县', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('799', '宝清县', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('800', '饶河县', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('801', '其它区', '792', '3', '730,792', '0', '1');
INSERT INTO `smi_region` VALUES ('802', '大庆市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('803', '萨尔图区', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('804', '龙凤区', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('805', '让胡路区', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('806', '红岗区', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('807', '大同区', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('808', '肇州县', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('809', '肇源县', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('810', '林甸县', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('811', '杜尔伯特蒙古族自治县', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('812', '其它区', '802', '3', '730,802', '0', '1');
INSERT INTO `smi_region` VALUES ('813', '伊春市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('814', '伊春区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('815', '南岔区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('816', '友好区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('817', '西林区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('818', '翠峦区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('819', '新青区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('820', '美溪区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('821', '金山屯区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('822', '五营区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('823', '乌马河区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('824', '汤旺河区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('825', '带岭区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('826', '乌伊岭区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('827', '红星区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('828', '上甘岭区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('829', '嘉荫县', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('830', '铁力市', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('831', '其它区', '813', '3', '730,813', '0', '1');
INSERT INTO `smi_region` VALUES ('832', '佳木斯市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('833', '永红区', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('834', '向阳区', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('835', '前进区', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('836', '东风区', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('837', '郊区', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('838', '桦南县', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('839', '桦川县', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('840', '汤原县', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('841', '抚远县', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('842', '同江市', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('843', '富锦市', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('844', '其它区', '832', '3', '730,832', '0', '1');
INSERT INTO `smi_region` VALUES ('845', '七台河市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('846', '新兴区', '845', '3', '730,845', '0', '1');
INSERT INTO `smi_region` VALUES ('847', '桃山区', '845', '3', '730,845', '0', '1');
INSERT INTO `smi_region` VALUES ('848', '茄子河区', '845', '3', '730,845', '0', '1');
INSERT INTO `smi_region` VALUES ('849', '勃利县', '845', '3', '730,845', '0', '1');
INSERT INTO `smi_region` VALUES ('850', '其它区', '845', '3', '730,845', '0', '1');
INSERT INTO `smi_region` VALUES ('851', '牡丹江市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('852', '东安区', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('853', '阳明区', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('854', '爱民区', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('855', '西安区', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('856', '东宁县', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('857', '林口县', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('858', '绥芬河市', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('859', '海林市', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('860', '宁安市', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('861', '穆棱市', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('862', '其它区', '851', '3', '730,851', '0', '1');
INSERT INTO `smi_region` VALUES ('863', '黑河市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('864', '爱辉区', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('865', '嫩江县', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('866', '逊克县', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('867', '孙吴县', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('868', '北安市', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('869', '五大连池市', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('870', '其它区', '863', '3', '730,863', '0', '1');
INSERT INTO `smi_region` VALUES ('871', '绥化市', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('872', '北林区', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('873', '望奎县', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('874', '兰西县', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('875', '青冈县', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('876', '庆安县', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('877', '明水县', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('878', '绥棱县', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('879', '安达市', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('880', '肇东市', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('881', '海伦市', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('882', '其它区', '871', '3', '730,871', '0', '1');
INSERT INTO `smi_region` VALUES ('883', '大兴安岭地区', '730', '2', '730', '0', '1');
INSERT INTO `smi_region` VALUES ('884', '呼玛县', '883', '3', '730,883', '0', '1');
INSERT INTO `smi_region` VALUES ('885', '塔河县', '883', '3', '730,883', '0', '1');
INSERT INTO `smi_region` VALUES ('886', '漠河县', '883', '3', '730,883', '0', '1');
INSERT INTO `smi_region` VALUES ('887', '加格达奇区', '883', '3', '730,883', '0', '1');
INSERT INTO `smi_region` VALUES ('888', '其它区', '883', '3', '730,883', '0', '1');
INSERT INTO `smi_region` VALUES ('889', '上海', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('890', '上海市', '889', '2', '889', '0', '1');
INSERT INTO `smi_region` VALUES ('891', '黄浦区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('892', '卢湾区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('893', '徐汇区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('894', '长宁区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('895', '静安区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('896', '普陀区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('897', '闸北区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('898', '虹口区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('899', '杨浦区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('900', '闵行区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('901', '宝山区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('902', '嘉定区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('903', '浦东新区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('904', '金山区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('905', '松江区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('906', '青浦区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('907', '南汇区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('908', '奉贤区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('909', '川沙区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('910', '崇明县', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('911', '其它区', '890', '3', '889,890', '0', '1');
INSERT INTO `smi_region` VALUES ('912', '江苏省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('913', '南京市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('914', '玄武区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('915', '白下区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('916', '秦淮区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('917', '建邺区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('918', '鼓楼区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('919', '下关区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('920', '浦口区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('921', '栖霞区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('922', '雨花台区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('923', '江宁区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('924', '六合区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('925', '溧水县', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('926', '高淳县', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('927', '其它区', '913', '3', '912,913', '0', '1');
INSERT INTO `smi_region` VALUES ('928', '无锡市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('929', '崇安区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('930', '南长区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('931', '北塘区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('932', '锡山区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('933', '惠山区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('934', '滨湖区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('935', '江阴市', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('936', '宜兴市', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('937', '新区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('938', '其它区', '928', '3', '912,928', '0', '1');
INSERT INTO `smi_region` VALUES ('939', '徐州市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('940', '鼓楼区', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('941', '云龙区', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('942', '九里区', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('943', '贾汪区', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('944', '泉山区', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('945', '丰县', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('946', '沛县', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('947', '铜山县', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('948', '睢宁县', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('949', '新沂市', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('950', '邳州市', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('951', '其它区', '939', '3', '912,939', '0', '1');
INSERT INTO `smi_region` VALUES ('952', '常州市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('953', '天宁区', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('954', '钟楼区', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('955', '戚墅堰区', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('956', '新北区', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('957', '武进区', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('958', '溧阳市', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('959', '金坛市', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('960', '其它区', '952', '3', '912,952', '0', '1');
INSERT INTO `smi_region` VALUES ('961', '苏州市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('962', '沧浪区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('963', '平江区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('964', '金阊区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('965', '虎丘区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('966', '吴中区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('967', '相城区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('968', '常熟市', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('969', '张家港市', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('970', '昆山市', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('971', '吴江市', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('972', '太仓市', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('973', '新区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('974', '园区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('975', '其它区', '961', '3', '912,961', '0', '1');
INSERT INTO `smi_region` VALUES ('976', '南通市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('977', '崇川区', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('978', '港闸区', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('979', '通州区', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('980', '海安县', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('981', '如东县', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('982', '启东市', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('983', '如皋市', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('984', '通州市', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('985', '海门市', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('986', '开发区', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('987', '其它区', '976', '3', '912,976', '0', '1');
INSERT INTO `smi_region` VALUES ('988', '连云港市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('989', '连云区', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('990', '新浦区', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('991', '海州区', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('992', '赣榆县', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('993', '东海县', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('994', '灌云县', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('995', '灌南县', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('996', '其它区', '988', '3', '912,988', '0', '1');
INSERT INTO `smi_region` VALUES ('997', '淮安市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('998', '清河区', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('999', '楚州区', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1000', '淮阴区', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1001', '清浦区', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1002', '涟水县', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1003', '洪泽县', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1004', '盱眙县', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1005', '金湖县', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1006', '其它区', '997', '3', '912,997', '0', '1');
INSERT INTO `smi_region` VALUES ('1007', '盐城市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('1008', '亭湖区', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1009', '盐都区', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1010', '响水县', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1011', '滨海县', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1012', '阜宁县', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1013', '射阳县', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1014', '建湖县', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1015', '东台市', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1016', '大丰市', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1017', '其它区', '1007', '3', '912,1007', '0', '1');
INSERT INTO `smi_region` VALUES ('1018', '扬州市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('1019', '广陵区', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1020', '邗江区', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1021', '维扬区', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1022', '宝应县', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1023', '仪征市', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1024', '高邮市', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1025', '江都市', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1026', '经济开发区', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1027', '其它区', '1018', '3', '912,1018', '0', '1');
INSERT INTO `smi_region` VALUES ('1028', '镇江市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('1029', '京口区', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1030', '润州区', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1031', '丹徒区', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1032', '丹阳市', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1033', '扬中市', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1034', '句容市', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1035', '其它区', '1028', '3', '912,1028', '0', '1');
INSERT INTO `smi_region` VALUES ('1036', '泰州市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('1037', '海陵区', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1038', '高港区', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1039', '兴化市', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1040', '靖江市', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1041', '泰兴市', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1042', '姜堰市', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1043', '其它区', '1036', '3', '912,1036', '0', '1');
INSERT INTO `smi_region` VALUES ('1044', '宿迁市', '912', '2', '912', '0', '1');
INSERT INTO `smi_region` VALUES ('1045', '宿城区', '1044', '3', '912,1044', '0', '1');
INSERT INTO `smi_region` VALUES ('1046', '宿豫区', '1044', '3', '912,1044', '0', '1');
INSERT INTO `smi_region` VALUES ('1047', '沭阳县', '1044', '3', '912,1044', '0', '1');
INSERT INTO `smi_region` VALUES ('1048', '泗阳县', '1044', '3', '912,1044', '0', '1');
INSERT INTO `smi_region` VALUES ('1049', '泗洪县', '1044', '3', '912,1044', '0', '1');
INSERT INTO `smi_region` VALUES ('1050', '其它区', '1044', '3', '912,1044', '0', '1');
INSERT INTO `smi_region` VALUES ('1051', '浙江省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1052', '杭州市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1053', '上城区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1054', '下城区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1055', '江干区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1056', '拱墅区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1057', '西湖区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1058', '滨江区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1059', '萧山区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1060', '余杭区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1061', '桐庐县', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1062', '淳安县', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1063', '建德市', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1064', '富阳市', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1065', '临安市', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1066', '其它区', '1052', '3', '1051,1052', '0', '1');
INSERT INTO `smi_region` VALUES ('1067', '宁波市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1068', '海曙区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1069', '江东区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1070', '江北区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1071', '北仑区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1072', '镇海区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1073', '鄞州区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1074', '象山县', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1075', '宁海县', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1076', '余姚市', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1077', '慈溪市', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1078', '奉化市', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1079', '其它区', '1067', '3', '1051,1067', '0', '1');
INSERT INTO `smi_region` VALUES ('1080', '温州市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1081', '鹿城区', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1082', '龙湾区', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1083', '瓯海区', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1084', '洞头县', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1085', '永嘉县', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1086', '平阳县', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1087', '苍南县', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1088', '文成县', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1089', '泰顺县', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1090', '瑞安市', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1091', '乐清市', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1092', '其它区', '1080', '3', '1051,1080', '0', '1');
INSERT INTO `smi_region` VALUES ('1093', '嘉兴市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1094', '南湖区', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1095', '秀洲区', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1096', '嘉善县', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1097', '海盐县', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1098', '海宁市', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1099', '平湖市', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1100', '桐乡市', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1101', '其它区', '1093', '3', '1051,1093', '0', '1');
INSERT INTO `smi_region` VALUES ('1102', '湖州市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1103', '吴兴区', '1102', '3', '1051,1102', '0', '1');
INSERT INTO `smi_region` VALUES ('1104', '南浔区', '1102', '3', '1051,1102', '0', '1');
INSERT INTO `smi_region` VALUES ('1105', '德清县', '1102', '3', '1051,1102', '0', '1');
INSERT INTO `smi_region` VALUES ('1106', '长兴县', '1102', '3', '1051,1102', '0', '1');
INSERT INTO `smi_region` VALUES ('1107', '安吉县', '1102', '3', '1051,1102', '0', '1');
INSERT INTO `smi_region` VALUES ('1108', '其它区', '1102', '3', '1051,1102', '0', '1');
INSERT INTO `smi_region` VALUES ('1109', '绍兴市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1110', '越城区', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1111', '绍兴县', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1112', '新昌县', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1113', '诸暨市', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1114', '上虞市', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1115', '嵊州市', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1116', '其它区', '1109', '3', '1051,1109', '0', '1');
INSERT INTO `smi_region` VALUES ('1117', '金华市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1118', '婺城区', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1119', '金东区', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1120', '武义县', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1121', '浦江县', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1122', '磐安县', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1123', '兰溪市', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1124', '义乌市', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1125', '东阳市', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1126', '永康市', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1127', '其它区', '1117', '3', '1051,1117', '0', '1');
INSERT INTO `smi_region` VALUES ('1128', '衢州市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1129', '柯城区', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1130', '衢江区', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1131', '常山县', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1132', '开化县', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1133', '龙游县', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1134', '江山市', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1135', '其它区', '1128', '3', '1051,1128', '0', '1');
INSERT INTO `smi_region` VALUES ('1136', '舟山市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1137', '定海区', '1136', '3', '1051,1136', '0', '1');
INSERT INTO `smi_region` VALUES ('1138', '普陀区', '1136', '3', '1051,1136', '0', '1');
INSERT INTO `smi_region` VALUES ('1139', '岱山县', '1136', '3', '1051,1136', '0', '1');
INSERT INTO `smi_region` VALUES ('1140', '嵊泗县', '1136', '3', '1051,1136', '0', '1');
INSERT INTO `smi_region` VALUES ('1141', '其它区', '1136', '3', '1051,1136', '0', '1');
INSERT INTO `smi_region` VALUES ('1142', '台州市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1143', '椒江区', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1144', '黄岩区', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1145', '路桥区', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1146', '玉环县', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1147', '三门县', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1148', '天台县', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1149', '仙居县', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1150', '温岭市', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1151', '临海市', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1152', '其它区', '1142', '3', '1051,1142', '0', '1');
INSERT INTO `smi_region` VALUES ('1153', '丽水市', '1051', '2', '1051', '0', '1');
INSERT INTO `smi_region` VALUES ('1154', '莲都区', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1155', '青田县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1156', '缙云县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1157', '遂昌县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1158', '松阳县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1159', '云和县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1160', '庆元县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1161', '景宁畲族自治县', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1162', '龙泉市', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1163', '其它区', '1153', '3', '1051,1153', '0', '1');
INSERT INTO `smi_region` VALUES ('1164', '安徽省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1165', '合肥市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1166', '瑶海区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1167', '庐阳区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1168', '蜀山区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1169', '包河区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1170', '长丰县', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1171', '肥东县', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1172', '肥西县', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1173', '高新区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1174', '中区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1175', '其它区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1176', '巢湖市', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1177', '居巢区', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1178', '庐江县', '1165', '3', '1164,1165', '0', '1');
INSERT INTO `smi_region` VALUES ('1179', '芜湖市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1180', '镜湖区', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1181', '弋江区', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1182', '鸠江区', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1183', '三山区', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1184', '芜湖县', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1185', '繁昌县', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1186', '南陵县', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1187', '其它区', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1188', '无为县', '1179', '3', '1164,1179', '0', '1');
INSERT INTO `smi_region` VALUES ('1189', '蚌埠市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1190', '龙子湖区', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1191', '蚌山区', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1192', '禹会区', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1193', '淮上区', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1194', '怀远县', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1195', '五河县', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1196', '固镇县', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1197', '其它区', '1189', '3', '1164,1189', '0', '1');
INSERT INTO `smi_region` VALUES ('1198', '淮南市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1199', '大通区', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1200', '田家庵区', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1201', '谢家集区', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1202', '八公山区', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1203', '潘集区', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1204', '凤台县', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1205', '其它区', '1198', '3', '1164,1198', '0', '1');
INSERT INTO `smi_region` VALUES ('1206', '马鞍山市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1207', '金家庄区', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1208', '花山区', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1209', '雨山区', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1210', '当涂县', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1211', '其它区', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1212', '含山县', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1213', '和县', '1206', '3', '1164,1206', '0', '1');
INSERT INTO `smi_region` VALUES ('1214', '淮北市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1215', '杜集区', '1214', '3', '1164,1214', '0', '1');
INSERT INTO `smi_region` VALUES ('1216', '相山区', '1214', '3', '1164,1214', '0', '1');
INSERT INTO `smi_region` VALUES ('1217', '烈山区', '1214', '3', '1164,1214', '0', '1');
INSERT INTO `smi_region` VALUES ('1218', '濉溪县', '1214', '3', '1164,1214', '0', '1');
INSERT INTO `smi_region` VALUES ('1219', '其它区', '1214', '3', '1164,1214', '0', '1');
INSERT INTO `smi_region` VALUES ('1220', '铜陵市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1221', '铜官山区', '1220', '3', '1164,1220', '0', '1');
INSERT INTO `smi_region` VALUES ('1222', '狮子山区', '1220', '3', '1164,1220', '0', '1');
INSERT INTO `smi_region` VALUES ('1223', '郊区', '1220', '3', '1164,1220', '0', '1');
INSERT INTO `smi_region` VALUES ('1224', '铜陵县', '1220', '3', '1164,1220', '0', '1');
INSERT INTO `smi_region` VALUES ('1225', '其它区', '1220', '3', '1164,1220', '0', '1');
INSERT INTO `smi_region` VALUES ('1226', '安庆市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1227', '迎江区', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1228', '大观区', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1229', '宜秀区', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1230', '怀宁县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1231', '枞阳县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1232', '潜山县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1233', '太湖县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1234', '宿松县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1235', '望江县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1236', '岳西县', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1237', '桐城市', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1238', '其它区', '1226', '3', '1164,1226', '0', '1');
INSERT INTO `smi_region` VALUES ('1239', '黄山市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1240', '屯溪区', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1241', '黄山区', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1242', '徽州区', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1243', '歙县', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1244', '休宁县', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1245', '黟县', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1246', '祁门县', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1247', '其它区', '1239', '3', '1164,1239', '0', '1');
INSERT INTO `smi_region` VALUES ('1248', '滁州市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1249', '琅琊区', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1250', '南谯区', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1251', '来安县', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1252', '全椒县', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1253', '定远县', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1254', '凤阳县', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1255', '天长市', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1256', '明光市', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1257', '其它区', '1248', '3', '1164,1248', '0', '1');
INSERT INTO `smi_region` VALUES ('1258', '阜阳市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1259', '颍州区', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1260', '颍东区', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1261', '颍泉区', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1262', '临泉县', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1263', '太和县', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1264', '阜南县', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1265', '颍上县', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1266', '界首市', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1267', '其它区', '1258', '3', '1164,1258', '0', '1');
INSERT INTO `smi_region` VALUES ('1268', '宿州市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1269', '埇桥区', '1268', '3', '1164,1268', '0', '1');
INSERT INTO `smi_region` VALUES ('1270', '砀山县', '1268', '3', '1164,1268', '0', '1');
INSERT INTO `smi_region` VALUES ('1271', '萧县', '1268', '3', '1164,1268', '0', '1');
INSERT INTO `smi_region` VALUES ('1272', '灵璧县', '1268', '3', '1164,1268', '0', '1');
INSERT INTO `smi_region` VALUES ('1273', '泗县', '1268', '3', '1164,1268', '0', '1');
INSERT INTO `smi_region` VALUES ('1274', '其它区', '1268', '3', '1164,1268', '0', '1');
INSERT INTO `smi_region` VALUES ('1275', '六安市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1276', '金安区', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1277', '裕安区', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1278', '寿县', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1279', '霍邱县', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1280', '舒城县', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1281', '金寨县', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1282', '霍山县', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1283', '其它区', '1275', '3', '1164,1275', '0', '1');
INSERT INTO `smi_region` VALUES ('1284', '亳州市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1285', '谯城区', '1284', '3', '1164,1284', '0', '1');
INSERT INTO `smi_region` VALUES ('1286', '涡阳县', '1284', '3', '1164,1284', '0', '1');
INSERT INTO `smi_region` VALUES ('1287', '蒙城县', '1284', '3', '1164,1284', '0', '1');
INSERT INTO `smi_region` VALUES ('1288', '利辛县', '1284', '3', '1164,1284', '0', '1');
INSERT INTO `smi_region` VALUES ('1289', '其它区', '1284', '3', '1164,1284', '0', '1');
INSERT INTO `smi_region` VALUES ('1290', '池州市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1291', '贵池区', '1290', '3', '1164,1290', '0', '1');
INSERT INTO `smi_region` VALUES ('1292', '东至县', '1290', '3', '1164,1290', '0', '1');
INSERT INTO `smi_region` VALUES ('1293', '石台县', '1290', '3', '1164,1290', '0', '1');
INSERT INTO `smi_region` VALUES ('1294', '青阳县', '1290', '3', '1164,1290', '0', '1');
INSERT INTO `smi_region` VALUES ('1295', '其它区', '1290', '3', '1164,1290', '0', '1');
INSERT INTO `smi_region` VALUES ('1296', '宣城市', '1164', '2', '1164', '0', '1');
INSERT INTO `smi_region` VALUES ('1297', '宣州区', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1298', '郎溪县', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1299', '广德县', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1300', '泾县', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1301', '绩溪县', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1302', '旌德县', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1303', '宁国市', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1304', '其它区', '1296', '3', '1164,1296', '0', '1');
INSERT INTO `smi_region` VALUES ('1305', '福建省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1306', '福州市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1307', '鼓楼区', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1308', '台江区', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1309', '仓山区', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1310', '马尾区', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1311', '晋安区', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1312', '闽侯县', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1313', '连江县', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1314', '罗源县', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1315', '闽清县', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1316', '永泰县', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1317', '平潭县', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1318', '福清市', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1319', '长乐市', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1320', '其它区', '1306', '3', '1305,1306', '0', '1');
INSERT INTO `smi_region` VALUES ('1321', '厦门市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1322', '思明区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1323', '海沧区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1324', '湖里区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1325', '集美区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1326', '同安区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1327', '翔安区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1328', '其它区', '1321', '3', '1305,1321', '0', '1');
INSERT INTO `smi_region` VALUES ('1329', '莆田市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1330', '城厢区', '1329', '3', '1305,1329', '0', '1');
INSERT INTO `smi_region` VALUES ('1331', '涵江区', '1329', '3', '1305,1329', '0', '1');
INSERT INTO `smi_region` VALUES ('1332', '荔城区', '1329', '3', '1305,1329', '0', '1');
INSERT INTO `smi_region` VALUES ('1333', '秀屿区', '1329', '3', '1305,1329', '0', '1');
INSERT INTO `smi_region` VALUES ('1334', '仙游县', '1329', '3', '1305,1329', '0', '1');
INSERT INTO `smi_region` VALUES ('1335', '其它区', '1329', '3', '1305,1329', '0', '1');
INSERT INTO `smi_region` VALUES ('1336', '三明市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1337', '梅列区', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1338', '三元区', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1339', '明溪县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1340', '清流县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1341', '宁化县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1342', '大田县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1343', '尤溪县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1344', '沙县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1345', '将乐县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1346', '泰宁县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1347', '建宁县', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1348', '永安市', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1349', '其它区', '1336', '3', '1305,1336', '0', '1');
INSERT INTO `smi_region` VALUES ('1350', '泉州市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1351', '鲤城区', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1352', '丰泽区', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1353', '洛江区', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1354', '泉港区', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1355', '惠安县', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1356', '安溪县', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1357', '永春县', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1358', '德化县', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1359', '金门县', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1360', '石狮市', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1361', '晋江市', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1362', '南安市', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1363', '其它区', '1350', '3', '1305,1350', '0', '1');
INSERT INTO `smi_region` VALUES ('1364', '漳州市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1365', '芗城区', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1366', '龙文区', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1367', '云霄县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1368', '漳浦县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1369', '诏安县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1370', '长泰县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1371', '东山县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1372', '南靖县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1373', '平和县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1374', '华安县', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1375', '龙海市', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1376', '其它区', '1364', '3', '1305,1364', '0', '1');
INSERT INTO `smi_region` VALUES ('1377', '南平市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1378', '延平区', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1379', '顺昌县', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1380', '浦城县', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1381', '光泽县', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1382', '松溪县', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1383', '政和县', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1384', '邵武市', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1385', '武夷山市', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1386', '建瓯市', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1387', '建阳市', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1388', '其它区', '1377', '3', '1305,1377', '0', '1');
INSERT INTO `smi_region` VALUES ('1389', '龙岩市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1390', '新罗区', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1391', '长汀县', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1392', '永定县', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1393', '上杭县', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1394', '武平县', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1395', '连城县', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1396', '漳平市', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1397', '其它区', '1389', '3', '1305,1389', '0', '1');
INSERT INTO `smi_region` VALUES ('1398', '宁德市', '1305', '2', '1305', '0', '1');
INSERT INTO `smi_region` VALUES ('1399', '蕉城区', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1400', '霞浦县', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1401', '古田县', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1402', '屏南县', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1403', '寿宁县', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1404', '周宁县', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1405', '柘荣县', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1406', '福安市', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1407', '福鼎市', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1408', '其它区', '1398', '3', '1305,1398', '0', '1');
INSERT INTO `smi_region` VALUES ('1409', '江西省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1410', '南昌市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1411', '东湖区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1412', '西湖区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1413', '青云谱区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1414', '湾里区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1415', '青山湖区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1416', '南昌县', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1417', '新建县', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1418', '安义县', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1419', '进贤县', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1420', '红谷滩新区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1421', '经济技术开发区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1422', '昌北区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1423', '其它区', '1410', '3', '1409,1410', '0', '1');
INSERT INTO `smi_region` VALUES ('1424', '景德镇市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1425', '昌江区', '1424', '3', '1409,1424', '0', '1');
INSERT INTO `smi_region` VALUES ('1426', '珠山区', '1424', '3', '1409,1424', '0', '1');
INSERT INTO `smi_region` VALUES ('1427', '浮梁县', '1424', '3', '1409,1424', '0', '1');
INSERT INTO `smi_region` VALUES ('1428', '乐平市', '1424', '3', '1409,1424', '0', '1');
INSERT INTO `smi_region` VALUES ('1429', '其它区', '1424', '3', '1409,1424', '0', '1');
INSERT INTO `smi_region` VALUES ('1430', '萍乡市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1431', '安源区', '1430', '3', '1409,1430', '0', '1');
INSERT INTO `smi_region` VALUES ('1432', '湘东区', '1430', '3', '1409,1430', '0', '1');
INSERT INTO `smi_region` VALUES ('1433', '莲花县', '1430', '3', '1409,1430', '0', '1');
INSERT INTO `smi_region` VALUES ('1434', '上栗县', '1430', '3', '1409,1430', '0', '1');
INSERT INTO `smi_region` VALUES ('1435', '芦溪县', '1430', '3', '1409,1430', '0', '1');
INSERT INTO `smi_region` VALUES ('1436', '其它区', '1430', '3', '1409,1430', '0', '1');
INSERT INTO `smi_region` VALUES ('1437', '九江市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1438', '庐山区', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1439', '浔阳区', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1440', '九江县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1441', '武宁县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1442', '修水县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1443', '永修县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1444', '德安县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1445', '星子县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1446', '都昌县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1447', '湖口县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1448', '彭泽县', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1449', '瑞昌市', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1450', '其它区', '1437', '3', '1409,1437', '0', '1');
INSERT INTO `smi_region` VALUES ('1451', '新余市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1452', '渝水区', '1451', '3', '1409,1451', '0', '1');
INSERT INTO `smi_region` VALUES ('1453', '分宜县', '1451', '3', '1409,1451', '0', '1');
INSERT INTO `smi_region` VALUES ('1454', '其它区', '1451', '3', '1409,1451', '0', '1');
INSERT INTO `smi_region` VALUES ('1455', '鹰潭市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1456', '月湖区', '1455', '3', '1409,1455', '0', '1');
INSERT INTO `smi_region` VALUES ('1457', '余江县', '1455', '3', '1409,1455', '0', '1');
INSERT INTO `smi_region` VALUES ('1458', '贵溪市', '1455', '3', '1409,1455', '0', '1');
INSERT INTO `smi_region` VALUES ('1459', '其它区', '1455', '3', '1409,1455', '0', '1');
INSERT INTO `smi_region` VALUES ('1460', '赣州市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1461', '章贡区', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1462', '赣县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1463', '信丰县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1464', '大余县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1465', '上犹县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1466', '崇义县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1467', '安远县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1468', '龙南县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1469', '定南县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1470', '全南县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1471', '宁都县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1472', '于都县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1473', '兴国县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1474', '会昌县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1475', '寻乌县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1476', '石城县', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1477', '黄金区', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1478', '瑞金市', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1479', '南康市', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1480', '其它区', '1460', '3', '1409,1460', '0', '1');
INSERT INTO `smi_region` VALUES ('1481', '吉安市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1482', '吉州区', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1483', '青原区', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1484', '吉安县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1485', '吉水县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1486', '峡江县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1487', '新干县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1488', '永丰县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1489', '泰和县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1490', '遂川县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1491', '万安县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1492', '安福县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1493', '永新县', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1494', '井冈山市', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1495', '其它区', '1481', '3', '1409,1481', '0', '1');
INSERT INTO `smi_region` VALUES ('1496', '宜春市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1497', '袁州区', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1498', '奉新县', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1499', '万载县', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1500', '上高县', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1501', '宜丰县', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1502', '靖安县', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1503', '铜鼓县', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1504', '丰城市', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1505', '樟树市', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1506', '高安市', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1507', '其它区', '1496', '3', '1409,1496', '0', '1');
INSERT INTO `smi_region` VALUES ('1508', '抚州市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1509', '临川区', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1510', '南城县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1511', '黎川县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1512', '南丰县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1513', '崇仁县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1514', '乐安县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1515', '宜黄县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1516', '金溪县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1517', '资溪县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1518', '东乡县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1519', '广昌县', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1520', '其它区', '1508', '3', '1409,1508', '0', '1');
INSERT INTO `smi_region` VALUES ('1521', '上饶市', '1409', '2', '1409', '0', '1');
INSERT INTO `smi_region` VALUES ('1522', '信州区', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1523', '上饶县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1524', '广丰县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1525', '玉山县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1526', '铅山县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1527', '横峰县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1528', '弋阳县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1529', '余干县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1530', '鄱阳县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1531', '万年县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1532', '婺源县', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1533', '德兴市', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1534', '其它区', '1521', '3', '1409,1521', '0', '1');
INSERT INTO `smi_region` VALUES ('1535', '山东省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1536', '济南市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1537', '历下区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1538', '市中区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1539', '槐荫区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1540', '天桥区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1541', '历城区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1542', '长清区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1543', '平阴县', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1544', '济阳县', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1545', '商河县', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1546', '章丘市', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1547', '其它区', '1536', '3', '1535,1536', '0', '1');
INSERT INTO `smi_region` VALUES ('1548', '青岛市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1549', '市南区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1550', '市北区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1551', '四方区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1552', '黄岛区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1553', '崂山区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1554', '李沧区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1555', '城阳区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1556', '开发区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1557', '胶州市', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1558', '即墨市', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1559', '平度市', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1560', '胶南市', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1561', '莱西市', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1562', '其它区', '1548', '3', '1535,1548', '0', '1');
INSERT INTO `smi_region` VALUES ('1563', '淄博市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1564', '淄川区', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1565', '张店区', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1566', '博山区', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1567', '临淄区', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1568', '周村区', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1569', '桓台县', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1570', '高青县', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1571', '沂源县', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1572', '其它区', '1563', '3', '1535,1563', '0', '1');
INSERT INTO `smi_region` VALUES ('1573', '枣庄市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1574', '市中区', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1575', '薛城区', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1576', '峄城区', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1577', '台儿庄区', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1578', '山亭区', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1579', '滕州市', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1580', '其它区', '1573', '3', '1535,1573', '0', '1');
INSERT INTO `smi_region` VALUES ('1581', '东营市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1582', '东营区', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1583', '河口区', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1584', '垦利县', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1585', '利津县', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1586', '广饶县', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1587', '西城区', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1588', '东城区', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1589', '其它区', '1581', '3', '1535,1581', '0', '1');
INSERT INTO `smi_region` VALUES ('1590', '烟台市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1591', '芝罘区', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1592', '福山区', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1593', '牟平区', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1594', '莱山区', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1595', '长岛县', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1596', '龙口市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1597', '莱阳市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1598', '莱州市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1599', '蓬莱市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1600', '招远市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1601', '栖霞市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1602', '海阳市', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1603', '其它区', '1590', '3', '1535,1590', '0', '1');
INSERT INTO `smi_region` VALUES ('1604', '潍坊市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1605', '潍城区', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1606', '寒亭区', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1607', '坊子区', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1608', '奎文区', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1609', '临朐县', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1610', '昌乐县', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1611', '开发区', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1612', '青州市', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1613', '诸城市', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1614', '寿光市', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1615', '安丘市', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1616', '高密市', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1617', '昌邑市', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1618', '其它区', '1604', '3', '1535,1604', '0', '1');
INSERT INTO `smi_region` VALUES ('1619', '济宁市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1620', '市中区', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1621', '任城区', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1622', '微山县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1623', '鱼台县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1624', '金乡县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1625', '嘉祥县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1626', '汶上县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1627', '泗水县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1628', '梁山县', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1629', '曲阜市', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1630', '兖州市', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1631', '邹城市', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1632', '其它区', '1619', '3', '1535,1619', '0', '1');
INSERT INTO `smi_region` VALUES ('1633', '泰安市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1634', '泰山区', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1635', '岱岳区', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1636', '宁阳县', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1637', '东平县', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1638', '新泰市', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1639', '肥城市', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1640', '其它区', '1633', '3', '1535,1633', '0', '1');
INSERT INTO `smi_region` VALUES ('1641', '威海市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1642', '环翠区', '1641', '3', '1535,1641', '0', '1');
INSERT INTO `smi_region` VALUES ('1643', '文登市', '1641', '3', '1535,1641', '0', '1');
INSERT INTO `smi_region` VALUES ('1644', '荣成市', '1641', '3', '1535,1641', '0', '1');
INSERT INTO `smi_region` VALUES ('1645', '乳山市', '1641', '3', '1535,1641', '0', '1');
INSERT INTO `smi_region` VALUES ('1646', '其它区', '1641', '3', '1535,1641', '0', '1');
INSERT INTO `smi_region` VALUES ('1647', '日照市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1648', '东港区', '1647', '3', '1535,1647', '0', '1');
INSERT INTO `smi_region` VALUES ('1649', '岚山区', '1647', '3', '1535,1647', '0', '1');
INSERT INTO `smi_region` VALUES ('1650', '五莲县', '1647', '3', '1535,1647', '0', '1');
INSERT INTO `smi_region` VALUES ('1651', '莒县', '1647', '3', '1535,1647', '0', '1');
INSERT INTO `smi_region` VALUES ('1652', '其它区', '1647', '3', '1535,1647', '0', '1');
INSERT INTO `smi_region` VALUES ('1653', '莱芜市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1654', '莱城区', '1653', '3', '1535,1653', '0', '1');
INSERT INTO `smi_region` VALUES ('1655', '钢城区', '1653', '3', '1535,1653', '0', '1');
INSERT INTO `smi_region` VALUES ('1656', '其它区', '1653', '3', '1535,1653', '0', '1');
INSERT INTO `smi_region` VALUES ('1657', '临沂市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1658', '兰山区', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1659', '罗庄区', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1660', '河东区', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1661', '沂南县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1662', '郯城县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1663', '沂水县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1664', '苍山县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1665', '费县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1666', '平邑县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1667', '莒南县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1668', '蒙阴县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1669', '临沭县', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1670', '其它区', '1657', '3', '1535,1657', '0', '1');
INSERT INTO `smi_region` VALUES ('1671', '德州市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1672', '德城区', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1673', '陵县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1674', '宁津县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1675', '庆云县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1676', '临邑县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1677', '齐河县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1678', '平原县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1679', '夏津县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1680', '武城县', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1681', '开发区', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1682', '乐陵市', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1683', '禹城市', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1684', '其它区', '1671', '3', '1535,1671', '0', '1');
INSERT INTO `smi_region` VALUES ('1685', '聊城市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1686', '东昌府区', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1687', '阳谷县', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1688', '莘县', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1689', '茌平县', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1690', '东阿县', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1691', '冠县', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1692', '高唐县', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1693', '临清市', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1694', '其它区', '1685', '3', '1535,1685', '0', '1');
INSERT INTO `smi_region` VALUES ('1695', '滨州市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1696', '滨城区', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1697', '惠民县', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1698', '阳信县', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1699', '无棣县', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1700', '沾化县', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1701', '博兴县', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1702', '邹平县', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1703', '其它区', '1695', '3', '1535,1695', '0', '1');
INSERT INTO `smi_region` VALUES ('1704', '菏泽市', '1535', '2', '1535', '0', '1');
INSERT INTO `smi_region` VALUES ('1705', '牡丹区', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1706', '曹县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1707', '单县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1708', '成武县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1709', '巨野县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1710', '郓城县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1711', '鄄城县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1712', '定陶县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1713', '东明县', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1714', '其它区', '1704', '3', '1535,1704', '0', '1');
INSERT INTO `smi_region` VALUES ('1715', '河南省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1716', '郑州市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1717', '中原区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1718', '二七区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1719', '管城回族区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1720', '金水区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1721', '上街区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1722', '惠济区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1723', '中牟县', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1724', '巩义市', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1725', '荥阳市', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1726', '新密市', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1727', '新郑市', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1728', '登封市', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1729', '郑东新区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1730', '高新区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1731', '其它区', '1716', '3', '1715,1716', '0', '1');
INSERT INTO `smi_region` VALUES ('1732', '开封市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1733', '龙亭区', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1734', '顺河回族区', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1735', '鼓楼区', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1736', '禹王台区', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1737', '金明区', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1738', '杞县', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1739', '通许县', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1740', '尉氏县', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1741', '开封县', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1742', '兰考县', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1743', '其它区', '1732', '3', '1715,1732', '0', '1');
INSERT INTO `smi_region` VALUES ('1744', '洛阳市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1745', '老城区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1746', '西工区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1747', '廛河回族区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1748', '涧西区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1749', '吉利区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1750', '洛龙区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1751', '孟津县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1752', '新安县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1753', '栾川县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1754', '嵩县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1755', '汝阳县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1756', '宜阳县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1757', '洛宁县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1758', '伊川县', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1759', '偃师市', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1760', '高新区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1761', '其它区', '1744', '3', '1715,1744', '0', '1');
INSERT INTO `smi_region` VALUES ('1762', '平顶山市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1763', '新华区', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1764', '卫东区', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1765', '石龙区', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1766', '湛河区', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1767', '宝丰县', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1768', '叶县', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1769', '鲁山县', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1770', '郏县', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1771', '舞钢市', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1772', '汝州市', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1773', '其它区', '1762', '3', '1715,1762', '0', '1');
INSERT INTO `smi_region` VALUES ('1774', '安阳市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1775', '文峰区', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1776', '北关区', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1777', '殷都区', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1778', '龙安区', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1779', '安阳县', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1780', '汤阴县', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1781', '滑县', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1782', '内黄县', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1783', '林州市', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1784', '其它区', '1774', '3', '1715,1774', '0', '1');
INSERT INTO `smi_region` VALUES ('1785', '鹤壁市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1786', '鹤山区', '1785', '3', '1715,1785', '0', '1');
INSERT INTO `smi_region` VALUES ('1787', '山城区', '1785', '3', '1715,1785', '0', '1');
INSERT INTO `smi_region` VALUES ('1788', '淇滨区', '1785', '3', '1715,1785', '0', '1');
INSERT INTO `smi_region` VALUES ('1789', '浚县', '1785', '3', '1715,1785', '0', '1');
INSERT INTO `smi_region` VALUES ('1790', '淇县', '1785', '3', '1715,1785', '0', '1');
INSERT INTO `smi_region` VALUES ('1791', '其它区', '1785', '3', '1715,1785', '0', '1');
INSERT INTO `smi_region` VALUES ('1792', '新乡市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1793', '红旗区', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1794', '卫滨区', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1795', '凤泉区', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1796', '牧野区', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1797', '新乡县', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1798', '获嘉县', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1799', '原阳县', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1800', '延津县', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1801', '封丘县', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1802', '长垣县', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1803', '卫辉市', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1804', '辉县市', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1805', '其它区', '1792', '3', '1715,1792', '0', '1');
INSERT INTO `smi_region` VALUES ('1806', '焦作市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1807', '解放区', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1808', '中站区', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1809', '马村区', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1810', '山阳区', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1811', '修武县', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1812', '博爱县', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1813', '武陟县', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1814', '温县', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1815', '沁阳市', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1816', '孟州市', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1817', '其它区', '1806', '3', '1715,1806', '0', '1');
INSERT INTO `smi_region` VALUES ('1818', '济源市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1819', '濮阳市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1820', '华龙区', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1821', '清丰县', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1822', '南乐县', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1823', '范县', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1824', '台前县', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1825', '濮阳县', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1826', '其它区', '1819', '3', '1715,1819', '0', '1');
INSERT INTO `smi_region` VALUES ('1827', '许昌市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1828', '魏都区', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1829', '许昌县', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1830', '鄢陵县', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1831', '襄城县', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1832', '禹州市', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1833', '长葛市', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1834', '其它区', '1827', '3', '1715,1827', '0', '1');
INSERT INTO `smi_region` VALUES ('1835', '漯河市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1836', '源汇区', '1835', '3', '1715,1835', '0', '1');
INSERT INTO `smi_region` VALUES ('1837', '郾城区', '1835', '3', '1715,1835', '0', '1');
INSERT INTO `smi_region` VALUES ('1838', '召陵区', '1835', '3', '1715,1835', '0', '1');
INSERT INTO `smi_region` VALUES ('1839', '舞阳县', '1835', '3', '1715,1835', '0', '1');
INSERT INTO `smi_region` VALUES ('1840', '临颍县', '1835', '3', '1715,1835', '0', '1');
INSERT INTO `smi_region` VALUES ('1841', '其它区', '1835', '3', '1715,1835', '0', '1');
INSERT INTO `smi_region` VALUES ('1842', '三门峡市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1843', '湖滨区', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1844', '渑池县', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1845', '陕县', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1846', '卢氏县', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1847', '义马市', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1848', '灵宝市', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1849', '其它区', '1842', '3', '1715,1842', '0', '1');
INSERT INTO `smi_region` VALUES ('1850', '南阳市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1851', '宛城区', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1852', '卧龙区', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1853', '南召县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1854', '方城县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1855', '西峡县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1856', '镇平县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1857', '内乡县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1858', '淅川县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1859', '社旗县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1860', '唐河县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1861', '新野县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1862', '桐柏县', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1863', '邓州市', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1864', '其它区', '1850', '3', '1715,1850', '0', '1');
INSERT INTO `smi_region` VALUES ('1865', '商丘市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1866', '梁园区', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1867', '睢阳区', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1868', '民权县', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1869', '睢县', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1870', '宁陵县', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1871', '柘城县', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1872', '虞城县', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1873', '夏邑县', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1874', '永城市', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1875', '其它区', '1865', '3', '1715,1865', '0', '1');
INSERT INTO `smi_region` VALUES ('1876', '信阳市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1877', '浉河区', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1878', '平桥区', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1879', '罗山县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1880', '光山县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1881', '新县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1882', '商城县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1883', '固始县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1884', '潢川县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1885', '淮滨县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1886', '息县', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1887', '其它区', '1876', '3', '1715,1876', '0', '1');
INSERT INTO `smi_region` VALUES ('1888', '周口市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1889', '川汇区', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1890', '扶沟县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1891', '西华县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1892', '商水县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1893', '沈丘县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1894', '郸城县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1895', '淮阳县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1896', '太康县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1897', '鹿邑县', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1898', '项城市', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1899', '其它区', '1888', '3', '1715,1888', '0', '1');
INSERT INTO `smi_region` VALUES ('1900', '驻马店市', '1715', '2', '1715', '0', '1');
INSERT INTO `smi_region` VALUES ('1901', '驿城区', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1902', '西平县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1903', '上蔡县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1904', '平舆县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1905', '正阳县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1906', '确山县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1907', '泌阳县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1908', '汝南县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1909', '遂平县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1910', '新蔡县', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1911', '其它区', '1900', '3', '1715,1900', '0', '1');
INSERT INTO `smi_region` VALUES ('1912', '湖北省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('1913', '武汉市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1914', '江岸区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1915', '江汉区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1916', '硚口区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1917', '汉阳区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1918', '武昌区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1919', '青山区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1920', '洪山区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1921', '东西湖区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1922', '汉南区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1923', '蔡甸区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1924', '江夏区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1925', '黄陂区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1926', '新洲区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1927', '其它区', '1913', '3', '1912,1913', '0', '1');
INSERT INTO `smi_region` VALUES ('1928', '黄石市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1929', '黄石港区', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1930', '西塞山区', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1931', '下陆区', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1932', '铁山区', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1933', '阳新县', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1934', '大冶市', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1935', '其它区', '1928', '3', '1912,1928', '0', '1');
INSERT INTO `smi_region` VALUES ('1936', '十堰市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1937', '茅箭区', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1938', '张湾区', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1939', '郧县', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1940', '郧西县', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1941', '竹山县', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1942', '竹溪县', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1943', '房县', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1944', '丹江口市', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1945', '城区', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1946', '其它区', '1936', '3', '1912,1936', '0', '1');
INSERT INTO `smi_region` VALUES ('1947', '宜昌市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1948', '西陵区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1949', '伍家岗区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1950', '点军区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1951', '猇亭区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1952', '夷陵区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1953', '远安县', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1954', '兴山县', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1955', '秭归县', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1956', '长阳土家族自治县', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1957', '五峰土家族自治县', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1958', '葛洲坝区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1959', '开发区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1960', '宜都市', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1961', '当阳市', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1962', '枝江市', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1963', '其它区', '1947', '3', '1912,1947', '0', '1');
INSERT INTO `smi_region` VALUES ('1964', '襄阳市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1965', '襄城区', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1966', '樊城区', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1967', '襄州区', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1968', '南漳县', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1969', '谷城县', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1970', '保康县', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1971', '老河口市', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1972', '枣阳市', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1973', '宜城市', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1974', '其它区', '1964', '3', '1912,1964', '0', '1');
INSERT INTO `smi_region` VALUES ('1975', '鄂州市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1976', '梁子湖区', '1975', '3', '1912,1975', '0', '1');
INSERT INTO `smi_region` VALUES ('1977', '华容区', '1975', '3', '1912,1975', '0', '1');
INSERT INTO `smi_region` VALUES ('1978', '鄂城区', '1975', '3', '1912,1975', '0', '1');
INSERT INTO `smi_region` VALUES ('1979', '其它区', '1975', '3', '1912,1975', '0', '1');
INSERT INTO `smi_region` VALUES ('1980', '荆门市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1981', '东宝区', '1980', '3', '1912,1980', '0', '1');
INSERT INTO `smi_region` VALUES ('1982', '掇刀区', '1980', '3', '1912,1980', '0', '1');
INSERT INTO `smi_region` VALUES ('1983', '京山县', '1980', '3', '1912,1980', '0', '1');
INSERT INTO `smi_region` VALUES ('1984', '沙洋县', '1980', '3', '1912,1980', '0', '1');
INSERT INTO `smi_region` VALUES ('1985', '钟祥市', '1980', '3', '1912,1980', '0', '1');
INSERT INTO `smi_region` VALUES ('1986', '其它区', '1980', '3', '1912,1980', '0', '1');
INSERT INTO `smi_region` VALUES ('1987', '孝感市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1988', '孝南区', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1989', '孝昌县', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1990', '大悟县', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1991', '云梦县', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1992', '应城市', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1993', '安陆市', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1994', '汉川市', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1995', '其它区', '1987', '3', '1912,1987', '0', '1');
INSERT INTO `smi_region` VALUES ('1996', '荆州市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('1997', '沙市区', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('1998', '荆州区', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('1999', '公安县', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2000', '监利县', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2001', '江陵县', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2002', '石首市', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2003', '洪湖市', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2004', '松滋市', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2005', '其它区', '1996', '3', '1912,1996', '0', '1');
INSERT INTO `smi_region` VALUES ('2006', '黄冈市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2007', '黄州区', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2008', '团风县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2009', '红安县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2010', '罗田县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2011', '英山县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2012', '浠水县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2013', '蕲春县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2014', '黄梅县', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2015', '麻城市', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2016', '武穴市', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2017', '其它区', '2006', '3', '1912,2006', '0', '1');
INSERT INTO `smi_region` VALUES ('2018', '咸宁市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2019', '咸安区', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2020', '嘉鱼县', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2021', '通城县', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2022', '崇阳县', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2023', '通山县', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2024', '赤壁市', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2025', '温泉城区', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2026', '其它区', '2018', '3', '1912,2018', '0', '1');
INSERT INTO `smi_region` VALUES ('2027', '随州市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2028', '曾都区', '2027', '3', '1912,2027', '0', '1');
INSERT INTO `smi_region` VALUES ('2029', '随县', '2027', '3', '1912,2027', '0', '1');
INSERT INTO `smi_region` VALUES ('2030', '广水市', '2027', '3', '1912,2027', '0', '1');
INSERT INTO `smi_region` VALUES ('2031', '其它区', '2027', '3', '1912,2027', '0', '1');
INSERT INTO `smi_region` VALUES ('2032', '恩施土家族苗族自治州', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2033', '恩施市', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2034', '利川市', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2035', '建始县', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2036', '巴东县', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2037', '宣恩县', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2038', '咸丰县', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2039', '来凤县', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2040', '鹤峰县', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2041', '其它区', '2032', '3', '1912,2032', '0', '1');
INSERT INTO `smi_region` VALUES ('2042', '仙桃市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2043', '潜江市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2044', '天门市', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2045', '神农架林区', '1912', '2', '1912', '0', '1');
INSERT INTO `smi_region` VALUES ('2046', '湖南省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2047', '长沙市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2048', '芙蓉区', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2049', '天心区', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2050', '岳麓区', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2051', '开福区', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2052', '雨花区', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2053', '长沙县', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2054', '望城县', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2055', '宁乡县', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2056', '浏阳市', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2057', '其它区', '2047', '3', '2046,2047', '0', '1');
INSERT INTO `smi_region` VALUES ('2058', '株洲市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2059', '荷塘区', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2060', '芦淞区', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2061', '石峰区', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2062', '天元区', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2063', '株洲县', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2064', '攸县', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2065', '茶陵县', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2066', '炎陵县', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2067', '醴陵市', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2068', '其它区', '2058', '3', '2046,2058', '0', '1');
INSERT INTO `smi_region` VALUES ('2069', '湘潭市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2070', '雨湖区', '2069', '3', '2046,2069', '0', '1');
INSERT INTO `smi_region` VALUES ('2071', '岳塘区', '2069', '3', '2046,2069', '0', '1');
INSERT INTO `smi_region` VALUES ('2072', '湘潭县', '2069', '3', '2046,2069', '0', '1');
INSERT INTO `smi_region` VALUES ('2073', '湘乡市', '2069', '3', '2046,2069', '0', '1');
INSERT INTO `smi_region` VALUES ('2074', '韶山市', '2069', '3', '2046,2069', '0', '1');
INSERT INTO `smi_region` VALUES ('2075', '其它区', '2069', '3', '2046,2069', '0', '1');
INSERT INTO `smi_region` VALUES ('2076', '衡阳市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2077', '珠晖区', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2078', '雁峰区', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2079', '石鼓区', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2080', '蒸湘区', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2081', '南岳区', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2082', '衡阳县', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2083', '衡南县', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2084', '衡山县', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2085', '衡东县', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2086', '祁东县', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2087', '耒阳市', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2088', '常宁市', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2089', '其它区', '2076', '3', '2046,2076', '0', '1');
INSERT INTO `smi_region` VALUES ('2090', '邵阳市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2091', '双清区', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2092', '大祥区', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2093', '北塔区', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2094', '邵东县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2095', '新邵县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2096', '邵阳县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2097', '隆回县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2098', '洞口县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2099', '绥宁县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2100', '新宁县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2101', '城步苗族自治县', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2102', '武冈市', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2103', '其它区', '2090', '3', '2046,2090', '0', '1');
INSERT INTO `smi_region` VALUES ('2104', '岳阳市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2105', '岳阳楼区', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2106', '云溪区', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2107', '君山区', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2108', '岳阳县', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2109', '华容县', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2110', '湘阴县', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2111', '平江县', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2112', '汨罗市', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2113', '临湘市', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2114', '其它区', '2104', '3', '2046,2104', '0', '1');
INSERT INTO `smi_region` VALUES ('2115', '常德市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2116', '武陵区', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2117', '鼎城区', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2118', '安乡县', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2119', '汉寿县', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2120', '澧县', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2121', '临澧县', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2122', '桃源县', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2123', '石门县', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2124', '津市市', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2125', '其它区', '2115', '3', '2046,2115', '0', '1');
INSERT INTO `smi_region` VALUES ('2126', '张家界市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2127', '永定区', '2126', '3', '2046,2126', '0', '1');
INSERT INTO `smi_region` VALUES ('2128', '武陵源区', '2126', '3', '2046,2126', '0', '1');
INSERT INTO `smi_region` VALUES ('2129', '慈利县', '2126', '3', '2046,2126', '0', '1');
INSERT INTO `smi_region` VALUES ('2130', '桑植县', '2126', '3', '2046,2126', '0', '1');
INSERT INTO `smi_region` VALUES ('2131', '其它区', '2126', '3', '2046,2126', '0', '1');
INSERT INTO `smi_region` VALUES ('2132', '益阳市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2133', '资阳区', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2134', '赫山区', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2135', '南县', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2136', '桃江县', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2137', '安化县', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2138', '沅江市', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2139', '其它区', '2132', '3', '2046,2132', '0', '1');
INSERT INTO `smi_region` VALUES ('2140', '郴州市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2141', '北湖区', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2142', '苏仙区', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2143', '桂阳县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2144', '宜章县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2145', '永兴县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2146', '嘉禾县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2147', '临武县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2148', '汝城县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2149', '桂东县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2150', '安仁县', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2151', '资兴市', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2152', '其它区', '2140', '3', '2046,2140', '0', '1');
INSERT INTO `smi_region` VALUES ('2153', '永州市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2154', '零陵区', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2155', '冷水滩区', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2156', '祁阳县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2157', '东安县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2158', '双牌县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2159', '道县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2160', '江永县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2161', '宁远县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2162', '蓝山县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2163', '新田县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2164', '江华瑶族自治县', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2165', '其它区', '2153', '3', '2046,2153', '0', '1');
INSERT INTO `smi_region` VALUES ('2166', '怀化市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2167', '鹤城区', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2168', '中方县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2169', '沅陵县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2170', '辰溪县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2171', '溆浦县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2172', '会同县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2173', '麻阳苗族自治县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2174', '新晃侗族自治县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2175', '芷江侗族自治县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2176', '靖州苗族侗族自治县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2177', '通道侗族自治县', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2178', '洪江市', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2179', '其它区', '2166', '3', '2046,2166', '0', '1');
INSERT INTO `smi_region` VALUES ('2180', '娄底市', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2181', '娄星区', '2180', '3', '2046,2180', '0', '1');
INSERT INTO `smi_region` VALUES ('2182', '双峰县', '2180', '3', '2046,2180', '0', '1');
INSERT INTO `smi_region` VALUES ('2183', '新化县', '2180', '3', '2046,2180', '0', '1');
INSERT INTO `smi_region` VALUES ('2184', '冷水江市', '2180', '3', '2046,2180', '0', '1');
INSERT INTO `smi_region` VALUES ('2185', '涟源市', '2180', '3', '2046,2180', '0', '1');
INSERT INTO `smi_region` VALUES ('2186', '其它区', '2180', '3', '2046,2180', '0', '1');
INSERT INTO `smi_region` VALUES ('2187', '湘西土家族苗族自治州', '2046', '2', '2046', '0', '1');
INSERT INTO `smi_region` VALUES ('2188', '吉首市', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2189', '泸溪县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2190', '凤凰县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2191', '花垣县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2192', '保靖县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2193', '古丈县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2194', '永顺县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2195', '龙山县', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2196', '其它区', '2187', '3', '2046,2187', '0', '1');
INSERT INTO `smi_region` VALUES ('2197', '广东省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2198', '广州市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2199', '荔湾区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2200', '越秀区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2201', '海珠区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2202', '天河区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2203', '白云区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2204', '黄埔区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2205', '番禺区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2206', '花都区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2207', '南沙区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2208', '萝岗区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2209', '增城市', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2210', '从化市', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2211', '东山区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2212', '其它区', '2198', '3', '2197,2198', '0', '1');
INSERT INTO `smi_region` VALUES ('2213', '韶关市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2214', '武江区', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2215', '浈江区', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2216', '曲江区', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2217', '始兴县', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2218', '仁化县', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2219', '翁源县', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2220', '乳源瑶族自治县', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2221', '新丰县', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2222', '乐昌市', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2223', '南雄市', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2224', '其它区', '2213', '3', '2197,2213', '0', '1');
INSERT INTO `smi_region` VALUES ('2225', '深圳市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2226', '罗湖区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2227', '福田区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2228', '南山区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2229', '宝安区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2230', '龙岗区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2231', '盐田区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2232', '其它区', '2225', '3', '2197,2225', '0', '1');
INSERT INTO `smi_region` VALUES ('2233', '珠海市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2234', '香洲区', '2233', '3', '2197,2233', '0', '1');
INSERT INTO `smi_region` VALUES ('2235', '斗门区', '2233', '3', '2197,2233', '0', '1');
INSERT INTO `smi_region` VALUES ('2236', '金湾区', '2233', '3', '2197,2233', '0', '1');
INSERT INTO `smi_region` VALUES ('2237', '金唐区', '2233', '3', '2197,2233', '0', '1');
INSERT INTO `smi_region` VALUES ('2238', '南湾区', '2233', '3', '2197,2233', '0', '1');
INSERT INTO `smi_region` VALUES ('2239', '其它区', '2233', '3', '2197,2233', '0', '1');
INSERT INTO `smi_region` VALUES ('2240', '汕头市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2241', '龙湖区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2242', '金平区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2243', '濠江区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2244', '潮阳区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2245', '潮南区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2246', '澄海区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2247', '南澳县', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2248', '其它区', '2240', '3', '2197,2240', '0', '1');
INSERT INTO `smi_region` VALUES ('2249', '佛山市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2250', '禅城区', '2249', '3', '2197,2249', '0', '1');
INSERT INTO `smi_region` VALUES ('2251', '南海区', '2249', '3', '2197,2249', '0', '1');
INSERT INTO `smi_region` VALUES ('2252', '顺德区', '2249', '3', '2197,2249', '0', '1');
INSERT INTO `smi_region` VALUES ('2253', '三水区', '2249', '3', '2197,2249', '0', '1');
INSERT INTO `smi_region` VALUES ('2254', '高明区', '2249', '3', '2197,2249', '0', '1');
INSERT INTO `smi_region` VALUES ('2255', '其它区', '2249', '3', '2197,2249', '0', '1');
INSERT INTO `smi_region` VALUES ('2256', '江门市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2257', '蓬江区', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2258', '江海区', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2259', '新会区', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2260', '台山市', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2261', '开平市', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2262', '鹤山市', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2263', '恩平市', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2264', '其它区', '2256', '3', '2197,2256', '0', '1');
INSERT INTO `smi_region` VALUES ('2265', '湛江市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2266', '赤坎区', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2267', '霞山区', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2268', '坡头区', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2269', '麻章区', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2270', '遂溪县', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2271', '徐闻县', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2272', '廉江市', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2273', '雷州市', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2274', '吴川市', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2275', '其它区', '2265', '3', '2197,2265', '0', '1');
INSERT INTO `smi_region` VALUES ('2276', '茂名市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2277', '茂南区', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2278', '茂港区', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2279', '电白县', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2280', '高州市', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2281', '化州市', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2282', '信宜市', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2283', '其它区', '2276', '3', '2197,2276', '0', '1');
INSERT INTO `smi_region` VALUES ('2284', '肇庆市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2285', '端州区', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2286', '鼎湖区', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2287', '广宁县', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2288', '怀集县', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2289', '封开县', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2290', '德庆县', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2291', '高要市', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2292', '四会市', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2293', '其它区', '2284', '3', '2197,2284', '0', '1');
INSERT INTO `smi_region` VALUES ('2294', '惠州市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2295', '惠城区', '2294', '3', '2197,2294', '0', '1');
INSERT INTO `smi_region` VALUES ('2296', '惠阳区', '2294', '3', '2197,2294', '0', '1');
INSERT INTO `smi_region` VALUES ('2297', '博罗县', '2294', '3', '2197,2294', '0', '1');
INSERT INTO `smi_region` VALUES ('2298', '惠东县', '2294', '3', '2197,2294', '0', '1');
INSERT INTO `smi_region` VALUES ('2299', '龙门县', '2294', '3', '2197,2294', '0', '1');
INSERT INTO `smi_region` VALUES ('2300', '其它区', '2294', '3', '2197,2294', '0', '1');
INSERT INTO `smi_region` VALUES ('2301', '梅州市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2302', '梅江区', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2303', '梅县', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2304', '大埔县', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2305', '丰顺县', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2306', '五华县', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2307', '平远县', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2308', '蕉岭县', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2309', '兴宁市', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2310', '其它区', '2301', '3', '2197,2301', '0', '1');
INSERT INTO `smi_region` VALUES ('2311', '汕尾市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2312', '城区', '2311', '3', '2197,2311', '0', '1');
INSERT INTO `smi_region` VALUES ('2313', '海丰县', '2311', '3', '2197,2311', '0', '1');
INSERT INTO `smi_region` VALUES ('2314', '陆河县', '2311', '3', '2197,2311', '0', '1');
INSERT INTO `smi_region` VALUES ('2315', '陆丰市', '2311', '3', '2197,2311', '0', '1');
INSERT INTO `smi_region` VALUES ('2316', '其它区', '2311', '3', '2197,2311', '0', '1');
INSERT INTO `smi_region` VALUES ('2317', '河源市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2318', '源城区', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2319', '紫金县', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2320', '龙川县', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2321', '连平县', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2322', '和平县', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2323', '东源县', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2324', '其它区', '2317', '3', '2197,2317', '0', '1');
INSERT INTO `smi_region` VALUES ('2325', '阳江市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2326', '江城区', '2325', '3', '2197,2325', '0', '1');
INSERT INTO `smi_region` VALUES ('2327', '阳西县', '2325', '3', '2197,2325', '0', '1');
INSERT INTO `smi_region` VALUES ('2328', '阳东县', '2325', '3', '2197,2325', '0', '1');
INSERT INTO `smi_region` VALUES ('2329', '阳春市', '2325', '3', '2197,2325', '0', '1');
INSERT INTO `smi_region` VALUES ('2330', '其它区', '2325', '3', '2197,2325', '0', '1');
INSERT INTO `smi_region` VALUES ('2331', '清远市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2332', '清城区', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2333', '佛冈县', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2334', '阳山县', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2335', '连山壮族瑶族自治县', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2336', '连南瑶族自治县', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2337', '清新县', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2338', '英德市', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2339', '连州市', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2340', '其它区', '2331', '3', '2197,2331', '0', '1');
INSERT INTO `smi_region` VALUES ('2341', '东莞市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2342', '中山市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2343', '潮州市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2344', '湘桥区', '2343', '3', '2197,2343', '0', '1');
INSERT INTO `smi_region` VALUES ('2345', '潮安县', '2343', '3', '2197,2343', '0', '1');
INSERT INTO `smi_region` VALUES ('2346', '饶平县', '2343', '3', '2197,2343', '0', '1');
INSERT INTO `smi_region` VALUES ('2347', '枫溪区', '2343', '3', '2197,2343', '0', '1');
INSERT INTO `smi_region` VALUES ('2348', '其它区', '2343', '3', '2197,2343', '0', '1');
INSERT INTO `smi_region` VALUES ('2349', '揭阳市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2350', '榕城区', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2351', '揭东县', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2352', '揭西县', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2353', '惠来县', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2354', '普宁市', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2355', '东山区', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2356', '其它区', '2349', '3', '2197,2349', '0', '1');
INSERT INTO `smi_region` VALUES ('2357', '云浮市', '2197', '2', '2197', '0', '1');
INSERT INTO `smi_region` VALUES ('2358', '云城区', '2357', '3', '2197,2357', '0', '1');
INSERT INTO `smi_region` VALUES ('2359', '新兴县', '2357', '3', '2197,2357', '0', '1');
INSERT INTO `smi_region` VALUES ('2360', '郁南县', '2357', '3', '2197,2357', '0', '1');
INSERT INTO `smi_region` VALUES ('2361', '云安县', '2357', '3', '2197,2357', '0', '1');
INSERT INTO `smi_region` VALUES ('2362', '罗定市', '2357', '3', '2197,2357', '0', '1');
INSERT INTO `smi_region` VALUES ('2363', '其它区', '2357', '3', '2197,2357', '0', '1');
INSERT INTO `smi_region` VALUES ('2364', '广西壮族自治区', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2365', '南宁市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2366', '兴宁区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2367', '青秀区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2368', '江南区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2369', '西乡塘区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2370', '良庆区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2371', '邕宁区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2372', '武鸣县', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2373', '隆安县', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2374', '马山县', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2375', '上林县', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2376', '宾阳县', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2377', '横县', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2378', '其它区', '2365', '3', '2364,2365', '0', '1');
INSERT INTO `smi_region` VALUES ('2379', '柳州市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2380', '城中区', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2381', '鱼峰区', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2382', '柳南区', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2383', '柳北区', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2384', '柳江县', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2385', '柳城县', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2386', '鹿寨县', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2387', '融安县', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2388', '融水苗族自治县', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2389', '三江侗族自治县', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2390', '其它区', '2379', '3', '2364,2379', '0', '1');
INSERT INTO `smi_region` VALUES ('2391', '桂林市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2392', '秀峰区', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2393', '叠彩区', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2394', '象山区', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2395', '七星区', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2396', '雁山区', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2397', '阳朔县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2398', '临桂县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2399', '灵川县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2400', '全州县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2401', '兴安县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2402', '永福县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2403', '灌阳县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2404', '龙胜各族自治县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2405', '资源县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2406', '平乐县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2407', '荔浦县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2408', '恭城瑶族自治县', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2409', '其它区', '2391', '3', '2364,2391', '0', '1');
INSERT INTO `smi_region` VALUES ('2410', '梧州市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2411', '万秀区', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2412', '蝶山区', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2413', '长洲区', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2414', '苍梧县', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2415', '藤县', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2416', '蒙山县', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2417', '岑溪市', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2418', '其它区', '2410', '3', '2364,2410', '0', '1');
INSERT INTO `smi_region` VALUES ('2419', '北海市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2420', '海城区', '2419', '3', '2364,2419', '0', '1');
INSERT INTO `smi_region` VALUES ('2421', '银海区', '2419', '3', '2364,2419', '0', '1');
INSERT INTO `smi_region` VALUES ('2422', '铁山港区', '2419', '3', '2364,2419', '0', '1');
INSERT INTO `smi_region` VALUES ('2423', '合浦县', '2419', '3', '2364,2419', '0', '1');
INSERT INTO `smi_region` VALUES ('2424', '其它区', '2419', '3', '2364,2419', '0', '1');
INSERT INTO `smi_region` VALUES ('2425', '防城港市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2426', '港口区', '2425', '3', '2364,2425', '0', '1');
INSERT INTO `smi_region` VALUES ('2427', '防城区', '2425', '3', '2364,2425', '0', '1');
INSERT INTO `smi_region` VALUES ('2428', '上思县', '2425', '3', '2364,2425', '0', '1');
INSERT INTO `smi_region` VALUES ('2429', '东兴市', '2425', '3', '2364,2425', '0', '1');
INSERT INTO `smi_region` VALUES ('2430', '其它区', '2425', '3', '2364,2425', '0', '1');
INSERT INTO `smi_region` VALUES ('2431', '钦州市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2432', '钦南区', '2431', '3', '2364,2431', '0', '1');
INSERT INTO `smi_region` VALUES ('2433', '钦北区', '2431', '3', '2364,2431', '0', '1');
INSERT INTO `smi_region` VALUES ('2434', '灵山县', '2431', '3', '2364,2431', '0', '1');
INSERT INTO `smi_region` VALUES ('2435', '浦北县', '2431', '3', '2364,2431', '0', '1');
INSERT INTO `smi_region` VALUES ('2436', '其它区', '2431', '3', '2364,2431', '0', '1');
INSERT INTO `smi_region` VALUES ('2437', '贵港市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2438', '港北区', '2437', '3', '2364,2437', '0', '1');
INSERT INTO `smi_region` VALUES ('2439', '港南区', '2437', '3', '2364,2437', '0', '1');
INSERT INTO `smi_region` VALUES ('2440', '覃塘区', '2437', '3', '2364,2437', '0', '1');
INSERT INTO `smi_region` VALUES ('2441', '平南县', '2437', '3', '2364,2437', '0', '1');
INSERT INTO `smi_region` VALUES ('2442', '桂平市', '2437', '3', '2364,2437', '0', '1');
INSERT INTO `smi_region` VALUES ('2443', '其它区', '2437', '3', '2364,2437', '0', '1');
INSERT INTO `smi_region` VALUES ('2444', '玉林市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2445', '玉州区', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2446', '容县', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2447', '陆川县', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2448', '博白县', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2449', '兴业县', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2450', '北流市', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2451', '其它区', '2444', '3', '2364,2444', '0', '1');
INSERT INTO `smi_region` VALUES ('2452', '百色市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2453', '右江区', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2454', '田阳县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2455', '田东县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2456', '平果县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2457', '德保县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2458', '靖西县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2459', '那坡县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2460', '凌云县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2461', '乐业县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2462', '田林县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2463', '西林县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2464', '隆林各族自治县', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2465', '其它区', '2452', '3', '2364,2452', '0', '1');
INSERT INTO `smi_region` VALUES ('2466', '贺州市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2467', '八步区', '2466', '3', '2364,2466', '0', '1');
INSERT INTO `smi_region` VALUES ('2468', '昭平县', '2466', '3', '2364,2466', '0', '1');
INSERT INTO `smi_region` VALUES ('2469', '钟山县', '2466', '3', '2364,2466', '0', '1');
INSERT INTO `smi_region` VALUES ('2470', '富川瑶族自治县', '2466', '3', '2364,2466', '0', '1');
INSERT INTO `smi_region` VALUES ('2471', '其它区', '2466', '3', '2364,2466', '0', '1');
INSERT INTO `smi_region` VALUES ('2472', '河池市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2473', '金城江区', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2474', '南丹县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2475', '天峨县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2476', '凤山县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2477', '东兰县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2478', '罗城仫佬族自治县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2479', '环江毛南族自治县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2480', '巴马瑶族自治县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2481', '都安瑶族自治县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2482', '大化瑶族自治县', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2483', '宜州市', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2484', '其它区', '2472', '3', '2364,2472', '0', '1');
INSERT INTO `smi_region` VALUES ('2485', '来宾市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2486', '兴宾区', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2487', '忻城县', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2488', '象州县', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2489', '武宣县', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2490', '金秀瑶族自治县', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2491', '合山市', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2492', '其它区', '2485', '3', '2364,2485', '0', '1');
INSERT INTO `smi_region` VALUES ('2493', '崇左市', '2364', '2', '2364', '0', '1');
INSERT INTO `smi_region` VALUES ('2494', '江州区', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2495', '扶绥县', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2496', '宁明县', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2497', '龙州县', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2498', '大新县', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2499', '天等县', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2500', '凭祥市', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2501', '其它区', '2493', '3', '2364,2493', '0', '1');
INSERT INTO `smi_region` VALUES ('2502', '海南省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2503', '海口市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2504', '秀英区', '2503', '3', '2502,2503', '0', '1');
INSERT INTO `smi_region` VALUES ('2505', '龙华区', '2503', '3', '2502,2503', '0', '1');
INSERT INTO `smi_region` VALUES ('2506', '琼山区', '2503', '3', '2502,2503', '0', '1');
INSERT INTO `smi_region` VALUES ('2507', '美兰区', '2503', '3', '2502,2503', '0', '1');
INSERT INTO `smi_region` VALUES ('2508', '其它区', '2503', '3', '2502,2503', '0', '1');
INSERT INTO `smi_region` VALUES ('2509', '三亚市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2510', '五指山市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2511', '琼海市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2512', '儋州市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2513', '文昌市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2514', '万宁市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2515', '东方市', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2516', '定安县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2517', '屯昌县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2518', '澄迈县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2519', '临高县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2520', '白沙黎族自治县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2521', '昌江黎族自治县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2522', '乐东黎族自治县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2523', '陵水黎族自治县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2524', '保亭黎族苗族自治县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2525', '琼中黎族苗族自治县', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2526', '西沙群岛', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2527', '南沙群岛', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2528', '中沙群岛的岛礁及其海域', '2502', '2', '2502', '0', '1');
INSERT INTO `smi_region` VALUES ('2529', '重庆', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2530', '重庆市', '2529', '2', '2529', '0', '1');
INSERT INTO `smi_region` VALUES ('2531', '万州区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2532', '涪陵区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2533', '渝中区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2534', '大渡口区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2535', '江北区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2536', '沙坪坝区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2537', '九龙坡区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2538', '南岸区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2539', '北碚区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2540', '万盛区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2541', '双桥区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2542', '渝北区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2543', '巴南区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2544', '黔江区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2545', '长寿区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2546', '綦江县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2547', '潼南县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2548', '铜梁县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2549', '大足县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2550', '荣昌县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2551', '璧山县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2552', '梁平县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2553', '城口县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2554', '丰都县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2555', '垫江县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2556', '武隆县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2557', '忠县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2558', '开县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2559', '云阳县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2560', '奉节县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2561', '巫山县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2562', '巫溪县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2563', '石柱土家族自治县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2564', '秀山土家族苗族自治县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2565', '酉阳土家族苗族自治县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2566', '彭水苗族土家族自治县', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2567', '江津区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2568', '合川区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2569', '永川区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2570', '南川区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2571', '其它区', '2530', '3', '2529,2530', '0', '1');
INSERT INTO `smi_region` VALUES ('2572', '四川省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2573', '成都市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2574', '锦江区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2575', '青羊区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2576', '金牛区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2577', '武侯区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2578', '成华区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2579', '龙泉驿区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2580', '青白江区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2581', '新都区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2582', '温江区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2583', '金堂县', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2584', '双流县', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2585', '郫县', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2586', '大邑县', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2587', '蒲江县', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2588', '新津县', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2589', '都江堰市', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2590', '彭州市', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2591', '邛崃市', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2592', '崇州市', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2593', '其它区', '2573', '3', '2572,2573', '0', '1');
INSERT INTO `smi_region` VALUES ('2594', '自贡市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2595', '自流井区', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2596', '贡井区', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2597', '大安区', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2598', '沿滩区', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2599', '荣县', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2600', '富顺县', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2601', '其它区', '2594', '3', '2572,2594', '0', '1');
INSERT INTO `smi_region` VALUES ('2602', '攀枝花市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2603', '东区', '2602', '3', '2572,2602', '0', '1');
INSERT INTO `smi_region` VALUES ('2604', '西区', '2602', '3', '2572,2602', '0', '1');
INSERT INTO `smi_region` VALUES ('2605', '仁和区', '2602', '3', '2572,2602', '0', '1');
INSERT INTO `smi_region` VALUES ('2606', '米易县', '2602', '3', '2572,2602', '0', '1');
INSERT INTO `smi_region` VALUES ('2607', '盐边县', '2602', '3', '2572,2602', '0', '1');
INSERT INTO `smi_region` VALUES ('2608', '其它区', '2602', '3', '2572,2602', '0', '1');
INSERT INTO `smi_region` VALUES ('2609', '泸州市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2610', '江阳区', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2611', '纳溪区', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2612', '龙马潭区', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2613', '泸县', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2614', '合江县', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2615', '叙永县', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2616', '古蔺县', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2617', '其它区', '2609', '3', '2572,2609', '0', '1');
INSERT INTO `smi_region` VALUES ('2618', '德阳市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2619', '旌阳区', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2620', '中江县', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2621', '罗江县', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2622', '广汉市', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2623', '什邡市', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2624', '绵竹市', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2625', '其它区', '2618', '3', '2572,2618', '0', '1');
INSERT INTO `smi_region` VALUES ('2626', '绵阳市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2627', '涪城区', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2628', '游仙区', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2629', '三台县', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2630', '盐亭县', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2631', '安县', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2632', '梓潼县', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2633', '北川羌族自治县', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2634', '平武县', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2635', '高新区', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2636', '江油市', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2637', '其它区', '2626', '3', '2572,2626', '0', '1');
INSERT INTO `smi_region` VALUES ('2638', '广元市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2639', '利州区', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2640', '元坝区', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2641', '朝天区', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2642', '旺苍县', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2643', '青川县', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2644', '剑阁县', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2645', '苍溪县', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2646', '其它区', '2638', '3', '2572,2638', '0', '1');
INSERT INTO `smi_region` VALUES ('2647', '遂宁市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2648', '船山区', '2647', '3', '2572,2647', '0', '1');
INSERT INTO `smi_region` VALUES ('2649', '安居区', '2647', '3', '2572,2647', '0', '1');
INSERT INTO `smi_region` VALUES ('2650', '蓬溪县', '2647', '3', '2572,2647', '0', '1');
INSERT INTO `smi_region` VALUES ('2651', '射洪县', '2647', '3', '2572,2647', '0', '1');
INSERT INTO `smi_region` VALUES ('2652', '大英县', '2647', '3', '2572,2647', '0', '1');
INSERT INTO `smi_region` VALUES ('2653', '其它区', '2647', '3', '2572,2647', '0', '1');
INSERT INTO `smi_region` VALUES ('2654', '内江市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2655', '市中区', '2654', '3', '2572,2654', '0', '1');
INSERT INTO `smi_region` VALUES ('2656', '东兴区', '2654', '3', '2572,2654', '0', '1');
INSERT INTO `smi_region` VALUES ('2657', '威远县', '2654', '3', '2572,2654', '0', '1');
INSERT INTO `smi_region` VALUES ('2658', '资中县', '2654', '3', '2572,2654', '0', '1');
INSERT INTO `smi_region` VALUES ('2659', '隆昌县', '2654', '3', '2572,2654', '0', '1');
INSERT INTO `smi_region` VALUES ('2660', '其它区', '2654', '3', '2572,2654', '0', '1');
INSERT INTO `smi_region` VALUES ('2661', '乐山市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2662', '市中区', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2663', '沙湾区', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2664', '五通桥区', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2665', '金口河区', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2666', '犍为县', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2667', '井研县', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2668', '夹江县', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2669', '沐川县', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2670', '峨边彝族自治县', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2671', '马边彝族自治县', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2672', '峨眉山市', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2673', '其它区', '2661', '3', '2572,2661', '0', '1');
INSERT INTO `smi_region` VALUES ('2674', '南充市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2675', '顺庆区', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2676', '高坪区', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2677', '嘉陵区', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2678', '南部县', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2679', '营山县', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2680', '蓬安县', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2681', '仪陇县', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2682', '西充县', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2683', '阆中市', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2684', '其它区', '2674', '3', '2572,2674', '0', '1');
INSERT INTO `smi_region` VALUES ('2685', '眉山市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2686', '东坡区', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2687', '仁寿县', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2688', '彭山县', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2689', '洪雅县', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2690', '丹棱县', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2691', '青神县', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2692', '其它区', '2685', '3', '2572,2685', '0', '1');
INSERT INTO `smi_region` VALUES ('2693', '宜宾市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2694', '翠屏区', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2695', '宜宾县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2696', '南溪县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2697', '江安县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2698', '长宁县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2699', '高县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2700', '珙县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2701', '筠连县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2702', '兴文县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2703', '屏山县', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2704', '其它区', '2693', '3', '2572,2693', '0', '1');
INSERT INTO `smi_region` VALUES ('2705', '广安市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2706', '广安区', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2707', '岳池县', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2708', '武胜县', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2709', '邻水县', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2710', '华蓥市', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2711', '市辖区', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2712', '其它区', '2705', '3', '2572,2705', '0', '1');
INSERT INTO `smi_region` VALUES ('2713', '达州市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2714', '通川区', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2715', '达县', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2716', '宣汉县', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2717', '开江县', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2718', '大竹县', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2719', '渠县', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2720', '万源市', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2721', '其它区', '2713', '3', '2572,2713', '0', '1');
INSERT INTO `smi_region` VALUES ('2722', '雅安市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2723', '雨城区', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2724', '名山县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2725', '荥经县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2726', '汉源县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2727', '石棉县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2728', '天全县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2729', '芦山县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2730', '宝兴县', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2731', '其它区', '2722', '3', '2572,2722', '0', '1');
INSERT INTO `smi_region` VALUES ('2732', '巴中市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2733', '巴州区', '2732', '3', '2572,2732', '0', '1');
INSERT INTO `smi_region` VALUES ('2734', '通江县', '2732', '3', '2572,2732', '0', '1');
INSERT INTO `smi_region` VALUES ('2735', '南江县', '2732', '3', '2572,2732', '0', '1');
INSERT INTO `smi_region` VALUES ('2736', '平昌县', '2732', '3', '2572,2732', '0', '1');
INSERT INTO `smi_region` VALUES ('2737', '其它区', '2732', '3', '2572,2732', '0', '1');
INSERT INTO `smi_region` VALUES ('2738', '资阳市', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2739', '雁江区', '2738', '3', '2572,2738', '0', '1');
INSERT INTO `smi_region` VALUES ('2740', '安岳县', '2738', '3', '2572,2738', '0', '1');
INSERT INTO `smi_region` VALUES ('2741', '乐至县', '2738', '3', '2572,2738', '0', '1');
INSERT INTO `smi_region` VALUES ('2742', '简阳市', '2738', '3', '2572,2738', '0', '1');
INSERT INTO `smi_region` VALUES ('2743', '其它区', '2738', '3', '2572,2738', '0', '1');
INSERT INTO `smi_region` VALUES ('2744', '阿坝藏族羌族自治州', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2745', '汶川县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2746', '理县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2747', '茂县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2748', '松潘县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2749', '九寨沟县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2750', '金川县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2751', '小金县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2752', '黑水县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2753', '马尔康县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2754', '壤塘县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2755', '阿坝县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2756', '若尔盖县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2757', '红原县', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2758', '其它区', '2744', '3', '2572,2744', '0', '1');
INSERT INTO `smi_region` VALUES ('2759', '甘孜藏族自治州', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2760', '康定县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2761', '泸定县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2762', '丹巴县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2763', '九龙县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2764', '雅江县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2765', '道孚县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2766', '炉霍县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2767', '甘孜县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2768', '新龙县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2769', '德格县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2770', '白玉县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2771', '石渠县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2772', '色达县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2773', '理塘县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2774', '巴塘县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2775', '乡城县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2776', '稻城县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2777', '得荣县', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2778', '其它区', '2759', '3', '2572,2759', '0', '1');
INSERT INTO `smi_region` VALUES ('2779', '凉山彝族自治州', '2572', '2', '2572', '0', '1');
INSERT INTO `smi_region` VALUES ('2780', '西昌市', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2781', '木里藏族自治县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2782', '盐源县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2783', '德昌县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2784', '会理县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2785', '会东县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2786', '宁南县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2787', '普格县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2788', '布拖县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2789', '金阳县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2790', '昭觉县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2791', '喜德县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2792', '冕宁县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2793', '越西县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2794', '甘洛县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2795', '美姑县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2796', '雷波县', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2797', '其它区', '2779', '3', '2572,2779', '0', '1');
INSERT INTO `smi_region` VALUES ('2798', '贵州省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2799', '贵阳市', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2800', '南明区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2801', '云岩区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2802', '花溪区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2803', '乌当区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2804', '白云区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2805', '小河区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2806', '开阳县', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2807', '息烽县', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2808', '修文县', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2809', '金阳开发区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2810', '清镇市', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2811', '其它区', '2799', '3', '2798,2799', '0', '1');
INSERT INTO `smi_region` VALUES ('2812', '六盘水市', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2813', '钟山区', '2812', '3', '2798,2812', '0', '1');
INSERT INTO `smi_region` VALUES ('2814', '六枝特区', '2812', '3', '2798,2812', '0', '1');
INSERT INTO `smi_region` VALUES ('2815', '水城县', '2812', '3', '2798,2812', '0', '1');
INSERT INTO `smi_region` VALUES ('2816', '盘县', '2812', '3', '2798,2812', '0', '1');
INSERT INTO `smi_region` VALUES ('2817', '其它区', '2812', '3', '2798,2812', '0', '1');
INSERT INTO `smi_region` VALUES ('2818', '遵义市', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2819', '红花岗区', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2820', '汇川区', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2821', '遵义县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2822', '桐梓县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2823', '绥阳县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2824', '正安县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2825', '道真仡佬族苗族自治县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2826', '务川仡佬族苗族自治县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2827', '凤冈县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2828', '湄潭县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2829', '余庆县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2830', '习水县', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2831', '赤水市', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2832', '仁怀市', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2833', '其它区', '2818', '3', '2798,2818', '0', '1');
INSERT INTO `smi_region` VALUES ('2834', '安顺市', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2835', '西秀区', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2836', '平坝县', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2837', '普定县', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2838', '镇宁布依族苗族自治县', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2839', '关岭布依族苗族自治县', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2840', '紫云苗族布依族自治县', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2841', '其它区', '2834', '3', '2798,2834', '0', '1');
INSERT INTO `smi_region` VALUES ('2842', '铜仁地区', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2843', '铜仁市', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2844', '江口县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2845', '玉屏侗族自治县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2846', '石阡县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2847', '思南县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2848', '印江土家族苗族自治县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2849', '德江县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2850', '沿河土家族自治县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2851', '松桃苗族自治县', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2852', '万山特区', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2853', '其它区', '2842', '3', '2798,2842', '0', '1');
INSERT INTO `smi_region` VALUES ('2854', '黔西南布依族苗族自治州', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2855', '兴义市', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2856', '兴仁县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2857', '普安县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2858', '晴隆县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2859', '贞丰县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2860', '望谟县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2861', '册亨县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2862', '安龙县', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2863', '其它区', '2854', '3', '2798,2854', '0', '1');
INSERT INTO `smi_region` VALUES ('2864', '毕节地区', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2865', '毕节市', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2866', '大方县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2867', '黔西县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2868', '金沙县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2869', '织金县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2870', '纳雍县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2871', '威宁彝族回族苗族自治县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2872', '赫章县', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2873', '其它区', '2864', '3', '2798,2864', '0', '1');
INSERT INTO `smi_region` VALUES ('2874', '黔东南苗族侗族自治州', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2875', '凯里市', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2876', '黄平县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2877', '施秉县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2878', '三穗县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2879', '镇远县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2880', '岑巩县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2881', '天柱县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2882', '锦屏县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2883', '剑河县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2884', '台江县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2885', '黎平县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2886', '榕江县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2887', '从江县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2888', '雷山县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2889', '麻江县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2890', '丹寨县', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2891', '其它区', '2874', '3', '2798,2874', '0', '1');
INSERT INTO `smi_region` VALUES ('2892', '黔南布依族苗族自治州', '2798', '2', '2798', '0', '1');
INSERT INTO `smi_region` VALUES ('2893', '都匀市', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2894', '福泉市', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2895', '荔波县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2896', '贵定县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2897', '瓮安县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2898', '独山县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2899', '平塘县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2900', '罗甸县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2901', '长顺县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2902', '龙里县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2903', '惠水县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2904', '三都水族自治县', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2905', '其它区', '2892', '3', '2798,2892', '0', '1');
INSERT INTO `smi_region` VALUES ('2906', '云南省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('2907', '昆明市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2908', '五华区', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2909', '盘龙区', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2910', '官渡区', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2911', '西山区', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2912', '东川区', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2913', '呈贡县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2914', '晋宁县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2915', '富民县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2916', '宜良县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2917', '石林彝族自治县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2918', '嵩明县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2919', '禄劝彝族苗族自治县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2920', '寻甸回族彝族自治县', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2921', '安宁市', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2922', '其它区', '2907', '3', '2906,2907', '0', '1');
INSERT INTO `smi_region` VALUES ('2923', '曲靖市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2924', '麒麟区', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2925', '马龙县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2926', '陆良县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2927', '师宗县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2928', '罗平县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2929', '富源县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2930', '会泽县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2931', '沾益县', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2932', '宣威市', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2933', '其它区', '2923', '3', '2906,2923', '0', '1');
INSERT INTO `smi_region` VALUES ('2934', '玉溪市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2935', '红塔区', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2936', '江川县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2937', '澄江县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2938', '通海县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2939', '华宁县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2940', '易门县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2941', '峨山彝族自治县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2942', '新平彝族傣族自治县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2943', '元江哈尼族彝族傣族自治县', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2944', '其它区', '2934', '3', '2906,2934', '0', '1');
INSERT INTO `smi_region` VALUES ('2945', '保山市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2946', '隆阳区', '2945', '3', '2906,2945', '0', '1');
INSERT INTO `smi_region` VALUES ('2947', '施甸县', '2945', '3', '2906,2945', '0', '1');
INSERT INTO `smi_region` VALUES ('2948', '腾冲县', '2945', '3', '2906,2945', '0', '1');
INSERT INTO `smi_region` VALUES ('2949', '龙陵县', '2945', '3', '2906,2945', '0', '1');
INSERT INTO `smi_region` VALUES ('2950', '昌宁县', '2945', '3', '2906,2945', '0', '1');
INSERT INTO `smi_region` VALUES ('2951', '其它区', '2945', '3', '2906,2945', '0', '1');
INSERT INTO `smi_region` VALUES ('2952', '昭通市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2953', '昭阳区', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2954', '鲁甸县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2955', '巧家县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2956', '盐津县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2957', '大关县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2958', '永善县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2959', '绥江县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2960', '镇雄县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2961', '彝良县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2962', '威信县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2963', '水富县', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2964', '其它区', '2952', '3', '2906,2952', '0', '1');
INSERT INTO `smi_region` VALUES ('2965', '丽江市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2966', '古城区', '2965', '3', '2906,2965', '0', '1');
INSERT INTO `smi_region` VALUES ('2967', '玉龙纳西族自治县', '2965', '3', '2906,2965', '0', '1');
INSERT INTO `smi_region` VALUES ('2968', '永胜县', '2965', '3', '2906,2965', '0', '1');
INSERT INTO `smi_region` VALUES ('2969', '华坪县', '2965', '3', '2906,2965', '0', '1');
INSERT INTO `smi_region` VALUES ('2970', '宁蒗彝族自治县', '2965', '3', '2906,2965', '0', '1');
INSERT INTO `smi_region` VALUES ('2971', '其它区', '2965', '3', '2906,2965', '0', '1');
INSERT INTO `smi_region` VALUES ('2972', '普洱市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2973', '思茅区', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2974', '宁洱哈尼族彝族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2975', '墨江哈尼族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2976', '景东彝族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2977', '景谷傣族彝族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2978', '镇沅彝族哈尼族拉祜族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2979', '江城哈尼族彝族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2980', '孟连傣族拉祜族佤族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2981', '澜沧拉祜族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2982', '西盟佤族自治县', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2983', '其它区', '2972', '3', '2906,2972', '0', '1');
INSERT INTO `smi_region` VALUES ('2984', '临沧市', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2985', '临翔区', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2986', '凤庆县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2987', '云县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2988', '永德县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2989', '镇康县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2990', '双江拉祜族佤族布朗族傣族自治县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2991', '耿马傣族佤族自治县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2992', '沧源佤族自治县', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2993', '其它区', '2984', '3', '2906,2984', '0', '1');
INSERT INTO `smi_region` VALUES ('2994', '楚雄彝族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('2995', '楚雄市', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('2996', '双柏县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('2997', '牟定县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('2998', '南华县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('2999', '姚安县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3000', '大姚县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3001', '永仁县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3002', '元谋县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3003', '武定县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3004', '禄丰县', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3005', '其它区', '2994', '3', '2906,2994', '0', '1');
INSERT INTO `smi_region` VALUES ('3006', '红河哈尼族彝族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3007', '个旧市', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3008', '开远市', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3009', '蒙自县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3010', '屏边苗族自治县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3011', '建水县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3012', '石屏县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3013', '弥勒县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3014', '泸西县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3015', '元阳县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3016', '红河县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3017', '金平苗族瑶族傣族自治县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3018', '绿春县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3019', '河口瑶族自治县', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3020', '其它区', '3006', '3', '2906,3006', '0', '1');
INSERT INTO `smi_region` VALUES ('3021', '文山壮族苗族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3022', '文山县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3023', '砚山县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3024', '西畴县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3025', '麻栗坡县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3026', '马关县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3027', '丘北县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3028', '广南县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3029', '富宁县', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3030', '其它区', '3021', '3', '2906,3021', '0', '1');
INSERT INTO `smi_region` VALUES ('3031', '西双版纳傣族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3032', '景洪市', '3031', '3', '2906,3031', '0', '1');
INSERT INTO `smi_region` VALUES ('3033', '勐海县', '3031', '3', '2906,3031', '0', '1');
INSERT INTO `smi_region` VALUES ('3034', '勐腊县', '3031', '3', '2906,3031', '0', '1');
INSERT INTO `smi_region` VALUES ('3035', '其它区', '3031', '3', '2906,3031', '0', '1');
INSERT INTO `smi_region` VALUES ('3036', '大理白族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3037', '大理市', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3038', '漾濞彝族自治县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3039', '祥云县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3040', '宾川县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3041', '弥渡县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3042', '南涧彝族自治县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3043', '巍山彝族回族自治县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3044', '永平县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3045', '云龙县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3046', '洱源县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3047', '剑川县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3048', '鹤庆县', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3049', '其它区', '3036', '3', '2906,3036', '0', '1');
INSERT INTO `smi_region` VALUES ('3050', '德宏傣族景颇族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3051', '瑞丽市', '3050', '3', '2906,3050', '0', '1');
INSERT INTO `smi_region` VALUES ('3052', '潞西市', '3050', '3', '2906,3050', '0', '1');
INSERT INTO `smi_region` VALUES ('3053', '梁河县', '3050', '3', '2906,3050', '0', '1');
INSERT INTO `smi_region` VALUES ('3054', '盈江县', '3050', '3', '2906,3050', '0', '1');
INSERT INTO `smi_region` VALUES ('3055', '陇川县', '3050', '3', '2906,3050', '0', '1');
INSERT INTO `smi_region` VALUES ('3056', '其它区', '3050', '3', '2906,3050', '0', '1');
INSERT INTO `smi_region` VALUES ('3057', '怒江傈僳族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3058', '泸水县', '3057', '3', '2906,3057', '0', '1');
INSERT INTO `smi_region` VALUES ('3059', '福贡县', '3057', '3', '2906,3057', '0', '1');
INSERT INTO `smi_region` VALUES ('3060', '贡山独龙族怒族自治县', '3057', '3', '2906,3057', '0', '1');
INSERT INTO `smi_region` VALUES ('3061', '兰坪白族普米族自治县', '3057', '3', '2906,3057', '0', '1');
INSERT INTO `smi_region` VALUES ('3062', '其它区', '3057', '3', '2906,3057', '0', '1');
INSERT INTO `smi_region` VALUES ('3063', '迪庆藏族自治州', '2906', '2', '2906', '0', '1');
INSERT INTO `smi_region` VALUES ('3064', '香格里拉县', '3063', '3', '2906,3063', '0', '1');
INSERT INTO `smi_region` VALUES ('3065', '德钦县', '3063', '3', '2906,3063', '0', '1');
INSERT INTO `smi_region` VALUES ('3066', '维西傈僳族自治县', '3063', '3', '2906,3063', '0', '1');
INSERT INTO `smi_region` VALUES ('3067', '其它区', '3063', '3', '2906,3063', '0', '1');
INSERT INTO `smi_region` VALUES ('3068', '西藏自治区', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('3069', '拉萨市', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3070', '城关区', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3071', '林周县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3072', '当雄县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3073', '尼木县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3074', '曲水县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3075', '堆龙德庆县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3076', '达孜县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3077', '墨竹工卡县', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3078', '其它区', '3069', '3', '3068,3069', '0', '1');
INSERT INTO `smi_region` VALUES ('3079', '昌都地区', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3080', '昌都县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3081', '江达县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3082', '贡觉县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3083', '类乌齐县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3084', '丁青县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3085', '察雅县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3086', '八宿县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3087', '左贡县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3088', '芒康县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3089', '洛隆县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3090', '边坝县', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3091', '其它区', '3079', '3', '3068,3079', '0', '1');
INSERT INTO `smi_region` VALUES ('3092', '山南地区', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3093', '乃东县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3094', '扎囊县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3095', '贡嘎县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3096', '桑日县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3097', '琼结县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3098', '曲松县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3099', '措美县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3100', '洛扎县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3101', '加查县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3102', '隆子县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3103', '错那县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3104', '浪卡子县', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3105', '其它区', '3092', '3', '3068,3092', '0', '1');
INSERT INTO `smi_region` VALUES ('3106', '日喀则地区', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3107', '日喀则市', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3108', '南木林县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3109', '江孜县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3110', '定日县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3111', '萨迦县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3112', '拉孜县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3113', '昂仁县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3114', '谢通门县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3115', '白朗县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3116', '仁布县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3117', '康马县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3118', '定结县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3119', '仲巴县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3120', '亚东县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3121', '吉隆县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3122', '聂拉木县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3123', '萨嘎县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3124', '岗巴县', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3125', '其它区', '3106', '3', '3068,3106', '0', '1');
INSERT INTO `smi_region` VALUES ('3126', '那曲地区', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3127', '那曲县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3128', '嘉黎县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3129', '比如县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3130', '聂荣县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3131', '安多县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3132', '申扎县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3133', '索县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3134', '班戈县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3135', '巴青县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3136', '尼玛县', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3137', '其它区', '3126', '3', '3068,3126', '0', '1');
INSERT INTO `smi_region` VALUES ('3138', '阿里地区', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3139', '普兰县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3140', '札达县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3141', '噶尔县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3142', '日土县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3143', '革吉县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3144', '改则县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3145', '措勤县', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3146', '其它区', '3138', '3', '3068,3138', '0', '1');
INSERT INTO `smi_region` VALUES ('3147', '林芝地区', '3068', '2', '3068', '0', '1');
INSERT INTO `smi_region` VALUES ('3148', '林芝县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3149', '工布江达县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3150', '米林县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3151', '墨脱县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3152', '波密县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3153', '察隅县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3154', '朗县', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3155', '其它区', '3147', '3', '3068,3147', '0', '1');
INSERT INTO `smi_region` VALUES ('3156', '陕西省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('3157', '西安市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3158', '新城区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3159', '碑林区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3160', '莲湖区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3161', '灞桥区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3162', '未央区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3163', '雁塔区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3164', '阎良区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3165', '临潼区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3166', '长安区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3167', '蓝田县', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3168', '周至县', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3169', '户县', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3170', '高陵县', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3171', '其它区', '3157', '3', '3156,3157', '0', '1');
INSERT INTO `smi_region` VALUES ('3172', '铜川市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3173', '王益区', '3172', '3', '3156,3172', '0', '1');
INSERT INTO `smi_region` VALUES ('3174', '印台区', '3172', '3', '3156,3172', '0', '1');
INSERT INTO `smi_region` VALUES ('3175', '耀州区', '3172', '3', '3156,3172', '0', '1');
INSERT INTO `smi_region` VALUES ('3176', '宜君县', '3172', '3', '3156,3172', '0', '1');
INSERT INTO `smi_region` VALUES ('3177', '其它区', '3172', '3', '3156,3172', '0', '1');
INSERT INTO `smi_region` VALUES ('3178', '宝鸡市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3179', '渭滨区', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3180', '金台区', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3181', '陈仓区', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3182', '凤翔县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3183', '岐山县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3184', '扶风县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3185', '眉县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3186', '陇县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3187', '千阳县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3188', '麟游县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3189', '凤县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3190', '太白县', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3191', '其它区', '3178', '3', '3156,3178', '0', '1');
INSERT INTO `smi_region` VALUES ('3192', '咸阳市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3193', '秦都区', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3194', '杨凌区', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3195', '渭城区', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3196', '三原县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3197', '泾阳县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3198', '乾县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3199', '礼泉县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3200', '永寿县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3201', '彬县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3202', '长武县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3203', '旬邑县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3204', '淳化县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3205', '武功县', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3206', '兴平市', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3207', '其它区', '3192', '3', '3156,3192', '0', '1');
INSERT INTO `smi_region` VALUES ('3208', '渭南市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3209', '临渭区', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3210', '华县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3211', '潼关县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3212', '大荔县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3213', '合阳县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3214', '澄城县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3215', '蒲城县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3216', '白水县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3217', '富平县', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3218', '韩城市', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3219', '华阴市', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3220', '其它区', '3208', '3', '3156,3208', '0', '1');
INSERT INTO `smi_region` VALUES ('3221', '延安市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3222', '宝塔区', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3223', '延长县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3224', '延川县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3225', '子长县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3226', '安塞县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3227', '志丹县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3228', '吴起县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3229', '甘泉县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3230', '富县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3231', '洛川县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3232', '宜川县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3233', '黄龙县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3234', '黄陵县', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3235', '其它区', '3221', '3', '3156,3221', '0', '1');
INSERT INTO `smi_region` VALUES ('3236', '汉中市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3237', '汉台区', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3238', '南郑县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3239', '城固县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3240', '洋县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3241', '西乡县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3242', '勉县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3243', '宁强县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3244', '略阳县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3245', '镇巴县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3246', '留坝县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3247', '佛坪县', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3248', '其它区', '3236', '3', '3156,3236', '0', '1');
INSERT INTO `smi_region` VALUES ('3249', '榆林市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3250', '榆阳区', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3251', '神木县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3252', '府谷县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3253', '横山县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3254', '靖边县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3255', '定边县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3256', '绥德县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3257', '米脂县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3258', '佳县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3259', '吴堡县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3260', '清涧县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3261', '子洲县', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3262', '其它区', '3249', '3', '3156,3249', '0', '1');
INSERT INTO `smi_region` VALUES ('3263', '安康市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3264', '汉滨区', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3265', '汉阴县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3266', '石泉县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3267', '宁陕县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3268', '紫阳县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3269', '岚皋县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3270', '平利县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3271', '镇坪县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3272', '旬阳县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3273', '白河县', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3274', '其它区', '3263', '3', '3156,3263', '0', '1');
INSERT INTO `smi_region` VALUES ('3275', '商洛市', '3156', '2', '3156', '0', '1');
INSERT INTO `smi_region` VALUES ('3276', '商州区', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3277', '洛南县', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3278', '丹凤县', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3279', '商南县', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3280', '山阳县', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3281', '镇安县', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3282', '柞水县', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3283', '其它区', '3275', '3', '3156,3275', '0', '1');
INSERT INTO `smi_region` VALUES ('3284', '甘肃省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('3285', '兰州市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3286', '城关区', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3287', '七里河区', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3288', '西固区', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3289', '安宁区', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3290', '红古区', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3291', '永登县', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3292', '皋兰县', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3293', '榆中县', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3294', '其它区', '3285', '3', '3284,3285', '0', '1');
INSERT INTO `smi_region` VALUES ('3295', '嘉峪关市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3296', '金昌市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3297', '金川区', '3296', '3', '3284,3296', '0', '1');
INSERT INTO `smi_region` VALUES ('3298', '永昌县', '3296', '3', '3284,3296', '0', '1');
INSERT INTO `smi_region` VALUES ('3299', '其它区', '3296', '3', '3284,3296', '0', '1');
INSERT INTO `smi_region` VALUES ('3300', '白银市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3301', '白银区', '3300', '3', '3284,3300', '0', '1');
INSERT INTO `smi_region` VALUES ('3302', '平川区', '3300', '3', '3284,3300', '0', '1');
INSERT INTO `smi_region` VALUES ('3303', '靖远县', '3300', '3', '3284,3300', '0', '1');
INSERT INTO `smi_region` VALUES ('3304', '会宁县', '3300', '3', '3284,3300', '0', '1');
INSERT INTO `smi_region` VALUES ('3305', '景泰县', '3300', '3', '3284,3300', '0', '1');
INSERT INTO `smi_region` VALUES ('3306', '其它区', '3300', '3', '3284,3300', '0', '1');
INSERT INTO `smi_region` VALUES ('3307', '天水市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3308', '秦州区', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3309', '麦积区', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3310', '清水县', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3311', '秦安县', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3312', '甘谷县', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3313', '武山县', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3314', '张家川回族自治县', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3315', '其它区', '3307', '3', '3284,3307', '0', '1');
INSERT INTO `smi_region` VALUES ('3316', '武威市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3317', '凉州区', '3316', '3', '3284,3316', '0', '1');
INSERT INTO `smi_region` VALUES ('3318', '民勤县', '3316', '3', '3284,3316', '0', '1');
INSERT INTO `smi_region` VALUES ('3319', '古浪县', '3316', '3', '3284,3316', '0', '1');
INSERT INTO `smi_region` VALUES ('3320', '天祝藏族自治县', '3316', '3', '3284,3316', '0', '1');
INSERT INTO `smi_region` VALUES ('3321', '其它区', '3316', '3', '3284,3316', '0', '1');
INSERT INTO `smi_region` VALUES ('3322', '张掖市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3323', '甘州区', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3324', '肃南裕固族自治县', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3325', '民乐县', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3326', '临泽县', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3327', '高台县', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3328', '山丹县', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3329', '其它区', '3322', '3', '3284,3322', '0', '1');
INSERT INTO `smi_region` VALUES ('3330', '平凉市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3331', '崆峒区', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3332', '泾川县', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3333', '灵台县', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3334', '崇信县', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3335', '华亭县', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3336', '庄浪县', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3337', '静宁县', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3338', '其它区', '3330', '3', '3284,3330', '0', '1');
INSERT INTO `smi_region` VALUES ('3339', '酒泉市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3340', '肃州区', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3341', '金塔县', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3342', '安西县', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3343', '肃北蒙古族自治县', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3344', '阿克塞哈萨克族自治县', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3345', '玉门市', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3346', '敦煌市', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3347', '其它区', '3339', '3', '3284,3339', '0', '1');
INSERT INTO `smi_region` VALUES ('3348', '庆阳市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3349', '西峰区', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3350', '庆城县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3351', '环县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3352', '华池县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3353', '合水县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3354', '正宁县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3355', '宁县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3356', '镇原县', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3357', '其它区', '3348', '3', '3284,3348', '0', '1');
INSERT INTO `smi_region` VALUES ('3358', '定西市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3359', '安定区', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3360', '通渭县', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3361', '陇西县', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3362', '渭源县', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3363', '临洮县', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3364', '漳县', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3365', '岷县', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3366', '其它区', '3358', '3', '3284,3358', '0', '1');
INSERT INTO `smi_region` VALUES ('3367', '陇南市', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3368', '武都区', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3369', '成县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3370', '文县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3371', '宕昌县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3372', '康县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3373', '西和县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3374', '礼县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3375', '徽县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3376', '两当县', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3377', '其它区', '3367', '3', '3284,3367', '0', '1');
INSERT INTO `smi_region` VALUES ('3378', '临夏回族自治州', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3379', '临夏市', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3380', '临夏县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3381', '康乐县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3382', '永靖县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3383', '广河县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3384', '和政县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3385', '东乡族自治县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3386', '积石山保安族东乡族撒拉族自治县', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3387', '其它区', '3378', '3', '3284,3378', '0', '1');
INSERT INTO `smi_region` VALUES ('3388', '甘南藏族自治州', '3284', '2', '3284', '0', '1');
INSERT INTO `smi_region` VALUES ('3389', '合作市', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3390', '临潭县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3391', '卓尼县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3392', '舟曲县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3393', '迭部县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3394', '玛曲县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3395', '碌曲县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3396', '夏河县', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3397', '其它区', '3388', '3', '3284,3388', '0', '1');
INSERT INTO `smi_region` VALUES ('3398', '青海省', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('3399', '西宁市', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3400', '城东区', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3401', '城中区', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3402', '城西区', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3403', '城北区', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3404', '大通回族土族自治县', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3405', '湟中县', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3406', '湟源县', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3407', '其它区', '3399', '3', '3398,3399', '0', '1');
INSERT INTO `smi_region` VALUES ('3408', '海东地区', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3409', '平安县', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3410', '民和回族土族自治县', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3411', '乐都县', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3412', '互助土族自治县', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3413', '化隆回族自治县', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3414', '循化撒拉族自治县', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3415', '其它区', '3408', '3', '3398,3408', '0', '1');
INSERT INTO `smi_region` VALUES ('3416', '海北藏族自治州', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3417', '门源回族自治县', '3416', '3', '3398,3416', '0', '1');
INSERT INTO `smi_region` VALUES ('3418', '祁连县', '3416', '3', '3398,3416', '0', '1');
INSERT INTO `smi_region` VALUES ('3419', '海晏县', '3416', '3', '3398,3416', '0', '1');
INSERT INTO `smi_region` VALUES ('3420', '刚察县', '3416', '3', '3398,3416', '0', '1');
INSERT INTO `smi_region` VALUES ('3421', '其它区', '3416', '3', '3398,3416', '0', '1');
INSERT INTO `smi_region` VALUES ('3422', '黄南藏族自治州', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3423', '同仁县', '3422', '3', '3398,3422', '0', '1');
INSERT INTO `smi_region` VALUES ('3424', '尖扎县', '3422', '3', '3398,3422', '0', '1');
INSERT INTO `smi_region` VALUES ('3425', '泽库县', '3422', '3', '3398,3422', '0', '1');
INSERT INTO `smi_region` VALUES ('3426', '河南蒙古族自治县', '3422', '3', '3398,3422', '0', '1');
INSERT INTO `smi_region` VALUES ('3427', '其它区', '3422', '3', '3398,3422', '0', '1');
INSERT INTO `smi_region` VALUES ('3428', '海南藏族自治州', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3429', '共和县', '3428', '3', '3398,3428', '0', '1');
INSERT INTO `smi_region` VALUES ('3430', '同德县', '3428', '3', '3398,3428', '0', '1');
INSERT INTO `smi_region` VALUES ('3431', '贵德县', '3428', '3', '3398,3428', '0', '1');
INSERT INTO `smi_region` VALUES ('3432', '兴海县', '3428', '3', '3398,3428', '0', '1');
INSERT INTO `smi_region` VALUES ('3433', '贵南县', '3428', '3', '3398,3428', '0', '1');
INSERT INTO `smi_region` VALUES ('3434', '其它区', '3428', '3', '3398,3428', '0', '1');
INSERT INTO `smi_region` VALUES ('3435', '果洛藏族自治州', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3436', '玛沁县', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3437', '班玛县', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3438', '甘德县', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3439', '达日县', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3440', '久治县', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3441', '玛多县', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3442', '其它区', '3435', '3', '3398,3435', '0', '1');
INSERT INTO `smi_region` VALUES ('3443', '玉树藏族自治州', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3444', '玉树县', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3445', '杂多县', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3446', '称多县', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3447', '治多县', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3448', '囊谦县', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3449', '曲麻莱县', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3450', '其它区', '3443', '3', '3398,3443', '0', '1');
INSERT INTO `smi_region` VALUES ('3451', '海西蒙古族藏族自治州', '3398', '2', '3398', '0', '1');
INSERT INTO `smi_region` VALUES ('3452', '格尔木市', '3451', '3', '3398,3451', '0', '1');
INSERT INTO `smi_region` VALUES ('3453', '德令哈市', '3451', '3', '3398,3451', '0', '1');
INSERT INTO `smi_region` VALUES ('3454', '乌兰县', '3451', '3', '3398,3451', '0', '1');
INSERT INTO `smi_region` VALUES ('3455', '都兰县', '3451', '3', '3398,3451', '0', '1');
INSERT INTO `smi_region` VALUES ('3456', '天峻县', '3451', '3', '3398,3451', '0', '1');
INSERT INTO `smi_region` VALUES ('3457', '其它区', '3451', '3', '3398,3451', '0', '1');
INSERT INTO `smi_region` VALUES ('3458', '宁夏回族自治区', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('3459', '银川市', '3458', '2', '3458', '0', '1');
INSERT INTO `smi_region` VALUES ('3460', '兴庆区', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3461', '西夏区', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3462', '金凤区', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3463', '永宁县', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3464', '贺兰县', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3465', '灵武市', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3466', '其它区', '3459', '3', '3458,3459', '0', '1');
INSERT INTO `smi_region` VALUES ('3467', '石嘴山市', '3458', '2', '3458', '0', '1');
INSERT INTO `smi_region` VALUES ('3468', '大武口区', '3467', '3', '3458,3467', '0', '1');
INSERT INTO `smi_region` VALUES ('3469', '惠农区', '3467', '3', '3458,3467', '0', '1');
INSERT INTO `smi_region` VALUES ('3470', '平罗县', '3467', '3', '3458,3467', '0', '1');
INSERT INTO `smi_region` VALUES ('3471', '其它区', '3467', '3', '3458,3467', '0', '1');
INSERT INTO `smi_region` VALUES ('3472', '吴忠市', '3458', '2', '3458', '0', '1');
INSERT INTO `smi_region` VALUES ('3473', '利通区', '3472', '3', '3458,3472', '0', '1');
INSERT INTO `smi_region` VALUES ('3474', '红寺堡区', '3472', '3', '3458,3472', '0', '1');
INSERT INTO `smi_region` VALUES ('3475', '盐池县', '3472', '3', '3458,3472', '0', '1');
INSERT INTO `smi_region` VALUES ('3476', '同心县', '3472', '3', '3458,3472', '0', '1');
INSERT INTO `smi_region` VALUES ('3477', '青铜峡市', '3472', '3', '3458,3472', '0', '1');
INSERT INTO `smi_region` VALUES ('3478', '其它区', '3472', '3', '3458,3472', '0', '1');
INSERT INTO `smi_region` VALUES ('3479', '固原市', '3458', '2', '3458', '0', '1');
INSERT INTO `smi_region` VALUES ('3480', '原州区', '3479', '3', '3458,3479', '0', '1');
INSERT INTO `smi_region` VALUES ('3481', '西吉县', '3479', '3', '3458,3479', '0', '1');
INSERT INTO `smi_region` VALUES ('3482', '隆德县', '3479', '3', '3458,3479', '0', '1');
INSERT INTO `smi_region` VALUES ('3483', '泾源县', '3479', '3', '3458,3479', '0', '1');
INSERT INTO `smi_region` VALUES ('3484', '彭阳县', '3479', '3', '3458,3479', '0', '1');
INSERT INTO `smi_region` VALUES ('3485', '其它区', '3479', '3', '3458,3479', '0', '1');
INSERT INTO `smi_region` VALUES ('3486', '中卫市', '3458', '2', '3458', '0', '1');
INSERT INTO `smi_region` VALUES ('3487', '沙坡头区', '3486', '3', '3458,3486', '0', '1');
INSERT INTO `smi_region` VALUES ('3488', '中宁县', '3486', '3', '3458,3486', '0', '1');
INSERT INTO `smi_region` VALUES ('3489', '海原县', '3486', '3', '3458,3486', '0', '1');
INSERT INTO `smi_region` VALUES ('3490', '其它区', '3486', '3', '3458,3486', '0', '1');
INSERT INTO `smi_region` VALUES ('3491', '新疆维吾尔自治区', '0', '1', '', '0', '1');
INSERT INTO `smi_region` VALUES ('3492', '乌鲁木齐市', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3493', '天山区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3494', '沙依巴克区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3495', '新市区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3496', '水磨沟区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3497', '头屯河区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3498', '达坂城区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3499', '东山区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3500', '米东区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3501', '乌鲁木齐县', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3502', '其它区', '3492', '3', '3491,3492', '0', '1');
INSERT INTO `smi_region` VALUES ('3503', '克拉玛依市', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3504', '独山子区', '3503', '3', '3491,3503', '0', '1');
INSERT INTO `smi_region` VALUES ('3505', '克拉玛依区', '3503', '3', '3491,3503', '0', '1');
INSERT INTO `smi_region` VALUES ('3506', '白碱滩区', '3503', '3', '3491,3503', '0', '1');
INSERT INTO `smi_region` VALUES ('3507', '乌尔禾区', '3503', '3', '3491,3503', '0', '1');
INSERT INTO `smi_region` VALUES ('3508', '其它区', '3503', '3', '3491,3503', '0', '1');
INSERT INTO `smi_region` VALUES ('3509', '吐鲁番地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3510', '吐鲁番市', '3509', '3', '3491,3509', '0', '1');
INSERT INTO `smi_region` VALUES ('3511', '鄯善县', '3509', '3', '3491,3509', '0', '1');
INSERT INTO `smi_region` VALUES ('3512', '托克逊县', '3509', '3', '3491,3509', '0', '1');
INSERT INTO `smi_region` VALUES ('3513', '其它区', '3509', '3', '3491,3509', '0', '1');
INSERT INTO `smi_region` VALUES ('3514', '哈密地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3515', '哈密市', '3514', '3', '3491,3514', '0', '1');
INSERT INTO `smi_region` VALUES ('3516', '巴里坤哈萨克自治县', '3514', '3', '3491,3514', '0', '1');
INSERT INTO `smi_region` VALUES ('3517', '伊吾县', '3514', '3', '3491,3514', '0', '1');
INSERT INTO `smi_region` VALUES ('3518', '其它区', '3514', '3', '3491,3514', '0', '1');
INSERT INTO `smi_region` VALUES ('3519', '昌吉回族自治州', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3520', '昌吉市', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3521', '阜康市', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3522', '米泉市', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3523', '呼图壁县', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3524', '玛纳斯县', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3525', '奇台县', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3526', '吉木萨尔县', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3527', '木垒哈萨克自治县', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3528', '其它区', '3519', '3', '3491,3519', '0', '1');
INSERT INTO `smi_region` VALUES ('3529', '博尔塔拉蒙古自治州', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3530', '博乐市', '3529', '3', '3491,3529', '0', '1');
INSERT INTO `smi_region` VALUES ('3531', '精河县', '3529', '3', '3491,3529', '0', '1');
INSERT INTO `smi_region` VALUES ('3532', '温泉县', '3529', '3', '3491,3529', '0', '1');
INSERT INTO `smi_region` VALUES ('3533', '其它区', '3529', '3', '3491,3529', '0', '1');
INSERT INTO `smi_region` VALUES ('3534', '巴音郭楞蒙古自治州', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3535', '库尔勒市', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3536', '轮台县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3537', '尉犁县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3538', '若羌县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3539', '且末县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3540', '焉耆回族自治县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3541', '和静县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3542', '和硕县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3543', '博湖县', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3544', '其它区', '3534', '3', '3491,3534', '0', '1');
INSERT INTO `smi_region` VALUES ('3545', '阿克苏地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3546', '阿克苏市', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3547', '温宿县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3548', '库车县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3549', '沙雅县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3550', '新和县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3551', '拜城县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3552', '乌什县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3553', '阿瓦提县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3554', '柯坪县', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3555', '其它区', '3545', '3', '3491,3545', '0', '1');
INSERT INTO `smi_region` VALUES ('3556', '克孜勒苏柯尔克孜自治州', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3557', '阿图什市', '3556', '3', '3491,3556', '0', '1');
INSERT INTO `smi_region` VALUES ('3558', '阿克陶县', '3556', '3', '3491,3556', '0', '1');
INSERT INTO `smi_region` VALUES ('3559', '阿合奇县', '3556', '3', '3491,3556', '0', '1');
INSERT INTO `smi_region` VALUES ('3560', '乌恰县', '3556', '3', '3491,3556', '0', '1');
INSERT INTO `smi_region` VALUES ('3561', '其它区', '3556', '3', '3491,3556', '0', '1');
INSERT INTO `smi_region` VALUES ('3562', '喀什地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3563', '喀什市', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3564', '疏附县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3565', '疏勒县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3566', '英吉沙县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3567', '泽普县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3568', '莎车县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3569', '叶城县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3570', '麦盖提县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3571', '岳普湖县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3572', '伽师县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3573', '巴楚县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3574', '塔什库尔干塔吉克自治县', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3575', '其它区', '3562', '3', '3491,3562', '0', '1');
INSERT INTO `smi_region` VALUES ('3576', '和田地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3577', '和田市', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3578', '和田县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3579', '墨玉县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3580', '皮山县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3581', '洛浦县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3582', '策勒县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3583', '于田县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3584', '民丰县', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3585', '其它区', '3576', '3', '3491,3576', '0', '1');
INSERT INTO `smi_region` VALUES ('3586', '伊犁哈萨克自治州', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3587', '伊宁市', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3588', '奎屯市', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3589', '伊宁县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3590', '察布查尔锡伯自治县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3591', '霍城县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3592', '巩留县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3593', '新源县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3594', '昭苏县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3595', '特克斯县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3596', '尼勒克县', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3597', '其它区', '3586', '3', '3491,3586', '0', '1');
INSERT INTO `smi_region` VALUES ('3598', '塔城地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3599', '塔城市', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3600', '乌苏市', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3601', '额敏县', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3602', '沙湾县', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3603', '托里县', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3604', '裕民县', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3605', '和布克赛尔蒙古自治县', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3606', '其它区', '3598', '3', '3491,3598', '0', '1');
INSERT INTO `smi_region` VALUES ('3607', '阿勒泰地区', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3608', '阿勒泰市', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3609', '布尔津县', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3610', '富蕴县', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3611', '福海县', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3612', '哈巴河县', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3613', '青河县', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3614', '吉木乃县', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3615', '其它区', '3607', '3', '3491,3607', '0', '1');
INSERT INTO `smi_region` VALUES ('3616', '石河子市', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3617', '阿拉尔市', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3618', '图木舒克市', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3619', '五家渠市', '3491', '2', '3491', '0', '1');
INSERT INTO `smi_region` VALUES ('3620', '台湾省', '0', '1', '', '0', '0');
INSERT INTO `smi_region` VALUES ('3621', '台北市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3622', '中正区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3623', '大同区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3624', '中山区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3625', '松山区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3626', '大安区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3627', '万华区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3628', '信义区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3629', '士林区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3630', '北投区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3631', '内湖区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3632', '南港区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3633', '文山区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3634', '其它区', '3621', '3', '3620,3621', '0', '1');
INSERT INTO `smi_region` VALUES ('3635', '高雄市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3636', '新兴区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3637', '前金区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3638', '芩雅区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3639', '盐埕区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3640', '鼓山区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3641', '旗津区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3642', '前镇区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3643', '三民区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3644', '左营区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3645', '楠梓区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3646', '小港区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3647', '其它区', '3635', '3', '3620,3635', '0', '1');
INSERT INTO `smi_region` VALUES ('3648', '台南市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3649', '中西区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3650', '东区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3651', '南区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3652', '北区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3653', '安平区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3654', '安南区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3655', '其它区', '3648', '3', '3620,3648', '0', '1');
INSERT INTO `smi_region` VALUES ('3656', '台中市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3657', '中区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3658', '东区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3659', '南区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3660', '西区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3661', '北区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3662', '北屯区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3663', '西屯区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3664', '南屯区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3665', '其它区', '3656', '3', '3620,3656', '0', '1');
INSERT INTO `smi_region` VALUES ('3666', '金门县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3667', '南投县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3668', '基隆市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3669', '仁爱区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3670', '信义区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3671', '中正区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3672', '中山区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3673', '安乐区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3674', '暖暖区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3675', '七堵区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3676', '其它区', '3668', '3', '3620,3668', '0', '1');
INSERT INTO `smi_region` VALUES ('3677', '新竹市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3678', '东区', '3677', '3', '3620,3677', '0', '1');
INSERT INTO `smi_region` VALUES ('3679', '北区', '3677', '3', '3620,3677', '0', '1');
INSERT INTO `smi_region` VALUES ('3680', '香山区', '3677', '3', '3620,3677', '0', '1');
INSERT INTO `smi_region` VALUES ('3681', '其它区', '3677', '3', '3620,3677', '0', '1');
INSERT INTO `smi_region` VALUES ('3682', '嘉义市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3683', '东区', '3682', '3', '3620,3682', '0', '1');
INSERT INTO `smi_region` VALUES ('3684', '西区', '3682', '3', '3620,3682', '0', '1');
INSERT INTO `smi_region` VALUES ('3685', '其它区', '3682', '3', '3620,3682', '0', '1');
INSERT INTO `smi_region` VALUES ('3686', '新北市', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3687', '宜兰县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3688', '新竹县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3689', '桃园县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3690', '苗栗县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3691', '彰化县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3692', '嘉义县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3693', '云林县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3694', '屏东县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3695', '台东县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3696', '花莲县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3697', '澎湖县', '3620', '2', '3620', '0', '1');
INSERT INTO `smi_region` VALUES ('3698', '香港特别行政区', '0', '1', '', '0', '0');
INSERT INTO `smi_region` VALUES ('3699', '香港岛', '3698', '2', '3698', '0', '1');
INSERT INTO `smi_region` VALUES ('3700', '中西区', '3699', '3', '3698,3699', '0', '1');
INSERT INTO `smi_region` VALUES ('3701', '湾仔', '3699', '3', '3698,3699', '0', '1');
INSERT INTO `smi_region` VALUES ('3702', '东区', '3699', '3', '3698,3699', '0', '1');
INSERT INTO `smi_region` VALUES ('3703', '南区', '3699', '3', '3698,3699', '0', '1');
INSERT INTO `smi_region` VALUES ('3704', '九龙', '3698', '2', '3698', '0', '1');
INSERT INTO `smi_region` VALUES ('3705', '九龙城区', '3704', '3', '3698,3704', '0', '1');
INSERT INTO `smi_region` VALUES ('3706', '油尖旺区', '3704', '3', '3698,3704', '0', '1');
INSERT INTO `smi_region` VALUES ('3707', '深水埗区', '3704', '3', '3698,3704', '0', '1');
INSERT INTO `smi_region` VALUES ('3708', '黄大仙区', '3704', '3', '3698,3704', '0', '1');
INSERT INTO `smi_region` VALUES ('3709', '观塘区', '3704', '3', '3698,3704', '0', '1');
INSERT INTO `smi_region` VALUES ('3710', '新界', '3698', '2', '3698', '0', '1');
INSERT INTO `smi_region` VALUES ('3711', '北区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3712', '大埔区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3713', '沙田区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3714', '西贡区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3715', '元朗区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3716', '屯门区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3717', '荃湾区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3718', '葵青区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3719', '离岛区', '3710', '3', '3698,3710', '0', '1');
INSERT INTO `smi_region` VALUES ('3720', '澳门特别行政区', '0', '1', '', '0', '0');
INSERT INTO `smi_region` VALUES ('3721', '澳门半岛', '3720', '2', '3720', '0', '1');
INSERT INTO `smi_region` VALUES ('3722', '离岛', '3720', '2', '3720', '0', '1');

-- -----------------------------
-- Table structure for `smi_role`
-- -----------------------------
DROP TABLE IF EXISTS `smi_role`;
CREATE TABLE `smi_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `pid` int(11) NOT NULL,
  `route` varchar(255) NOT NULL,
  `grade` tinyint(4) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_role`
-- -----------------------------
INSERT INTO `smi_role` VALUES ('1', '高级管理员', '0', '0', '1', '0', '1', '');
INSERT INTO `smi_role` VALUES ('2', '二级管理员', '1', '0,1', '2', '3', '1', '');
INSERT INTO `smi_role` VALUES ('3', '三级管理员', '2', '0,1,2', '3', '0', '1', '');
INSERT INTO `smi_role` VALUES ('4', '新的二级管理员', '1', '0,1', '2', '2', '1', '');

-- -----------------------------
-- Table structure for `smi_seo_names`
-- -----------------------------
DROP TABLE IF EXISTS `smi_seo_names`;
CREATE TABLE `smi_seo_names` (
  `seo_name` varchar(128) NOT NULL,
  `object_id` int(11) NOT NULL,
  `type` char(1) NOT NULL,
  UNIQUE KEY `name` (`seo_name`,`type`),
  KEY `name_2` (`seo_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_seo_names`
-- -----------------------------
INSERT INTO `smi_seo_names` VALUES ('tset', '1', 'a');

-- -----------------------------
-- Table structure for `smi_spec`
-- -----------------------------
DROP TABLE IF EXISTS `smi_spec`;
CREATE TABLE `smi_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec` varchar(128) NOT NULL,
  `spec_alias` varchar(128) NOT NULL,
  `display` tinyint(1) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='规格表';

-- -----------------------------
-- Records of `smi_spec`
-- -----------------------------
INSERT INTO `smi_spec` VALUES ('1', '颜色1', '颜色1', '0', '一般性颜色1');
INSERT INTO `smi_spec` VALUES ('2', '尺寸（大中小）', '尺寸', '1', '');

-- -----------------------------
-- Table structure for `smi_spec_value`
-- -----------------------------
DROP TABLE IF EXISTS `smi_spec_value`;
CREATE TABLE `smi_spec_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) NOT NULL,
  `spec_value` varchar(128) NOT NULL,
  `spec_image` varchar(128) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `spec_id` (`spec_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_spec_value`
-- -----------------------------
INSERT INTO `smi_spec_value` VALUES ('1', '1', 'asdfasdf00', 'Spec/2014-10-24/544a19c50ab7b.jpg', '2');
INSERT INTO `smi_spec_value` VALUES ('2', '1', 'yuhjh0', '/Uploads/SpecValue/546af67f3fe19.gif', '0');
INSERT INTO `smi_spec_value` VALUES ('5', '1', 'gdfhshbgfh11', 'Spec/2014-10-23/5448c4d90c596.jpg', '1');
INSERT INTO `smi_spec_value` VALUES ('6', '2', 'XXS', '', '0');
INSERT INTO `smi_spec_value` VALUES ('7', '2', 'XS', '', '1');

-- -----------------------------
-- Table structure for `smi_type`
-- -----------------------------
DROP TABLE IF EXISTS `smi_type`;
CREATE TABLE `smi_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(128) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='产品类型表';

-- -----------------------------
-- Records of `smi_type`
-- -----------------------------
INSERT INTO `smi_type` VALUES ('1', '手机', '');
INSERT INTO `smi_type` VALUES ('2', '电脑', '');

-- -----------------------------
-- Table structure for `smi_type_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `smi_type_attribute`;
CREATE TABLE `smi_type_attribute` (
  `type_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `sort` smallint(6) NOT NULL,
  UNIQUE KEY `type_id` (`type_id`,`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品类型-属性关联表';

-- -----------------------------
-- Records of `smi_type_attribute`
-- -----------------------------
INSERT INTO `smi_type_attribute` VALUES ('1', '1', '1');
INSERT INTO `smi_type_attribute` VALUES ('1', '2', '0');
INSERT INTO `smi_type_attribute` VALUES ('2', '1', '0');

-- -----------------------------
-- Table structure for `smi_user`
-- -----------------------------
DROP TABLE IF EXISTS `smi_user`;
CREATE TABLE `smi_user` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `account` varchar(64) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `is_super` tinyint(1) NOT NULL COMMENT '超级管理员',
  `last_login_time` int(11) NOT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(15) NOT NULL COMMENT '最后登录IP',
  `login_count` smallint(6) NOT NULL COMMENT '登录次数',
  `status` tinyint(1) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_user`
-- -----------------------------
INSERT INTO `smi_user` VALUES ('2', 'administrator', '$1$dF3.iv/.$C6F38LMCo5t.f3kKCyOrl0', '', '', '0', '1', '1416534567', '127.0.0.1', '82', '1', '1401359163');
INSERT INTO `smi_user` VALUES ('3', 'jacob', '$1$O32.9y4.$0TEwBLEU0K10aKsOAlyEU/', '', '', '1', '0', '1401784869', '127.0.0.1', '5', '1', '1401530055');
INSERT INTO `smi_user` VALUES ('4', 'echo', '$1$Lm/.2u3.$VJDP/OgRNNBjHvOOg7hfI.', '', '', '2', '0', '0', '', '0', '1', '1401786246');
