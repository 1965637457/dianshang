-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : localhost
-- Port     : 
-- Database : hamanaka3
-- 
-- Part : #1
-- Date : 2014-11-09 22:16:27
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `smi_access`
-- -----------------------------
DROP TABLE IF EXISTS `smi_access`;
CREATE TABLE `smi_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_access`
-- -----------------------------
INSERT INTO `smi_access` VALUES ('1', '54', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '53', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '52', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '51', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '50', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '49', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '48', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '47', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '46', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '45', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '44', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '43', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '42', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '41', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '40', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '39', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '38', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '37', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '36', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '35', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '34', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '33', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '32', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '31', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '30', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '29', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '28', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '27', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '26', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '25', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '24', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '12', '1', '1');
INSERT INTO `smi_access` VALUES ('1', '62', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '61', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '60', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '59', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '11', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '10', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '9', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '8', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '7', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '6', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '5', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '4', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '3', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '2', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '1', '1', '1');
INSERT INTO `smi_access` VALUES ('2', '1', '1', '1');
INSERT INTO `smi_access` VALUES ('2', '2', '2', '1');
INSERT INTO `smi_access` VALUES ('2', '3', '3', '1');
INSERT INTO `smi_access` VALUES ('2', '4', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '5', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '6', '2', '1');
INSERT INTO `smi_access` VALUES ('2', '7', '3', '1');
INSERT INTO `smi_access` VALUES ('2', '8', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '9', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '10', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '11', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '12', '1', '1');
INSERT INTO `smi_access` VALUES ('2', '48', '2', '1');
INSERT INTO `smi_access` VALUES ('2', '49', '3', '1');
INSERT INTO `smi_access` VALUES ('2', '50', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '51', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '52', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '53', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '54', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '55', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '56', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '57', '4', '1');
INSERT INTO `smi_access` VALUES ('2', '58', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '55', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '56', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '57', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '58', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '63', '2', '1');
INSERT INTO `smi_access` VALUES ('1', '64', '3', '1');
INSERT INTO `smi_access` VALUES ('1', '65', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '66', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '67', '4', '1');
INSERT INTO `smi_access` VALUES ('1', '68', '4', '1');

-- -----------------------------
-- Table structure for `smi_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `smi_attribute`;
CREATE TABLE `smi_attribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute` varchar(128) NOT NULL,
  `attribute_alias` varchar(128) NOT NULL,
  `display` tinyint(1) NOT NULL COMMENT '1单选0多选',
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='产品属性表';

-- -----------------------------
-- Records of `smi_attribute`
-- -----------------------------
INSERT INTO `smi_attribute` VALUES ('1', '价格', '价格', '1', '');
INSERT INTO `smi_attribute` VALUES ('2', '网络制式', '网络制式', '1', '');

-- -----------------------------
-- Table structure for `smi_attribute_value`
-- -----------------------------
DROP TABLE IF EXISTS `smi_attribute_value`;
CREATE TABLE `smi_attribute_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attribute_id` int(11) NOT NULL,
  `attribute_value` varchar(128) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `attribute_id` (`attribute_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COMMENT='产品属性值表';

-- -----------------------------
-- Records of `smi_attribute_value`
-- -----------------------------
INSERT INTO `smi_attribute_value` VALUES ('2', '1', '0-100', '0');
INSERT INTO `smi_attribute_value` VALUES ('3', '1', '100-200', '1');
INSERT INTO `smi_attribute_value` VALUES ('4', '1', '300-500', '2');
INSERT INTO `smi_attribute_value` VALUES ('5', '2', '移动', '0');
INSERT INTO `smi_attribute_value` VALUES ('6', '2', '联通', '1');
INSERT INTO `smi_attribute_value` VALUES ('7', '2', '电信', '2');

-- -----------------------------
-- Table structure for `smi_category`
-- -----------------------------
DROP TABLE IF EXISTS `smi_category`;
CREATE TABLE `smi_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(128) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `route` varchar(128) DEFAULT NULL,
  `grade` tinyint(4) DEFAULT NULL,
  `sort` smallint(6) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='产品分类';

-- -----------------------------
-- Records of `smi_category`
-- -----------------------------
INSERT INTO `smi_category` VALUES ('1', '数码产品', '0', '0', '1', '0', '1', '0');
INSERT INTO `smi_category` VALUES ('2', '电脑', '1', '0,1', '2', '0', '1', '2');
INSERT INTO `smi_category` VALUES ('3', '手机', '1', '0,1', '2', '0', '1', '1');
INSERT INTO `smi_category` VALUES ('4', '相机', '1', '0,1', '2', '0', '1', '0');

-- -----------------------------
-- Table structure for `smi_config`
-- -----------------------------
DROP TABLE IF EXISTS `smi_config`;
CREATE TABLE `smi_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `config_title` varchar(32) NOT NULL,
  `code` varchar(32) NOT NULL,
  `type` varchar(16) NOT NULL,
  `config_value` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  `grade` tinyint(1) NOT NULL,
  `route` varchar(64) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `remark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='网站配置表';

-- -----------------------------
-- Records of `smi_config`
-- -----------------------------
INSERT INTO `smi_config` VALUES ('1', '基本配置', '', 'text', '', '0', '1', '0', '0', '');
INSERT INTO `smi_config` VALUES ('2', '网站标题', 'META_TITLE', 'text', '这是网站标题', '1', '2', '0,1', '0', '网站前台显示标题');
INSERT INTO `smi_config` VALUES ('3', '网站描述', 'META_DESCRIPTION', 'textarea', '这是网站描述', '1', '2', '0,1', '0', '网站搜索引擎描述');
INSERT INTO `smi_config` VALUES ('4', '网站关键字', 'META_KEYWORD', 'textarea', '这是网站关键字', '1', '2', '0,1', '0', '网站搜索引擎关键字');
INSERT INTO `smi_config` VALUES ('5', '网站备案号', 'META_COPYRIGHT', 'text', '这是网站备案号', '1', '2', '0,1', '0', '');
INSERT INTO `smi_config` VALUES ('6', '邮箱配置', '', 'text', '', '0', '1', '0', '0', '');
INSERT INTO `smi_config` VALUES ('7', 'SMTP服务器', 'SMTP_HOST', 'text', 'localhost', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('8', 'SMTP用户名', 'SMTP_USERNAME', 'text', 'mail@example.com', '6', '2', '0,6', '0', '邮箱全称：mail@example.com');
INSERT INTO `smi_config` VALUES ('9', 'SMTP密码', 'SMTP_PWD', 'text', 'password', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('10', 'SMTP端口', 'SMTP_PORT', 'text', '25', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('11', '字符编码', 'SMTP_CHARSET', 'text', 'utf-8', '6', '2', '0,6', '0', '');
INSERT INTO `smi_config` VALUES ('12', '编码方式', 'SMTP_ENCODING', 'text', '', '6', '2', '0,6', '0', '若发送邮件内容出现乱码则用base64');

-- -----------------------------
-- Table structure for `smi_coupon`
-- -----------------------------
DROP TABLE IF EXISTS `smi_coupon`;
CREATE TABLE `smi_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon` varchar(16) NOT NULL,
  `coupon_rule_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `batch` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `use_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupon` (`coupon`),
  KEY `coupon_rule_id` (`coupon_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='优惠券表';


-- -----------------------------
-- Table structure for `smi_coupon_limitation`
-- -----------------------------
DROP TABLE IF EXISTS `smi_coupon_limitation`;
CREATE TABLE `smi_coupon_limitation` (
  `coupon_rule_id` int(11) NOT NULL,
  `limit_type` smallint(6) NOT NULL,
  `object_id` int(11) NOT NULL,
  KEY `coupon_rule_id` (`coupon_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `smi_coupon_rule`
-- -----------------------------
DROP TABLE IF EXISTS `smi_coupon_rule`;
CREATE TABLE `smi_coupon_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `coupon_rule` varchar(128) NOT NULL,
  `coupon_alias` varchar(128) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `min_amount` decimal(11,2) NOT NULL,
  `discount_amount` decimal(11,2) NOT NULL,
  `discount_rate` decimal(3,1) NOT NULL,
  `target_type` tinyint(1) NOT NULL,
  `target_object` text NOT NULL,
  `limit_type` tinyint(1) NOT NULL,
  `total_batch` smallint(6) NOT NULL,
  `remark` varchar(128) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='优惠券规则表';


-- -----------------------------
-- Table structure for `smi_goods`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods`;
CREATE TABLE `smi_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_sno` varchar(64) NOT NULL,
  `goods` varchar(128) DEFAULT NULL,
  `short_name` varchar(128) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `original_price` decimal(11,2) NOT NULL,
  `price` decimal(11,2) NOT NULL,
  `image` varchar(128) NOT NULL,
  `category_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `specification` text NOT NULL,
  `default_product` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods`
-- -----------------------------
INSERT INTO `smi_goods` VALUES ('1', 'sno000', 'testse', 'vice title', '6', '0.00', '0.00', 'Goods/2014-10-17/5440b78f56f48.jpg', '2', '1', '[{\"id\":\"1\",\"spec\":\"\\u989c\\u82721\",\"display\":\"0\",\"_list\":{\"1\":{\"id\":\"1\",\"pvt_val\":\"\\u9ed1\",\"pvt_img\":\"\\/Uploads\\/Spec\\/2014-10-24\\/544a19c50ab7b.jpg\"},\"2\":{\"id\":\"2\",\"pvt_val\":\"\\u767d\",\"pvt_img\":\"\\/Uploads\\/Spec\\/2014-10-22\\/5447841cda655.gif\"},\"5\":{\"id\":\"5\",\"pvt_val\":\"\\u7ea2\",\"pvt_img\":\"\\/Uploads\\/Spec\\/2014-10-23\\/5448c4d90c596.jpg\"}}},{\"id\":\"2\",\"spec\":\"\\u5c3a\\u5bf8\",\"display\":\"1\",\"_list\":{\"6\":{\"id\":\"6\",\"pvt_val\":\"XXS\"},\"7\":{\"id\":\"7\",\"pvt_val\":\"XS\"}}}]', '18', '1');
INSERT INTO `smi_goods` VALUES ('2', 'sno1', 'sadf', 'vice title', '40', '0.00', '0.00', 'Goods/5450a752d85fb.jpg', '2', '0', '', '20', '-1');
INSERT INTO `smi_goods` VALUES ('3', 'test11', 'test', 'tste', '0', '0.00', '0.00', '', '3', '1', '', '26', '-1');

-- -----------------------------
-- Table structure for `smi_goods_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_attribute`;
CREATE TABLE `smi_goods_attribute` (
  `goods_id` int(11) NOT NULL,
  `attr_val_id` int(11) NOT NULL,
  PRIMARY KEY (`goods_id`,`attr_val_id`),
  KEY `goods_id_2` (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品-属性值中间表';

-- -----------------------------
-- Records of `smi_goods_attribute`
-- -----------------------------
INSERT INTO `smi_goods_attribute` VALUES ('1', '2');
INSERT INTO `smi_goods_attribute` VALUES ('1', '5');
INSERT INTO `smi_goods_attribute` VALUES ('3', '2');
INSERT INTO `smi_goods_attribute` VALUES ('3', '7');

-- -----------------------------
-- Table structure for `smi_goods_category`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_category`;
CREATE TABLE `smi_goods_category` (
  `goods_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `is_primary` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`goods_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods_category`
-- -----------------------------
INSERT INTO `smi_goods_category` VALUES ('1', '2', '1');
INSERT INTO `smi_goods_category` VALUES ('1', '3', '0');
INSERT INTO `smi_goods_category` VALUES ('1', '4', '0');
INSERT INTO `smi_goods_category` VALUES ('2', '2', '1');
INSERT INTO `smi_goods_category` VALUES ('3', '3', '1');

-- -----------------------------
-- Table structure for `smi_goods_description`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_description`;
CREATE TABLE `smi_goods_description` (
  `goods_id` int(11) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods_description`
-- -----------------------------
INSERT INTO `smi_goods_description` VALUES ('1', '<p>test sss</p>\r\n');
INSERT INTO `smi_goods_description` VALUES ('2', '<p>sdfad</p>\r\n');
INSERT INTO `smi_goods_description` VALUES ('3', '<p>test</p>\r\n');

-- -----------------------------
-- Table structure for `smi_goods_image`
-- -----------------------------
DROP TABLE IF EXISTS `smi_goods_image`;
CREATE TABLE `smi_goods_image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `origin_image` varchar(128) NOT NULL,
  `big_image` varchar(128) NOT NULL,
  `thumb_image` varchar(128) NOT NULL,
  `small_image` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  PRIMARY KEY (`image_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_goods_image`
-- -----------------------------
INSERT INTO `smi_goods_image` VALUES ('4', '1', 'Goods/2014-10-17/5440d988cbb87.png', '', '', '', '3');
INSERT INTO `smi_goods_image` VALUES ('5', '1', 'Goods/2014-10-17/5440d98c0ea16.jpg', '', '', '', '1');
INSERT INTO `smi_goods_image` VALUES ('6', '1', 'Goods/2014-10-17/5440da3bd11cb.gif', '', '', '', '0');
INSERT INTO `smi_goods_image` VALUES ('7', '1', 'Goods/2014-10-17/5440da3ec154f.jpg', '', '', '', '2');
INSERT INTO `smi_goods_image` VALUES ('8', '1', 'Goods/2014-10-17/5440da40e56a5.jpg', '', '', '', '5');
INSERT INTO `smi_goods_image` VALUES ('9', '1', 'Goods/2014-10-17/5440da4f0700f.jpg', '', '', '', '4');
INSERT INTO `smi_goods_image` VALUES ('11', '1', 'Goods/2014-10-17/5440dd9cc0348.gif', '', '', '', '6');
INSERT INTO `smi_goods_image` VALUES ('12', '1', 'Goods/2014-10-17/5440df337b8a6.jpg', '', '', '', '7');
INSERT INTO `smi_goods_image` VALUES ('13', '1', 'Goods/2014-10-30/5451cf0453ba3.jpg', '', '', '', '8');

-- -----------------------------
-- Table structure for `smi_letter`
-- -----------------------------
DROP TABLE IF EXISTS `smi_letter`;
CREATE TABLE `smi_letter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `subject` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `cc_addr` varchar(128) NOT NULL,
  `bcc_addr` varchar(128) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='邮件模板';

-- -----------------------------
-- Records of `smi_letter`
-- -----------------------------
INSERT INTO `smi_letter` VALUES ('1', '测试邮件模板', '测试主题', '<p>TEST</p>\r\n', '', '', '', '1413193240');

-- -----------------------------
-- Table structure for `smi_member`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member`;
CREATE TABLE `smi_member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account` varchar(128) NOT NULL,
  `pwd` varchar(64) NOT NULL,
  `level_id` smallint(6) NOT NULL,
  `username` varchar(32) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `smi_member`
-- -----------------------------
INSERT INTO `smi_member` VALUES ('2', 'xsp@foxmail.com', '$1$kO1.dY/.$uEAE2MjebpFOqcsVjVs8p1', '1', 'xsp', '1');

-- -----------------------------
-- Table structure for `smi_member_hashcode`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_hashcode`;
CREATE TABLE `smi_member_hashcode` (
  `member_id` int(11) NOT NULL,
  `hash_type` int(11) NOT NULL COMMENT '0注册1找回密码',
  `hash_code` varchar(64) NOT NULL,
  `hash_time` int(11) NOT NULL,
  PRIMARY KEY (`member_id`,`hash_type`),
  KEY `hash_code` (`hash_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员验证表';


-- -----------------------------
-- Table structure for `smi_member_info`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_info`;
CREATE TABLE `smi_member_info` (
  `member_id` int(11) NOT NULL,
  `register_time` int(11) NOT NULL,
  `register_ip` varchar(15) NOT NULL,
  `active_time` int(11) NOT NULL,
  `login_time` int(11) NOT NULL,
  `login_ip` varchar(15) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='会员信息表';

-- -----------------------------
-- Records of `smi_member_info`
-- -----------------------------
INSERT INTO `smi_member_info` VALUES ('2', '1415167810', '127.0.0.1', '1415167810', '0', '', 'aa');

-- -----------------------------
-- Table structure for `smi_member_level`
-- -----------------------------
DROP TABLE IF EXISTS `smi_member_level`;
CREATE TABLE `smi_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_level` varchar(64) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='会员等级表';

-- -----------------------------
-- Records of `smi_member_level`
-- -----------------------------
INSERT INTO `smi_member_level` VALUES ('1', '普通会员', '很普通');
INSERT INTO `smi_member_level` VALUES ('2', '高级会员', '很高级');

-- -----------------------------
-- Table structure for `smi_node`
-- -----------------------------
DROP TABLE IF EXISTS `smi_node`;
CREATE TABLE `smi_node` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `title_cn` varchar(50) DEFAULT NULL,
  `title_en` varchar(128) NOT NULL,
  `show_top` tinyint(1) NOT NULL COMMENT '顶部显示',
  `status` tinyint(1) NOT NULL,
  `sort` smallint(6) NOT NULL COMMENT '排序',
  `pid` smallint(6) NOT NULL COMMENT '上级ID',
  `route` varchar(128) NOT NULL COMMENT '结构1-2-3',
  `grade` tinyint(1) NOT NULL COMMENT '级别1大组2小组3模块4操作',
  `remark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`grade`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=258 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_node`
-- -----------------------------
INSERT INTO `smi_node` VALUES ('1', '', '后台面板', 'Panel', '0', '0', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('2', '', '默认组', 'Default', '0', '0', '0', '1', '0,1', '2', '');
INSERT INTO `smi_node` VALUES ('3', 'Index', '控制面板管理', 'Panel', '0', '0', '0', '2', '0,1,2', '3', '');
INSERT INTO `smi_node` VALUES ('4', 'index', '首页', 'home', '0', '0', '0', '3', '0,1,2,3', '4', '');
INSERT INTO `smi_node` VALUES ('5', 'phpinfo', '系统信息', 'System Info', '0', '0', '0', '3', '0,1,2,3', '4', '');
INSERT INTO `smi_node` VALUES ('6', '', '个人信息组', 'Profiles', '0', '0', '0', '1', '0,1', '2', '');
INSERT INTO `smi_node` VALUES ('7', 'Profile', '个人信息管理', 'Profile', '0', '0', '0', '6', '0,1,6', '3', '');
INSERT INTO `smi_node` VALUES ('8', 'edit', '个人信息', 'edit profile', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('9', 'update', '更新个人信息', 'update profile', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('10', 'editPwd', '修改密码', 'edit password', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('11', 'updatePwd', '更新密码', 'update password', '0', '0', '0', '7', '0,1,6,7', '4', '');
INSERT INTO `smi_node` VALUES ('12', '', '系统', 'System', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('13', '', '权限组', 'Privileges', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('14', 'Node', '权限管理', 'Nodes', '0', '1', '0', '13', '0,12,13', '3', '');
INSERT INTO `smi_node` VALUES ('15', 'index', '权限列表', 'Node List', '0', '1', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('16', 'add', '新增权限', 'add Node', '0', '1', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('17', 'insert', '插入权限', 'insert', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('18', 'edit', '编辑权限', 'edit', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('19', 'update', '更新权限', 'update', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('20', 'addController', '添加控制器权限', 'Add Controller', '0', '1', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('21', 'insertController', '插入控制器权限', 'insert Controller', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('22', 'sort', '排序权限', 'sort', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('23', 'setStatus', '设置状态', 'set status', '0', '0', '0', '14', '0,12,13,14', '4', '');
INSERT INTO `smi_node` VALUES ('24', '', '管理员组', 'Administrators', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('25', 'Role', '角色', 'Roles', '0', '1', '0', '24', '0,12,24', '3', '');
INSERT INTO `smi_node` VALUES ('26', 'index', '角色列表', 'Role List', '0', '1', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('27', 'add', '新增角色', 'Add Role', '0', '1', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('28', 'insert', '插入角色', 'insert', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('29', 'edit', '编辑角色', 'edit', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('30', 'update', '更新角色', 'update', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('31', 'delete', '删除角色', 'delete', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('32', 'setStatus', '设置状态', 'set status', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('33', 'sort', '排序角色', 'sort', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('34', 'privilege', '设置权限', 'set privilege', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('35', 'setPrivilege', '完成权限设置', 'update privilege', '0', '0', '0', '25', '0,12,24,25', '4', '');
INSERT INTO `smi_node` VALUES ('36', 'User', '管理员', 'Administrator', '0', '1', '0', '24', '0,12,24', '3', '');
INSERT INTO `smi_node` VALUES ('37', 'index', '管理员列表', 'Admin List', '0', '1', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('38', 'add', '新增管理员', 'Add Admin', '0', '1', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('39', 'insert', '插入管理员', 'insert', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('40', 'edit', '编辑管理员', 'edit', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('41', 'update', '更新管理员', 'update', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('42', 'delete', '删除管理员', 'delete', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('43', 'search', '搜索管理员', 'search', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('44', 'setStatus', '设置状态', 'set status', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('45', 'sort', '排序管理员', 'sort', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('46', 'editPwd', '修改密码', 'edit password', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('47', 'updatePwd', '更新密码', 'update password', '0', '0', '0', '36', '0,12,24,36', '4', '');
INSERT INTO `smi_node` VALUES ('48', '', '站点配置组', 'Settings', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('49', 'Config', '网站配置', 'Website', '0', '1', '0', '48', '0,12,48', '3', '');
INSERT INTO `smi_node` VALUES ('50', 'index', '网站配置列表', 'General Setting', '0', '1', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('51', 'add', '新增网站配置', 'Add', '0', '1', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('52', 'insert', '插入网站配置', 'insert', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('53', 'edit', '编辑网站配置', 'edit', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('54', 'update', '更新网站配置', 'update', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('55', 'delete', '删除网站配置', 'delete', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('56', 'sort', '排序网站配置', 'sort', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('57', 'setting', '网站配置', 'setting', '0', '1', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('58', 'updateSetting', '更新网站配置', 'update setting', '0', '0', '0', '49', '0,12,48,49', '4', '');
INSERT INTO `smi_node` VALUES ('59', '', '编辑器组', 'Editors', '0', '0', '0', '1', '0,1', '2', '');
INSERT INTO `smi_node` VALUES ('60', 'Editor', '编辑器', 'Editor', '0', '0', '0', '59', '0,1,59', '3', '');
INSERT INTO `smi_node` VALUES ('61', 'elfinder', 'Elfinder编辑器', 'Elfinder Editor', '0', '0', '0', '60', '0,1,59,60', '4', '');
INSERT INTO `smi_node` VALUES ('62', 'connectElfinder', '连接Elfinder', 'Connect Elfinder', '0', '0', '0', '60', '0,1,59,60', '4', '');
INSERT INTO `smi_node` VALUES ('63', '', '数据库组', 'Databases', '0', '1', '0', '12', '0,12', '2', '');
INSERT INTO `smi_node` VALUES ('64', 'Database', '数据库', 'Database', '0', '1', '0', '63', '0,12,63', '3', '');
INSERT INTO `smi_node` VALUES ('65', 'index', '查看数据表', 'Table List', '0', '1', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('66', 'export', '导出数据库', 'Export', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('67', 'optimize', '优化数据表', 'Optimize', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('68', 'repair', '修复数据表', 'Repair', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('69', 'backups', '查看备份', 'Backup List', '0', '1', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('70', 'recover', '恢复数据库', 'Recover', '0', '0', '0', '64', '0,12,63,64', '4', '');
INSERT INTO `smi_node` VALUES ('71', '-', '内容', 'Content', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('72', '-', '页面组', 'Pages', '0', '1', '0', '71', '0,71', '2', '');
INSERT INTO `smi_node` VALUES ('73', 'Page', '页面', 'Page', '0', '1', '0', '72', '0,71,72', '3', '');
INSERT INTO `smi_node` VALUES ('74', 'index', '页面列表', 'Page List', '0', '1', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('75', 'add', '新增页面', 'Add Page', '0', '1', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('76', 'insert', '插入', 'Insert', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('77', 'edit', '编辑', 'Edit', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('78', 'update', '更新', 'Update', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('79', 'delete', '删除', 'Delete', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('80', 'search', '搜索', 'Search', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('81', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('82', 'sort', '排序', 'Sort', '0', '0', '0', '73', '0,71,72,73', '4', '');
INSERT INTO `smi_node` VALUES ('83', '', '广告组', 'Models', '0', '1', '0', '71', '0,71', '2', '');
INSERT INTO `smi_node` VALUES ('84', 'PosterSpace', '广告位', 'Poster Spaces', '0', '1', '0', '83', '0,71,83', '3', '');
INSERT INTO `smi_node` VALUES ('85', 'index', '广告位列表', 'Poster Spaces List', '0', '1', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('86', 'add', '新增广告位', 'Add Poster Spaces', '0', '1', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('87', 'insert', '插入', 'Insert', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('88', 'edit', '编辑', 'Edit', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('89', 'update', '更新', 'Update', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('90', 'delete', '删除', 'Delete', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('91', 'search', '搜索', 'Search', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('92', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('93', 'sort', '排序', 'Sort', '0', '0', '0', '84', '0,71,83,84', '4', '');
INSERT INTO `smi_node` VALUES ('94', 'Poster', '广告', 'Posters', '0', '0', '0', '83', '0,71,83', '3', '');
INSERT INTO `smi_node` VALUES ('95', 'index', '广告列表', 'Posters List', '0', '1', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('96', 'add', '新增广告', 'Add Posters', '0', '1', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('97', 'insert', '插入', 'Insert', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('98', 'edit', '编辑', 'Edit', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('99', 'update', '更新', 'Update', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('100', 'delete', '删除', 'Delete', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('101', 'search', '搜索', 'Search', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('102', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('103', 'sort', '排序', 'Sort', '0', '0', '0', '94', '0,71,83,94', '4', '');
INSERT INTO `smi_node` VALUES ('104', '', '邮件模板组', 'Letters', '0', '1', '0', '71', '0,71', '2', '');
INSERT INTO `smi_node` VALUES ('105', 'Letter', '邮件模板', 'Letter', '0', '1', '0', '104', '0,71,104', '3', '');
INSERT INTO `smi_node` VALUES ('106', 'index', '邮件模板列表', 'Letter List', '0', '1', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('107', 'add', '新增邮件模板', 'Add Letter', '0', '1', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('108', 'insert', '插入', 'Insert', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('109', 'edit', '编辑', 'Edit', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('110', 'update', '更新', 'Update', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('111', 'delete', '删除', 'Delete', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('112', 'search', '搜索', 'Search', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('113', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('114', 'sort', '排序', 'Sort', '0', '0', '0', '105', '0,71,104,105', '4', '');
INSERT INTO `smi_node` VALUES ('115', '', '产品', 'Products', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('116', '', '分类组', 'Categories', '0', '1', '0', '115', '0,115', '2', '');
INSERT INTO `smi_node` VALUES ('117', 'Category', '分类', 'Category', '0', '1', '0', '116', '0,115,116', '3', '');
INSERT INTO `smi_node` VALUES ('118', 'index', '分类列表', 'Category List', '0', '1', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('119', 'add', '新增分类', 'Add Category', '0', '1', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('120', 'insert', '插入', 'Insert', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('121', 'edit', '编辑', 'Edit', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('122', 'update', '更新', 'Update', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('123', 'delete', '删除', 'Delete', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('124', 'search', '搜索', 'Search', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('125', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('126', 'sort', '排序', 'Sort', '0', '0', '0', '117', '0,115,116,117', '4', '');
INSERT INTO `smi_node` VALUES ('127', '', '产品组', 'Products', '0', '1', '0', '115', '0,115', '2', '');
INSERT INTO `smi_node` VALUES ('128', 'Goods', '产品', 'Goods', '0', '1', '0', '127', '0,115,127', '3', '');
INSERT INTO `smi_node` VALUES ('129', 'index', '产品列表', 'Goods List', '0', '1', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('130', 'add', '新增产品', 'Add Goods', '0', '1', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('131', 'insert', '插入', 'Insert', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('132', 'edit', '编辑', 'Edit', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('133', 'update', '更新', 'Update', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('134', 'delete', '删除', 'Delete', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('135', 'search', '搜索', 'Search', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('136', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('137', 'sort', '排序', 'Sort', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('138', '', '扩展组', 'Extends', '0', '1', '0', '115', '0,115', '2', '');
INSERT INTO `smi_node` VALUES ('139', 'Spec', '规格', 'Specification', '0', '1', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('140', 'index', '产品规格', 'Specification List', '0', '1', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('141', 'add', '新增产品规格', 'Add Specification', '0', '1', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('142', 'insert', '插入', 'Insert', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('143', 'edit', '编辑', 'Edit', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('144', 'update', '更新', 'Update', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('145', 'delete', '删除', 'Delete', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('146', 'search', '搜索', 'Search', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('147', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('148', 'sort', '排序', 'Sort', '0', '0', '0', '139', '0,115,138,139', '4', '');
INSERT INTO `smi_node` VALUES ('149', 'SpecValue', '规格值', 'Spec Values', '0', '0', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('150', 'add', '新增规格值', 'Add Spec Values', '0', '1', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('151', 'insert', '插入', 'Insert', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('152', 'edit', '编辑', 'Edit', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('153', 'update', '更新', 'Update', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('154', 'delete', '删除', 'Delete', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('155', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('156', 'sort', '排序', 'Sort', '0', '0', '0', '149', '0,115,138,149', '4', '');
INSERT INTO `smi_node` VALUES ('157', 'Attribute', '产品属性', 'Attribute', '0', '1', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('158', 'index', '产品属性', 'Attribute List', '0', '1', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('159', 'add', '新增产品属性', 'Add Attribute', '0', '1', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('160', 'insert', '插入', 'Insert', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('161', 'edit', '编辑', 'Edit', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('162', 'update', '更新', 'Update', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('163', 'delete', '删除', 'Delete', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('164', 'search', '搜索', 'Search', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('165', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('166', 'sort', '排序', 'Sort', '0', '0', '0', '157', '0,115,138,157', '4', '');
INSERT INTO `smi_node` VALUES ('167', 'AttributeValue', '产品属性值', 'AttributeValue', '0', '0', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('168', 'index', '产品属性值列表', 'AttributeValue List', '0', '1', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('169', 'add', '新增产品属性值', 'Add AttributeValue', '0', '1', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('170', 'insert', '插入', 'Insert', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('171', 'edit', '编辑', 'Edit', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('172', 'update', '更新', 'Update', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('173', 'delete', '删除', 'Delete', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('174', 'search', '搜索', 'Search', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('175', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('176', 'sort', '排序', 'Sort', '0', '0', '0', '167', '0,115,138,167', '4', '');
INSERT INTO `smi_node` VALUES ('177', 'Type', '产品类型', 'ProductType', '0', '1', '0', '138', '0,115,138', '3', '');
INSERT INTO `smi_node` VALUES ('178', 'index', '产品类型', 'ProductType List', '0', '1', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('179', 'add', '新增产品类型', 'Add ProductType', '0', '1', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('180', 'insert', '插入', 'Insert', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('181', 'edit', '编辑', 'Edit', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('182', 'update', '更新', 'Update', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('183', 'delete', '删除', 'Delete', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('184', 'search', '搜索', 'Search', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('185', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('186', 'sort', '排序', 'Sort', '0', '0', '0', '177', '0,115,138,177', '4', '');
INSERT INTO `smi_node` VALUES ('187', 'recycle', '放入回收站', 'Recycle', '0', '0', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('188', 'recyclebin', '产品回收站', 'RecycleBin', '0', '1', '0', '128', '0,115,127,128', '4', '');
INSERT INTO `smi_node` VALUES ('189', '', '会员', 'Member', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('190', '', '会员组', 'Members', '0', '1', '0', '189', '0,189', '2', '');
INSERT INTO `smi_node` VALUES ('191', 'Member', '会员', 'Member', '0', '1', '0', '190', '0,189,190', '3', '');
INSERT INTO `smi_node` VALUES ('192', 'index', '会员列表', 'Member List', '0', '1', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('193', 'add', '新增会员', 'Add Member', '0', '1', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('194', 'insert', '插入', 'Insert', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('195', 'edit', '编辑', 'Edit', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('196', 'update', '更新', 'Update', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('197', 'delete', '删除', 'Delete', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('198', 'search', '搜索', 'Search', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('199', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('200', 'sort', '排序', 'Sort', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('201', '', '扩展组', 'Extends', '0', '1', '0', '189', '0,189', '2', '');
INSERT INTO `smi_node` VALUES ('202', 'MemberLevel', '会员等级', 'MemberLevel', '0', '1', '0', '201', '0,189,201', '3', '');
INSERT INTO `smi_node` VALUES ('203', 'index', '会员等级列表', 'MemberLevel List', '0', '1', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('204', 'add', '新增会员等级', 'Add MemberLevel', '0', '1', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('205', 'insert', '插入', 'Insert', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('206', 'edit', '编辑', 'Edit', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('207', 'update', '更新', 'Update', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('208', 'delete', '删除', 'Delete', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('209', 'search', '搜索', 'Search', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('210', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('211', 'sort', '排序', 'Sort', '0', '0', '0', '202', '0,189,201,202', '4', '');
INSERT INTO `smi_node` VALUES ('212', 'modifypwd', '修改密码', 'ModifyPassword', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('213', 'updatepwd', '更新密码', 'UpdatePassword', '0', '0', '0', '191', '0,189,190,191', '4', '');
INSERT INTO `smi_node` VALUES ('214', '', '订单', 'Order', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('215', '', '运营', 'Sales', '0', '1', '0', '0', '0', '1', '');
INSERT INTO `smi_node` VALUES ('216', '', '促销推广组', 'Promotions', '0', '1', '0', '215', '0,215', '2', '');
INSERT INTO `smi_node` VALUES ('217', 'Promotion', '促销活动', 'Promotion', '0', '1', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('218', 'index', '促销活动列表', 'Promotion List', '0', '1', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('219', 'add', '新增促销活动', 'Add Promotion', '0', '1', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('220', 'insert', '插入', 'Insert', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('221', 'edit', '编辑', 'Edit', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('222', 'update', '更新', 'Update', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('223', 'delete', '删除', 'Delete', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('224', 'search', '搜索', 'Search', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('225', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('226', 'sort', '排序', 'Sort', '0', '0', '0', '217', '0,215,216,217', '4', '');
INSERT INTO `smi_node` VALUES ('227', 'PromotionRule', '促销活动规则', 'PromotionRule', '0', '0', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('228', 'index', '促销活动规则列表', 'PromotionRule List', '0', '1', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('229', 'add', '新增促销活动规则', 'Add PromotionRule', '0', '1', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('230', 'insert', '插入', 'Insert', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('231', 'edit', '编辑', 'Edit', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('232', 'update', '更新', 'Update', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('233', 'delete', '删除', 'Delete', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('234', 'search', '搜索', 'Search', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('235', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('236', 'sort', '排序', 'Sort', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('237', 'products', '调取产品', 'GetProducts', '0', '0', '0', '227', '0,215,216,227', '4', '');
INSERT INTO `smi_node` VALUES ('238', 'CouponRule', '优惠券规则', 'CouponRule', '0', '1', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('239', 'index', '优惠券规则列表', 'CouponRule List', '0', '1', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('240', 'add', '新增优惠券规则', 'Add CouponRule', '0', '1', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('241', 'insert', '插入', 'Insert', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('242', 'edit', '编辑', 'Edit', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('243', 'update', '更新', 'Update', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('244', 'delete', '删除', 'Delete', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('245', 'search', '搜索', 'Search', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('246', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('247', 'sort', '排序', 'Sort', '0', '0', '0', '238', '0,215,216,238', '4', '');
INSERT INTO `smi_node` VALUES ('248', 'Coupon', '优惠券', 'Coupon', '0', '0', '0', '216', '0,215,216', '3', '');
INSERT INTO `smi_node` VALUES ('249', 'index', '优惠券列表', 'Coupon List', '0', '1', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('250', 'add', '新增优惠券', 'Add Coupon', '0', '1', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('251', 'insert', '插入', 'Insert', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('252', 'edit', '编辑', 'Edit', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('253', 'update', '更新', 'Update', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('254', 'delete', '删除', 'Delete', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('255', 'search', '搜索', 'Search', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('256', 'setStatus', '设置状态', 'Set Status', '0', '0', '0', '248', '0,215,216,248', '4', '');
INSERT INTO `smi_node` VALUES ('257', 'sort', '排序', 'Sort', '0', '0', '0', '248', '0,215,216,248', '4', '');

-- -----------------------------
-- Table structure for `smi_page`
-- -----------------------------
DROP TABLE IF EXISTS `smi_page`;
CREATE TABLE `smi_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `brief` varchar(255) NOT NULL,
  `seo_name` varchar(128) NOT NULL,
  `image` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `publish_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  `page_title` varchar(128) NOT NULL,
  `meta_keywords` varchar(255) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `seo_name` (`seo_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_page`
-- -----------------------------
INSERT INTO `smi_page` VALUES ('1', 'teste', '<p>tsets</p>\r\n', 'tsets', 'test', '', '0', '1', '1413098100', '1413098160', '', '', '');

-- -----------------------------
-- Table structure for `smi_poster`
-- -----------------------------
DROP TABLE IF EXISTS `smi_poster`;
CREATE TABLE `smi_poster` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `space_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `file` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `space_id` (`space_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='广告内容';

-- -----------------------------
-- Records of `smi_poster`
-- -----------------------------
INSERT INTO `smi_poster` VALUES ('2', '3', 'test0', 'http://www.baidu.com0', 'Poster/2014-10-25/544bc22b0d2aa.png', '0', '1');
INSERT INTO `smi_poster` VALUES ('3', '3', 'test2', '#2', 'Poster/2014-10-25/544bbf7261b28.png', '1', '0');
INSERT INTO `smi_poster` VALUES ('4', '3', 'aaa', '#2', 'Poster/2014-10-25/544bc055615df.png', '2', '1');
INSERT INTO `smi_poster` VALUES ('6', '3', 'sarerewrew', 'adfsadf', 'Poster/544bd605b7905.png', '3', '0');

-- -----------------------------
-- Table structure for `smi_poster_space`
-- -----------------------------
DROP TABLE IF EXISTS `smi_poster_space`;
CREATE TABLE `smi_poster_space` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `sort` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='广告位';

-- -----------------------------
-- Records of `smi_poster_space`
-- -----------------------------
INSERT INTO `smi_poster_space` VALUES ('3', '第一个广告位99', '', '0');

-- -----------------------------
-- Table structure for `smi_product`
-- -----------------------------
DROP TABLE IF EXISTS `smi_product`;
CREATE TABLE `smi_product` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `sku_sno` int(11) NOT NULL,
  `sku_data` varchar(255) NOT NULL,
  `sku_info` varchar(128) NOT NULL,
  `product_sno` varchar(128) NOT NULL,
  `stock` int(11) NOT NULL,
  `sku_images` varchar(128) NOT NULL,
  `is_onsale` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `goods_id` (`goods_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_product`
-- -----------------------------
INSERT INTO `smi_product` VALUES ('18', '1', '6', '{\"color\":\"\\u9ed1\",\"size\":\"XXS\"}', '黑,XXS', 'e', '5', '7,4,5', '1');
INSERT INTO `smi_product` VALUES ('20', '2', '0', '', '', 'sno1', '4', '', '1');
INSERT INTO `smi_product` VALUES ('21', '1', '12', '{\"color\":\"\\u767d\",\"size\":\"XXS\"}', '白,XXS', 'r', '1', '11,12,8', '1');
INSERT INTO `smi_product` VALUES ('22', '1', '30', '{\"color\":\"\\u7ea2\",\"size\":\"XXS\"}', '红,XXS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('23', '1', '7', '{\"color\":\"\\u9ed1\",\"size\":\"XS\"}', '黑,XS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('24', '1', '14', '{\"color\":\"\\u767d\",\"size\":\"XS\"}', '白,XS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('25', '1', '35', '{\"color\":\"\\u7ea2\",\"size\":\"XS\"}', '红,XS', '', '0', '', '1');
INSERT INTO `smi_product` VALUES ('26', '3', '0', '', '', 'test11', '0', '', '1');

-- -----------------------------
-- Table structure for `smi_promotion`
-- -----------------------------
DROP TABLE IF EXISTS `smi_promotion`;
CREATE TABLE `smi_promotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion` varchar(128) NOT NULL,
  `start_time` int(11) NOT NULL,
  `end_time` int(11) NOT NULL,
  `remark` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='促销活动表';

-- -----------------------------
-- Records of `smi_promotion`
-- -----------------------------
INSERT INTO `smi_promotion` VALUES ('1', '测试活动一', '1415255629', '1415289599', 'test', '0', '1');

-- -----------------------------
-- Table structure for `smi_promotion_limitation`
-- -----------------------------
DROP TABLE IF EXISTS `smi_promotion_limitation`;
CREATE TABLE `smi_promotion_limitation` (
  `promotion_id` int(11) NOT NULL,
  `promotion_rule_id` int(11) NOT NULL,
  `limit_type` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  KEY `promotion_rule_id` (`promotion_rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_promotion_limitation`
-- -----------------------------
INSERT INTO `smi_promotion_limitation` VALUES ('1', '2', '2', '1');

-- -----------------------------
-- Table structure for `smi_promotion_rule`
-- -----------------------------
DROP TABLE IF EXISTS `smi_promotion_rule`;
CREATE TABLE `smi_promotion_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_id` int(11) NOT NULL,
  `promotion_rule` varchar(128) NOT NULL,
  `promotion_rule_alias` varchar(64) NOT NULL,
  `min_amount` decimal(11,2) NOT NULL,
  `promote_type` tinyint(4) NOT NULL,
  `discount_amount` decimal(11,2) NOT NULL,
  `discount_rate` decimal(2,0) NOT NULL,
  `limit_type` tinyint(4) NOT NULL,
  `remark` varchar(128) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `promotion_id` (`promotion_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='促销活动规则表';

-- -----------------------------
-- Records of `smi_promotion_rule`
-- -----------------------------
INSERT INTO `smi_promotion_rule` VALUES ('2', '1', '满200减100', '满200减100', '200.00', '1', '100.00', '0', '2', 'c', '0', '1');

-- -----------------------------
-- Table structure for `smi_role`
-- -----------------------------
DROP TABLE IF EXISTS `smi_role`;
CREATE TABLE `smi_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `pid` int(11) NOT NULL,
  `route` varchar(255) NOT NULL,
  `grade` tinyint(4) NOT NULL,
  `sort` smallint(6) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_role`
-- -----------------------------
INSERT INTO `smi_role` VALUES ('1', '高级管理员', '0', '0', '1', '0', '1', '');
INSERT INTO `smi_role` VALUES ('2', '二级管理员', '1', '0,1', '2', '3', '1', '');
INSERT INTO `smi_role` VALUES ('3', '三级管理员', '2', '0,1,2', '3', '0', '1', '');
INSERT INTO `smi_role` VALUES ('4', '新的二级管理员', '1', '0,1', '2', '2', '1', '');

-- -----------------------------
-- Table structure for `smi_seo_names`
-- -----------------------------
DROP TABLE IF EXISTS `smi_seo_names`;
CREATE TABLE `smi_seo_names` (
  `seo_name` varchar(128) NOT NULL,
  `object_id` int(11) NOT NULL,
  `type` char(1) NOT NULL,
  UNIQUE KEY `name` (`seo_name`,`type`),
  KEY `name_2` (`seo_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_seo_names`
-- -----------------------------
INSERT INTO `smi_seo_names` VALUES ('tset', '1', 'a');

-- -----------------------------
-- Table structure for `smi_spec`
-- -----------------------------
DROP TABLE IF EXISTS `smi_spec`;
CREATE TABLE `smi_spec` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec` varchar(128) NOT NULL,
  `spec_alias` varchar(128) NOT NULL,
  `display` tinyint(1) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='规格表';

-- -----------------------------
-- Records of `smi_spec`
-- -----------------------------
INSERT INTO `smi_spec` VALUES ('1', '颜色1', '颜色1', '0', '一般性颜色1');
INSERT INTO `smi_spec` VALUES ('2', '尺寸（大中小）', '尺寸', '1', '');

-- -----------------------------
-- Table structure for `smi_spec_value`
-- -----------------------------
DROP TABLE IF EXISTS `smi_spec_value`;
CREATE TABLE `smi_spec_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `spec_id` int(11) NOT NULL,
  `spec_value` varchar(128) NOT NULL,
  `spec_image` varchar(128) NOT NULL,
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `spec_id` (`spec_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_spec_value`
-- -----------------------------
INSERT INTO `smi_spec_value` VALUES ('1', '1', 'asdfasdf00', 'Spec/2014-10-24/544a19c50ab7b.jpg', '2');
INSERT INTO `smi_spec_value` VALUES ('2', '1', 'yuhjh0', 'Spec/2014-10-22/5447841cda655.gif', '0');
INSERT INTO `smi_spec_value` VALUES ('5', '1', 'gdfhshbgfh11', 'Spec/2014-10-23/5448c4d90c596.jpg', '1');
INSERT INTO `smi_spec_value` VALUES ('6', '2', 'XXS', '', '0');
INSERT INTO `smi_spec_value` VALUES ('7', '2', 'XS', '', '1');

-- -----------------------------
-- Table structure for `smi_type`
-- -----------------------------
DROP TABLE IF EXISTS `smi_type`;
CREATE TABLE `smi_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(128) NOT NULL,
  `remark` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='产品类型表';

-- -----------------------------
-- Records of `smi_type`
-- -----------------------------
INSERT INTO `smi_type` VALUES ('1', '手机', '');
INSERT INTO `smi_type` VALUES ('2', '电脑', '');

-- -----------------------------
-- Table structure for `smi_type_attribute`
-- -----------------------------
DROP TABLE IF EXISTS `smi_type_attribute`;
CREATE TABLE `smi_type_attribute` (
  `type_id` int(11) NOT NULL,
  `attribute_id` int(11) NOT NULL,
  `sort` smallint(6) NOT NULL,
  UNIQUE KEY `type_id` (`type_id`,`attribute_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='产品类型-属性关联表';

-- -----------------------------
-- Records of `smi_type_attribute`
-- -----------------------------
INSERT INTO `smi_type_attribute` VALUES ('1', '1', '1');
INSERT INTO `smi_type_attribute` VALUES ('1', '2', '0');
INSERT INTO `smi_type_attribute` VALUES ('2', '1', '0');

-- -----------------------------
-- Table structure for `smi_user`
-- -----------------------------
DROP TABLE IF EXISTS `smi_user`;
CREATE TABLE `smi_user` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `account` varchar(64) NOT NULL,
  `password` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `mobile` varchar(32) NOT NULL,
  `role_id` smallint(6) NOT NULL,
  `is_super` tinyint(1) NOT NULL COMMENT '超级管理员',
  `last_login_time` int(11) NOT NULL COMMENT '最后登录时间',
  `last_login_ip` varchar(15) NOT NULL COMMENT '最后登录IP',
  `login_count` smallint(6) NOT NULL COMMENT '登录次数',
  `status` tinyint(1) NOT NULL,
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `smi_user`
-- -----------------------------
INSERT INTO `smi_user` VALUES ('2', 'administrator', '$1$dF3.iv/.$C6F38LMCo5t.f3kKCyOrl0', '', '', '0', '1', '1415323923', '127.0.0.1', '65', '1', '1401359163');
INSERT INTO `smi_user` VALUES ('3', 'jacob', '$1$O32.9y4.$0TEwBLEU0K10aKsOAlyEU/', '', '', '1', '0', '1401784869', '127.0.0.1', '5', '1', '1401530055');
INSERT INTO `smi_user` VALUES ('4', 'echo', '$1$Lm/.2u3.$VJDP/OgRNNBjHvOOg7hfI.', '', '', '2', '0', '0', '', '0', '1', '1401786246');
